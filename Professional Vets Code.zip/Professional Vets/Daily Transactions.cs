﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Professional_Vets
{
    public partial class Daily_Transactions : Form
    {
        String vn;
        
        SqlConnection con = new SqlConnection(Properties.Settings.Default.Database1ConnectionString);
        SqlCommand cmd;

        public Daily_Transactions(String role)
        {
            InitializeComponent();
            label7.Text = role;
            vn = role;
        }

        private void Daily_Transactions_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            
        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void circularButton1_Click(object sender, EventArgs e)
        {
            this.Hide();
            HomePage HP = new HomePage(vn);
            HP.ShowDialog();
        }

        private void richTextBox9_Action_TextChanged(object sender, EventArgs e)
        {

        }

        private void circularButton3_Click(object sender, EventArgs e)
        {
//            con = new SqlConnection(Properties.Settings.Default.Database1ConnectionString);
            con.Open();

            cmd = new SqlCommand("Insert INTO DTran (Vet_Name, Date, Action_1, Price_1, Paid_1, More_Info_1, Action_2, Price_2, Paid_2, More_Info_2, Action_3, Price_3, Paid_3, More_Info_3, Action_4, Price_4, Paid_4, More_Info_4, Action_5, Price_5, Paid_5, More_Info_5, Action_6, Price_6, Paid_6, More_Info_6, Action_7, Price_7, Paid_7, More_Info_7, Action_8, Price_8, Paid_8, More_Info_8, Action_9, Price_9, Paid_9, More_Info_9, Action_10, Price_10, Paid_10, More_Info_10, Action_11, Price_11, Paid_11, More_Info_11, Action_12, Price_12, Paid_12, More_Info_12, Action_13, Price_13, Paid_13, More_Info_13, Action_14, Price_14, Paid_14, More_Info_14, Action_15, Price_15, Paid_15, More_Info_15) VALUES (@Vet_Name, @Date, @Action_1, @Price_1, @Paid_1, @More_Info_1, @Action_2, @Price_2, @Paid_2, @More_Info_2, @Action_3, @Price_3, @Paid_3, @More_Info_3, @Action_4, @Price_4, @Paid_4, @More_Info_4, @Action_5, @Price_5, @Paid_5, @More_Info_5, @Action_6, @Price_6, @Paid_6, @More_Info_6, @Action_7, @Price_7, @Paid_7, @More_Info_7, @Action_8, @Price_8, @Paid_8, @More_Info_8, @Action_9, @Price_9, @Paid_9, @More_Info_9, @Action_10, @Price_10, @Paid_10, @More_Info_10, @Action_11, @Price_11, @Paid_11, @More_Info_11, @Action_12, @Price_12, @Paid_12, @More_Info_12, @Action_13, @Price_13, @Paid_13, @More_Info_13, @Action_14, @Price_14, @Paid_14, @More_Info_14, @Action_15, @Price_15, @Paid_15, @More_Info_15)", con);

            cmd.Parameters.AddWithValue("@Vet_Name", label7.Text);
            cmd.Parameters.AddWithValue("@Date", DateTime.Now);

            if (rtxt_Action1 != null)
            {
                cmd.Parameters.AddWithValue("@Action_1", rtxt_Action1.Text);
                cmd.Parameters.AddWithValue("@Price_1", textBox1_Price.Text);
                cmd.Parameters.AddWithValue("@Paid_1", textBox1_Paid.Text);
                cmd.Parameters.AddWithValue("@More_Info_1", richTextBox1_MI.Text);
            }

            if (richTextBox2_Action != null)
            {
                cmd.Parameters.AddWithValue("@Action_2", richTextBox2_Action.Text);
                cmd.Parameters.AddWithValue("@Price_2", textBox2_Price.Text);
                cmd.Parameters.AddWithValue("@Paid_2", textBox2_Paid.Text);
                cmd.Parameters.AddWithValue("@More_Info_2", richTextBox2_MI.Text);
            }

            if (richTextBox3_Action != null)
            {
                cmd.Parameters.AddWithValue("@Action_3", richTextBox3_Action.Text);
                cmd.Parameters.AddWithValue("@Price_3", textBox3_Price.Text);
                cmd.Parameters.AddWithValue("@Paid_3", textBox3_Paid.Text);
                cmd.Parameters.AddWithValue("@More_Info_3", richTextBox3_MI.Text);
            }

            if (richTextBox4_Action != null)
            {
                cmd.Parameters.AddWithValue("@Action_4", richTextBox4_Action.Text);
                cmd.Parameters.AddWithValue("@Price_4", textBox4_Price.Text);
                cmd.Parameters.AddWithValue("@Paid_4", textBox4_Paid.Text);
                cmd.Parameters.AddWithValue("@More_Info_4", richTextBox4_MI.Text);
            }

            if (richTextBox5_Action != null)
            {
                cmd.Parameters.AddWithValue("@Action_5", richTextBox5_Action.Text);
                cmd.Parameters.AddWithValue("@Price_5", textBox5_Price.Text);
                cmd.Parameters.AddWithValue("@Paid_5", textBox5_Paid.Text);
                cmd.Parameters.AddWithValue("@More_Info_5", richTextBox5_MI.Text);
            }

            if (richTextBox6_Action != null)
            {
                cmd.Parameters.AddWithValue("@Action_6", richTextBox6_Action.Text);
                cmd.Parameters.AddWithValue("@Price_6", textBox6_Price.Text);
                cmd.Parameters.AddWithValue("@Paid_6", textBox6_Paid.Text);
                cmd.Parameters.AddWithValue("@More_Info_6", richTextBox6_MI.Text);
            }

            if (richTextBox7_Action != null)
            {
                cmd.Parameters.AddWithValue("@Action_7", richTextBox7_Action.Text);
                cmd.Parameters.AddWithValue("@Price_7", textBox7_Price.Text);
                cmd.Parameters.AddWithValue("@Paid_7", textBox7_Paid.Text);
                cmd.Parameters.AddWithValue("@More_Info_7", richTextBox7_MI.Text);
            }

            if (richTextBox8_Action != null)
            {
                cmd.Parameters.AddWithValue("@Action_8", richTextBox8_Action.Text);
                cmd.Parameters.AddWithValue("@Price_8", textBox8_Price.Text);
                cmd.Parameters.AddWithValue("@Paid_8", textBox8_Paid.Text);
                cmd.Parameters.AddWithValue("@More_Info_8", richTextBox8_MI.Text);
            }

            if (richTextBox9_Action != null)
            {
                cmd.Parameters.AddWithValue("@Action_9", richTextBox9_Action.Text);
                cmd.Parameters.AddWithValue("@Price_9", textBox9_Price.Text);
                cmd.Parameters.AddWithValue("@Paid_9", textBox9_Paid.Text);
                cmd.Parameters.AddWithValue("@More_Info_9", richTextBox9_MI.Text);
            }

            if (richTextBox10_Action != null)
            {
                cmd.Parameters.AddWithValue("@Action_10", richTextBox10_Action.Text);
                cmd.Parameters.AddWithValue("@Price_10", textBox10_Price.Text);
                cmd.Parameters.AddWithValue("@Paid_10", textBox10_Paid.Text);
                cmd.Parameters.AddWithValue("@More_Info_10", richTextBox10_MI.Text);
            }

            if (richTextBox11_Action != null)
            {
                cmd.Parameters.AddWithValue("@Action_11", richTextBox11_Action.Text);
                cmd.Parameters.AddWithValue("@Price_11", textBox11_Price.Text);
                cmd.Parameters.AddWithValue("@Paid_11", textBox11_Paid.Text);
                cmd.Parameters.AddWithValue("@More_Info_11", richTextBox11_MI.Text);
            }

            if (richTextBox12_Action != null)
            {
                cmd.Parameters.AddWithValue("@Action_12", richTextBox12_Action.Text);
                cmd.Parameters.AddWithValue("@Price_12", textBox12_Price.Text);
                cmd.Parameters.AddWithValue("@Paid_12", textBox12_Paid.Text);
                cmd.Parameters.AddWithValue("@More_Info_12", richTextBox12_MI.Text);
            }

            if (richTextBox13_Action != null)
            {
                cmd.Parameters.AddWithValue("@Action_13", richTextBox13_Action.Text);
                cmd.Parameters.AddWithValue("@Price_13", textBox13_Price.Text);
                cmd.Parameters.AddWithValue("@Paid_13", textBox13_Paid.Text);
                cmd.Parameters.AddWithValue("@More_Info_13", richTextBox13_MI.Text);
            }

            if (richTextBox14_Action != null)
            {
                cmd.Parameters.AddWithValue("@Action_14", richTextBox14_Action.Text);
                cmd.Parameters.AddWithValue("@Price_14", textBox14_Price.Text);
                cmd.Parameters.AddWithValue("@Paid_14", textBox14_Paid.Text);
                cmd.Parameters.AddWithValue("@More_Info_14", richTextBox14_MI.Text);
            }

            if (richTextBox15_Action != null)
            {
                cmd.Parameters.AddWithValue("@Action_15", richTextBox15_Action.Text);
                cmd.Parameters.AddWithValue("@Price_15", textBox15_Price.Text);
                cmd.Parameters.AddWithValue("@Paid_15", textBox15_Paid.Text);
                cmd.Parameters.AddWithValue("@More_Info_15", richTextBox15_MI.Text);
            }


            cmd.ExecuteNonQuery();
            con.Close();

            this.Hide();
            HomePage HP = new HomePage(vn);
            HP.ShowDialog();
        }

        private void Daily_Transactions_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.Hide();
            HomePage HP = new HomePage(vn);
            HP.ShowDialog();
        }
    }
}
