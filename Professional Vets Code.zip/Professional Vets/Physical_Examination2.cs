﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Professional_Vets
{
    public partial class Physical_Examination2 : Form
    {
        String vn, ow, mb, pt;
        DateTime dat;

        SqlCommand cmd;
        SqlConnection con;

        String N_GIT, AF_GIT, EG_GIT, P_GIT, V_GIT, D_GIT, An_GIT;
        String N_US, AU_US, AS_US, GD_US, AT_US, MA_US;

        private void Physical_Examination2_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.Hide();
            HomePage HP = new HomePage(vn);
            HP.ShowDialog();
        }

        private void txt_Pay_KeyPress(object sender, KeyPressEventArgs e)
        {
            
        }

        private void txt_Price_KeyPress(object sender, KeyPressEventArgs e)
        {
            
        }

        String Ex_D, Go_D, CD_D, Vn_D;
        
        public Physical_Examination2(String role, String owner, String mobile, String pet, DateTime dat1)
        {
            InitializeComponent();
            vn = role;
            ow = owner;
            mb = mobile;
            pt = pet;
            dat = dat1;

        }

        private void richTextBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void Physical_Examination2_Load(object sender, EventArgs e)
        {
            //////////GIT
            ///////////checkBox12 & textBox6/////////
            if (ch_Other_GIT.Checked)
            {
                txt_Other_GIT.Visible = true;
            }
            else
            {
                txt_Other_GIT.Visible = false;
            }


            /////////Urogenital System
            ///////////checkBox23 & textBox7/////////
            if (ch_Other_US.Checked)
            {
                txt_Other_US.Visible = true;
            }
            else
            {
                txt_Other_US.Visible = false;
            }


            ///////Diet
            ///////////checkBox25 & richTextBox1/////////
            if (ch_Recommendations_D.Checked)
            {
                rtxt_Recommendations_D.Visible = true;
            }
            else
            {
                rtxt_Recommendations_D.Visible = false;
            }

        }

        private void ch_Other_GIT_CheckedChanged(object sender, EventArgs e)
        {
            txt_Other_GIT.Visible = (ch_Other_GIT.CheckState == CheckState.Checked);
        }

        
        private void ch_Other_US_CheckedChanged(object sender, EventArgs e)
        {
            txt_Other_US.Visible = (ch_Other_US.CheckState == CheckState.Checked);
        }

        private void checkBox25_CheckedChanged(object sender, EventArgs e)
        {
            rtxt_Recommendations_D.Visible = (ch_Recommendations_D.CheckState == CheckState.Checked);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            
        }

        private void circularButton1_Click(object sender, EventArgs e)
        {
            this.Hide();
            HomePage HP = new HomePage(vn);
            HP.ShowDialog();
        }


        private void CircularButton3_Click(object sender, EventArgs e)
        {
            // IF Statement for GIT
            N_GIT = ch_Normal_GIT.Checked == true ? "Yes" : "No";
            AF_GIT = ch_Abn_Feces_GIT.Checked == true ? "Yes" : "No";
            EG_GIT = ch_Excessive_Gas_GIT.Checked == true ? "Yes" : "No";
            P_GIT = ch_Parasites_GIT.Checked == true ? "Yes" : "No";
            V_GIT = ch_Vomiting_GIT.Checked == true ? "Yes" : "No";
            D_GIT = ch_Diarrhea_GIT.Checked == true ? "Yes" : "No";
            An_GIT = ch_Anorexia_GIT.Checked == true ? "Yes" : "No";

            // IF Statement for US (Urogenital System)
            N_US = ch_Normal_US.Checked == true ? "Yes" : "No";
            AU_US = ch_Abnormal_Urination_US.Checked == true ? "Yes" : "No";
            AS_US = ch_Anal_Sacs_US.Checked == true ? "Yes" : "No";
            GD_US = ch_Genital_Discharge_C_US.Checked == true ? "Yes" : "No";
            AT_US = ch_Abn_Testicles_US.Checked == true ? "Yes" : "No";
            MA_US = ch_Mammary_Abn_US.Checked == true ? "Yes" : "No";

            // IF Statement for D (Diet)
            Ex_D = ch_Excellent_D.Checked == true ? "Yes" : "No";
            Go_D = ch_Good_D.Checked == true ? "Yes" : "No";
            CD_D = ch_Change_Diet_D.Checked == true ? "Yes" : "No";
            Vn_D = ch_Vitamins_needed_D.Checked == true ? "Yes" : "No";


            // Connect with DataBase
            con = new SqlConnection(Properties.Settings.Default.Database1ConnectionString);
            con.Open();

            cmd = new SqlCommand("Insert INTO Ph_Ex2(Date, Vet_Name, Owner, Mobile, Pet, Normal_GIT, Abn_Feces_GIT, Excessive_Gas_GIT, Parasites_GIT, Vomiting_GIT, Diarrhea_GIT, Anorexia_GIT, Other_GIT, Normal_US, Abnormal_Urination_US, Anal_Sacs_US, Genital_Discharge_US, Abn_Testicles_US, Mammary_Abn_US, Other_US, Excellent_D, Good_D, Change_Diet_D, Vitamins_needed_D, Recommendations_D, Diagnosis_Explanations, Recommendations, Price, Pay) VALUES (@Date, @Vet_Name, @Owner, @Mobile, @Pet, @Normal_GIT, @Abn_Feces_GIT, @Excessive_Gas_GIT, @Parasites_GIT, @Vomiting_GIT, @Diarrhea_GIT, @Anorexia_GIT, @Other_GIT, @Normal_US, @Abnormal_Urination_US, @Anal_Sacs_US, @Genital_Discharge_US, @Abn_Testicles_US, @Mammary_Abn_US, @Other_US, @Excellent_D, @Good_D, @Change_Diet_D, @Vitamins_needed_D, @Recommendations_D, @Diagnosis_Explanations, @Recommendations, @Price, @Pay)", con);

            // Vet_Name, Owner, Mobile, Pet
            cmd.Parameters.AddWithValue("@Vet_Name", vn);
            cmd.Parameters.AddWithValue("@Owner", ow);
            cmd.Parameters.AddWithValue("@Mobile", mb);
            cmd.Parameters.AddWithValue("@Pet", pt);
            //            cmd.Parameters.AddWithValue("@Date", DateTime.Now);
            cmd.Parameters.AddWithValue("@Date", dat);

            // GIT
            cmd.Parameters.AddWithValue("@Normal_GIT", N_GIT);
            cmd.Parameters.AddWithValue("@Abn_Feces_GIT", AF_GIT);
            cmd.Parameters.AddWithValue("@Excessive_Gas_GIT", EG_GIT);
            cmd.Parameters.AddWithValue("@Parasites_GIT", P_GIT);
            cmd.Parameters.AddWithValue("@Vomiting_GIT", V_GIT);
            cmd.Parameters.AddWithValue("@Diarrhea_GIT", D_GIT);
            cmd.Parameters.AddWithValue("@Anorexia_GIT", An_GIT);
            cmd.Parameters.AddWithValue("@Other_GIT", txt_Other_GIT.Text);

            // US (Urogenital System)
            cmd.Parameters.AddWithValue("@Normal_US", N_US);
            cmd.Parameters.AddWithValue("@Abnormal_Urination_US", AU_US);
            cmd.Parameters.AddWithValue("@Anal_Sacs_US", AS_US);
            cmd.Parameters.AddWithValue("@Genital_Discharge_US", GD_US);
            cmd.Parameters.AddWithValue("@Abn_Testicles_US", AT_US);
            cmd.Parameters.AddWithValue("@Mammary_Abn_US", MA_US);
            cmd.Parameters.AddWithValue("@Other_US", txt_Other_US.Text);

            // D (Diet)
            cmd.Parameters.AddWithValue("@Excellent_D", Ex_D);
            cmd.Parameters.AddWithValue("@Good_D", Go_D);
            cmd.Parameters.AddWithValue("@Change_Diet_D", CD_D);
            cmd.Parameters.AddWithValue("@Vitamins_needed_D", Vn_D);
            cmd.Parameters.AddWithValue("@Recommendations_D", rtxt_Recommendations_D.Text);

            // 
            cmd.Parameters.AddWithValue("@Diagnosis_Explanations", rtxt_Diagnosis_Explanations.Text);

            // 
            cmd.Parameters.AddWithValue("@Recommendations", rtxt_Recommendations.Text);

            // Price & Pay
            cmd.Parameters.AddWithValue("@Price", txt_Price.Text);
            cmd.Parameters.AddWithValue("@Pay", txt_Pay.Text);

            cmd.ExecuteNonQuery();
            con.Close();

            this.Hide();
            HomePage HP = new HomePage(vn);
            HP.ShowDialog();
        }
    }
}