﻿namespace Professional_Vets
{
    partial class Search_Options
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Button_Search = new System.Windows.Forms.Button();
            this.rB_Vaccinations = new System.Windows.Forms.RadioButton();
            this.rB_Veterinarys = new System.Windows.Forms.RadioButton();
            this.label1 = new System.Windows.Forms.Label();
            this.rB_Boarding = new System.Windows.Forms.RadioButton();
            this.rB_Daily_Transactions = new System.Windows.Forms.RadioButton();
            this.SuspendLayout();
            // 
            // Button_Search
            // 
            this.Button_Search.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.Button_Search.Font = new System.Drawing.Font("Tahoma", 12F);
            this.Button_Search.Location = new System.Drawing.Point(113, 254);
            this.Button_Search.Name = "Button_Search";
            this.Button_Search.Size = new System.Drawing.Size(129, 38);
            this.Button_Search.TabIndex = 0;
            this.Button_Search.Text = "Search";
            this.Button_Search.UseVisualStyleBackColor = true;
            this.Button_Search.Click += new System.EventHandler(this.Button_Search_Click);
            // 
            // rB_Vaccinations
            // 
            this.rB_Vaccinations.AutoSize = true;
            this.rB_Vaccinations.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold);
            this.rB_Vaccinations.Location = new System.Drawing.Point(16, 98);
            this.rB_Vaccinations.Name = "rB_Vaccinations";
            this.rB_Vaccinations.Size = new System.Drawing.Size(112, 21);
            this.rB_Vaccinations.TabIndex = 1;
            this.rB_Vaccinations.TabStop = true;
            this.rB_Vaccinations.Text = "Vaccinations";
            this.rB_Vaccinations.UseVisualStyleBackColor = true;
            // 
            // rB_Veterinarys
            // 
            this.rB_Veterinarys.AutoSize = true;
            this.rB_Veterinarys.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold);
            this.rB_Veterinarys.Location = new System.Drawing.Point(15, 57);
            this.rB_Veterinarys.Name = "rB_Veterinarys";
            this.rB_Veterinarys.Size = new System.Drawing.Size(105, 21);
            this.rB_Veterinarys.TabIndex = 2;
            this.rB_Veterinarys.TabStop = true;
            this.rB_Veterinarys.Text = "Veterinarys";
            this.rB_Veterinarys.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold);
            this.label1.Location = new System.Drawing.Point(12, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(230, 19);
            this.label1.TabIndex = 3;
            this.label1.Text = "Where you want to Search:";
            // 
            // rB_Boarding
            // 
            this.rB_Boarding.AutoSize = true;
            this.rB_Boarding.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold);
            this.rB_Boarding.Location = new System.Drawing.Point(16, 139);
            this.rB_Boarding.Name = "rB_Boarding";
            this.rB_Boarding.Size = new System.Drawing.Size(89, 21);
            this.rB_Boarding.TabIndex = 4;
            this.rB_Boarding.TabStop = true;
            this.rB_Boarding.Text = "Boarding";
            this.rB_Boarding.UseVisualStyleBackColor = true;
            // 
            // rB_Daily_Transactions
            // 
            this.rB_Daily_Transactions.AutoSize = true;
            this.rB_Daily_Transactions.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold);
            this.rB_Daily_Transactions.Location = new System.Drawing.Point(15, 184);
            this.rB_Daily_Transactions.Name = "rB_Daily_Transactions";
            this.rB_Daily_Transactions.Size = new System.Drawing.Size(150, 21);
            this.rB_Daily_Transactions.TabIndex = 5;
            this.rB_Daily_Transactions.TabStop = true;
            this.rB_Daily_Transactions.Text = "Daily Transactions";
            this.rB_Daily_Transactions.UseVisualStyleBackColor = true;
            // 
            // Search_Options
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.ClientSize = new System.Drawing.Size(368, 326);
            this.Controls.Add(this.rB_Daily_Transactions);
            this.Controls.Add(this.rB_Boarding);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.rB_Veterinarys);
            this.Controls.Add(this.rB_Vaccinations);
            this.Controls.Add(this.Button_Search);
            this.Name = "Search_Options";
            this.Text = "Search Options";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Search_Options_FormClosing);
            this.Load += new System.EventHandler(this.Search_Options_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Button_Search;
        private System.Windows.Forms.RadioButton rB_Vaccinations;
        private System.Windows.Forms.RadioButton rB_Veterinarys;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RadioButton rB_Boarding;
        private System.Windows.Forms.RadioButton rB_Daily_Transactions;
    }
}