﻿namespace Professional_Vets
{
    partial class Physical_Examination1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Physical_Examination1));
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.ch_Normal_MLL = new System.Windows.Forms.CheckBox();
            this.ch_Lameness_MLL = new System.Windows.Forms.CheckBox();
            this.ch_Pain_on_Palpation_MLL = new System.Windows.Forms.CheckBox();
            this.cobo_Lameness_MLL = new System.Windows.Forms.ComboBox();
            this.cobo_PoP_MLL = new System.Windows.Forms.ComboBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.ch_Normal_MTG = new System.Windows.Forms.CheckBox();
            this.ch_Broken_MTG = new System.Windows.Forms.CheckBox();
            this.ch_Loose_MTG = new System.Windows.Forms.CheckBox();
            this.ch_Ulcers_Lesions_MTG = new System.Windows.Forms.CheckBox();
            this.ch_Pyorrhea_MTG = new System.Windows.Forms.CheckBox();
            this.ch_Stain_MTG = new System.Windows.Forms.CheckBox();
            this.ch_Tartar_Degree_MTG = new System.Windows.Forms.CheckBox();
            this.ch_Gingivitis_MTG = new System.Windows.Forms.CheckBox();
            this.cobo_Tartar_MTG = new System.Windows.Forms.ComboBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.ch_Normal_NAT = new System.Windows.Forms.CheckBox();
            this.ch_Nasal_Discharge_NAT = new System.Windows.Forms.CheckBox();
            this.ch_Inf_Throat_NAT = new System.Windows.Forms.CheckBox();
            this.ch_Inf_Tensile_NAT = new System.Windows.Forms.CheckBox();
            this.ch_Other_NAT = new System.Windows.Forms.CheckBox();
            this.txt_Other_NAT = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.ch_Normal_Sound_LU = new System.Windows.Forms.CheckBox();
            this.ch_Abnormal_Sound_LU = new System.Windows.Forms.CheckBox();
            this.ch_Breathing_Difficulty_LU = new System.Windows.Forms.CheckBox();
            this.ch_Coughing_LU = new System.Windows.Forms.CheckBox();
            this.ch_Congestion_LU = new System.Windows.Forms.CheckBox();
            this.ch_Other_LU = new System.Windows.Forms.CheckBox();
            this.txt_Other_LU = new System.Windows.Forms.TextBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel5 = new System.Windows.Forms.TableLayoutPanel();
            this.ch_Normal_AB = new System.Windows.Forms.CheckBox();
            this.ch_Enlarged_AB = new System.Windows.Forms.CheckBox();
            this.ch_Mass_AB = new System.Windows.Forms.CheckBox();
            this.ch_Fluid_AB = new System.Windows.Forms.CheckBox();
            this.ch_Other_AB = new System.Windows.Forms.CheckBox();
            this.txt_Other_AB = new System.Windows.Forms.TextBox();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel6 = new System.Windows.Forms.TableLayoutPanel();
            this.ch_Sounds_Normal_H = new System.Windows.Forms.CheckBox();
            this.ch_Arrhythmia_H = new System.Windows.Forms.CheckBox();
            this.ch_Murmur_H = new System.Windows.Forms.CheckBox();
            this.ch_Other_H = new System.Windows.Forms.CheckBox();
            this.txt_Other_H = new System.Windows.Forms.TextBox();
            this.circularButton3 = new Professional_Vets.CircularButton();
            this.circularButton1 = new Professional_Vets.CircularButton();
            this.groupBox4.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.tableLayoutPanel5.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.tableLayoutPanel6.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox4
            // 
            this.groupBox4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox4.AutoSize = true;
            this.groupBox4.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.groupBox4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.groupBox4.Controls.Add(this.tableLayoutPanel3);
            this.groupBox4.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.groupBox4.Location = new System.Drawing.Point(581, 22);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(206, 245);
            this.groupBox4.TabIndex = 7;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Mussuloskeletal";
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 2;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel3.Controls.Add(this.ch_Normal_MLL, 0, 0);
            this.tableLayoutPanel3.Controls.Add(this.ch_Lameness_MLL, 0, 1);
            this.tableLayoutPanel3.Controls.Add(this.ch_Pain_on_Palpation_MLL, 0, 2);
            this.tableLayoutPanel3.Controls.Add(this.cobo_Lameness_MLL, 1, 1);
            this.tableLayoutPanel3.Controls.Add(this.cobo_PoP_MLL, 1, 2);
            this.tableLayoutPanel3.Location = new System.Drawing.Point(6, 24);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 3;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(194, 202);
            this.tableLayoutPanel3.TabIndex = 1;
            // 
            // ch_Normal_MLL
            // 
            this.ch_Normal_MLL.AutoSize = true;
            this.ch_Normal_MLL.Location = new System.Drawing.Point(3, 3);
            this.ch_Normal_MLL.Name = "ch_Normal_MLL";
            this.ch_Normal_MLL.Size = new System.Drawing.Size(66, 17);
            this.ch_Normal_MLL.TabIndex = 0;
            this.ch_Normal_MLL.Text = "Normal";
            this.ch_Normal_MLL.UseVisualStyleBackColor = true;
            // 
            // ch_Lameness_MLL
            // 
            this.ch_Lameness_MLL.AutoSize = true;
            this.ch_Lameness_MLL.Location = new System.Drawing.Point(3, 26);
            this.ch_Lameness_MLL.Name = "ch_Lameness_MLL";
            this.ch_Lameness_MLL.Size = new System.Drawing.Size(83, 17);
            this.ch_Lameness_MLL.TabIndex = 1;
            this.ch_Lameness_MLL.Text = "Lameness";
            this.ch_Lameness_MLL.UseVisualStyleBackColor = true;
            this.ch_Lameness_MLL.CheckedChanged += new System.EventHandler(this.checkBox20_CheckedChanged);
            // 
            // ch_Pain_on_Palpation_MLL
            // 
            this.ch_Pain_on_Palpation_MLL.AutoSize = true;
            this.ch_Pain_on_Palpation_MLL.Dock = System.Windows.Forms.DockStyle.Top;
            this.ch_Pain_on_Palpation_MLL.Location = new System.Drawing.Point(3, 53);
            this.ch_Pain_on_Palpation_MLL.Name = "ch_Pain_on_Palpation_MLL";
            this.ch_Pain_on_Palpation_MLL.Size = new System.Drawing.Size(120, 19);
            this.ch_Pain_on_Palpation_MLL.TabIndex = 2;
            this.ch_Pain_on_Palpation_MLL.Text = "Pain on Palpation";
            this.ch_Pain_on_Palpation_MLL.UseCompatibleTextRendering = true;
            this.ch_Pain_on_Palpation_MLL.UseVisualStyleBackColor = true;
            this.ch_Pain_on_Palpation_MLL.CheckedChanged += new System.EventHandler(this.checkBox21_CheckedChanged);
            // 
            // cobo_Lameness_MLL
            // 
            this.cobo_Lameness_MLL.FormattingEnabled = true;
            this.cobo_Lameness_MLL.Items.AddRange(new object[] {
            "LF",
            "LH",
            "RF",
            "RH"});
            this.cobo_Lameness_MLL.Location = new System.Drawing.Point(129, 26);
            this.cobo_Lameness_MLL.Name = "cobo_Lameness_MLL";
            this.cobo_Lameness_MLL.Size = new System.Drawing.Size(63, 21);
            this.cobo_Lameness_MLL.TabIndex = 12;
            // 
            // cobo_PoP_MLL
            // 
            this.cobo_PoP_MLL.FormattingEnabled = true;
            this.cobo_PoP_MLL.Items.AddRange(new object[] {
            "LR",
            "LH",
            "RF",
            "RH"});
            this.cobo_PoP_MLL.Location = new System.Drawing.Point(129, 53);
            this.cobo_PoP_MLL.Name = "cobo_PoP_MLL";
            this.cobo_PoP_MLL.Size = new System.Drawing.Size(63, 21);
            this.cobo_PoP_MLL.TabIndex = 13;
            // 
            // groupBox3
            // 
            this.groupBox3.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.groupBox3.AutoSize = true;
            this.groupBox3.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.groupBox3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.groupBox3.Controls.Add(this.tableLayoutPanel2);
            this.groupBox3.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.groupBox3.Location = new System.Drawing.Point(295, 22);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(206, 245);
            this.groupBox3.TabIndex = 6;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Mouth, Teeth, Gums";
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 2;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel2.Controls.Add(this.ch_Normal_MTG, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.ch_Broken_MTG, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.ch_Loose_MTG, 0, 2);
            this.tableLayoutPanel2.Controls.Add(this.ch_Ulcers_Lesions_MTG, 0, 3);
            this.tableLayoutPanel2.Controls.Add(this.ch_Pyorrhea_MTG, 0, 4);
            this.tableLayoutPanel2.Controls.Add(this.ch_Stain_MTG, 0, 6);
            this.tableLayoutPanel2.Controls.Add(this.ch_Tartar_Degree_MTG, 0, 7);
            this.tableLayoutPanel2.Controls.Add(this.ch_Gingivitis_MTG, 0, 5);
            this.tableLayoutPanel2.Controls.Add(this.cobo_Tartar_MTG, 1, 7);
            this.tableLayoutPanel2.Location = new System.Drawing.Point(6, 24);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 8;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel2.Size = new System.Drawing.Size(194, 202);
            this.tableLayoutPanel2.TabIndex = 1;
            // 
            // ch_Normal_MTG
            // 
            this.ch_Normal_MTG.AutoSize = true;
            this.ch_Normal_MTG.Location = new System.Drawing.Point(3, 3);
            this.ch_Normal_MTG.Name = "ch_Normal_MTG";
            this.ch_Normal_MTG.Size = new System.Drawing.Size(66, 17);
            this.ch_Normal_MTG.TabIndex = 0;
            this.ch_Normal_MTG.Text = "Normal";
            this.ch_Normal_MTG.UseVisualStyleBackColor = true;
            // 
            // ch_Broken_MTG
            // 
            this.ch_Broken_MTG.AutoSize = true;
            this.ch_Broken_MTG.Location = new System.Drawing.Point(3, 26);
            this.ch_Broken_MTG.Name = "ch_Broken_MTG";
            this.ch_Broken_MTG.Size = new System.Drawing.Size(66, 17);
            this.ch_Broken_MTG.TabIndex = 1;
            this.ch_Broken_MTG.Text = "Broken";
            this.ch_Broken_MTG.UseVisualStyleBackColor = true;
            // 
            // ch_Loose_MTG
            // 
            this.ch_Loose_MTG.AutoSize = true;
            this.ch_Loose_MTG.Location = new System.Drawing.Point(3, 49);
            this.ch_Loose_MTG.Name = "ch_Loose_MTG";
            this.ch_Loose_MTG.Size = new System.Drawing.Size(59, 17);
            this.ch_Loose_MTG.TabIndex = 2;
            this.ch_Loose_MTG.Text = "Loose";
            this.ch_Loose_MTG.UseVisualStyleBackColor = true;
            // 
            // ch_Ulcers_Lesions_MTG
            // 
            this.ch_Ulcers_Lesions_MTG.AutoSize = true;
            this.ch_Ulcers_Lesions_MTG.Location = new System.Drawing.Point(3, 72);
            this.ch_Ulcers_Lesions_MTG.Name = "ch_Ulcers_Lesions_MTG";
            this.ch_Ulcers_Lesions_MTG.Size = new System.Drawing.Size(108, 19);
            this.ch_Ulcers_Lesions_MTG.TabIndex = 3;
            this.ch_Ulcers_Lesions_MTG.Text = "Ulcers/ Lesions";
            this.ch_Ulcers_Lesions_MTG.UseCompatibleTextRendering = true;
            this.ch_Ulcers_Lesions_MTG.UseVisualStyleBackColor = true;
            // 
            // ch_Pyorrhea_MTG
            // 
            this.ch_Pyorrhea_MTG.AutoSize = true;
            this.ch_Pyorrhea_MTG.Location = new System.Drawing.Point(3, 97);
            this.ch_Pyorrhea_MTG.Name = "ch_Pyorrhea_MTG";
            this.ch_Pyorrhea_MTG.Size = new System.Drawing.Size(78, 17);
            this.ch_Pyorrhea_MTG.TabIndex = 4;
            this.ch_Pyorrhea_MTG.Text = "Pyorrhea";
            this.ch_Pyorrhea_MTG.UseVisualStyleBackColor = true;
            // 
            // ch_Stain_MTG
            // 
            this.ch_Stain_MTG.AutoSize = true;
            this.ch_Stain_MTG.Location = new System.Drawing.Point(3, 143);
            this.ch_Stain_MTG.Name = "ch_Stain_MTG";
            this.ch_Stain_MTG.Size = new System.Drawing.Size(55, 17);
            this.ch_Stain_MTG.TabIndex = 6;
            this.ch_Stain_MTG.Text = "Stain";
            this.ch_Stain_MTG.UseVisualStyleBackColor = true;
            // 
            // ch_Tartar_Degree_MTG
            // 
            this.ch_Tartar_Degree_MTG.AutoSize = true;
            this.ch_Tartar_Degree_MTG.Dock = System.Windows.Forms.DockStyle.Top;
            this.ch_Tartar_Degree_MTG.Location = new System.Drawing.Point(3, 166);
            this.ch_Tartar_Degree_MTG.Name = "ch_Tartar_Degree_MTG";
            this.ch_Tartar_Degree_MTG.Size = new System.Drawing.Size(108, 19);
            this.ch_Tartar_Degree_MTG.TabIndex = 10;
            this.ch_Tartar_Degree_MTG.Text = "Tartar Degree";
            this.ch_Tartar_Degree_MTG.UseCompatibleTextRendering = true;
            this.ch_Tartar_Degree_MTG.UseVisualStyleBackColor = true;
            this.ch_Tartar_Degree_MTG.CheckedChanged += new System.EventHandler(this.checkBox23_CheckedChanged);
            // 
            // ch_Gingivitis_MTG
            // 
            this.ch_Gingivitis_MTG.AutoSize = true;
            this.ch_Gingivitis_MTG.Location = new System.Drawing.Point(3, 120);
            this.ch_Gingivitis_MTG.Name = "ch_Gingivitis_MTG";
            this.ch_Gingivitis_MTG.Size = new System.Drawing.Size(78, 17);
            this.ch_Gingivitis_MTG.TabIndex = 5;
            this.ch_Gingivitis_MTG.Text = "Gingivitis";
            this.ch_Gingivitis_MTG.UseVisualStyleBackColor = true;
            // 
            // cobo_Tartar_MTG
            // 
            this.cobo_Tartar_MTG.FormattingEnabled = true;
            this.cobo_Tartar_MTG.Items.AddRange(new object[] {
            "Major",
            "Moderate",
            "Minor"});
            this.cobo_Tartar_MTG.Location = new System.Drawing.Point(117, 166);
            this.cobo_Tartar_MTG.Name = "cobo_Tartar_MTG";
            this.cobo_Tartar_MTG.Size = new System.Drawing.Size(71, 21);
            this.cobo_Tartar_MTG.TabIndex = 18;
            // 
            // groupBox2
            // 
            this.groupBox2.AutoSize = true;
            this.groupBox2.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.groupBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.groupBox2.Controls.Add(this.tableLayoutPanel1);
            this.groupBox2.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.groupBox2.Location = new System.Drawing.Point(21, 22);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(206, 245);
            this.groupBox2.TabIndex = 5;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Nose and Throat";
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.Controls.Add(this.ch_Normal_NAT, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.ch_Nasal_Discharge_NAT, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.ch_Inf_Throat_NAT, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.ch_Inf_Tensile_NAT, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.ch_Other_NAT, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.txt_Other_NAT, 1, 4);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(6, 24);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 5;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.Size = new System.Drawing.Size(194, 202);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // ch_Normal_NAT
            // 
            this.ch_Normal_NAT.AutoSize = true;
            this.ch_Normal_NAT.Location = new System.Drawing.Point(3, 3);
            this.ch_Normal_NAT.Name = "ch_Normal_NAT";
            this.ch_Normal_NAT.Size = new System.Drawing.Size(66, 17);
            this.ch_Normal_NAT.TabIndex = 0;
            this.ch_Normal_NAT.Text = "Normal";
            this.ch_Normal_NAT.UseVisualStyleBackColor = true;
            // 
            // ch_Nasal_Discharge_NAT
            // 
            this.ch_Nasal_Discharge_NAT.AutoSize = true;
            this.ch_Nasal_Discharge_NAT.Dock = System.Windows.Forms.DockStyle.Left;
            this.ch_Nasal_Discharge_NAT.Location = new System.Drawing.Point(3, 26);
            this.ch_Nasal_Discharge_NAT.Name = "ch_Nasal_Discharge_NAT";
            this.ch_Nasal_Discharge_NAT.Size = new System.Drawing.Size(112, 19);
            this.ch_Nasal_Discharge_NAT.TabIndex = 1;
            this.ch_Nasal_Discharge_NAT.Text = "Nasal Discharge";
            this.ch_Nasal_Discharge_NAT.UseCompatibleTextRendering = true;
            this.ch_Nasal_Discharge_NAT.UseVisualStyleBackColor = true;
            // 
            // ch_Inf_Throat_NAT
            // 
            this.ch_Inf_Throat_NAT.AutoSize = true;
            this.ch_Inf_Throat_NAT.Location = new System.Drawing.Point(3, 51);
            this.ch_Inf_Throat_NAT.Name = "ch_Inf_Throat_NAT";
            this.ch_Inf_Throat_NAT.Size = new System.Drawing.Size(86, 17);
            this.ch_Inf_Throat_NAT.TabIndex = 2;
            this.ch_Inf_Throat_NAT.Text = "Inf. Throat";
            this.ch_Inf_Throat_NAT.UseVisualStyleBackColor = true;
            // 
            // ch_Inf_Tensile_NAT
            // 
            this.ch_Inf_Tensile_NAT.AutoSize = true;
            this.ch_Inf_Tensile_NAT.Location = new System.Drawing.Point(3, 74);
            this.ch_Inf_Tensile_NAT.Name = "ch_Inf_Tensile_NAT";
            this.ch_Inf_Tensile_NAT.Size = new System.Drawing.Size(88, 17);
            this.ch_Inf_Tensile_NAT.TabIndex = 3;
            this.ch_Inf_Tensile_NAT.Text = "Inf. Tensile";
            this.ch_Inf_Tensile_NAT.UseVisualStyleBackColor = true;
            // 
            // ch_Other_NAT
            // 
            this.ch_Other_NAT.AutoSize = true;
            this.ch_Other_NAT.Location = new System.Drawing.Point(3, 97);
            this.ch_Other_NAT.Name = "ch_Other_NAT";
            this.ch_Other_NAT.Size = new System.Drawing.Size(58, 17);
            this.ch_Other_NAT.TabIndex = 10;
            this.ch_Other_NAT.Text = "Other";
            this.ch_Other_NAT.UseVisualStyleBackColor = true;
            this.ch_Other_NAT.CheckedChanged += new System.EventHandler(this.checkBox12_CheckedChanged);
            // 
            // txt_Other_NAT
            // 
            this.txt_Other_NAT.Location = new System.Drawing.Point(121, 97);
            this.txt_Other_NAT.Name = "txt_Other_NAT";
            this.txt_Other_NAT.Size = new System.Drawing.Size(67, 20);
            this.txt_Other_NAT.TabIndex = 11;
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox1.AutoSize = true;
            this.groupBox1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.groupBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.groupBox1.Controls.Add(this.tableLayoutPanel4);
            this.groupBox1.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.groupBox1.Location = new System.Drawing.Point(579, 300);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(206, 245);
            this.groupBox1.TabIndex = 10;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Lungs";
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.ColumnCount = 2;
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel4.Controls.Add(this.ch_Normal_Sound_LU, 0, 0);
            this.tableLayoutPanel4.Controls.Add(this.ch_Abnormal_Sound_LU, 0, 1);
            this.tableLayoutPanel4.Controls.Add(this.ch_Breathing_Difficulty_LU, 0, 5);
            this.tableLayoutPanel4.Controls.Add(this.ch_Coughing_LU, 0, 6);
            this.tableLayoutPanel4.Controls.Add(this.ch_Congestion_LU, 0, 7);
            this.tableLayoutPanel4.Controls.Add(this.ch_Other_LU, 0, 8);
            this.tableLayoutPanel4.Controls.Add(this.txt_Other_LU, 1, 8);
            this.tableLayoutPanel4.Location = new System.Drawing.Point(6, 24);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 9;
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel4.Size = new System.Drawing.Size(194, 202);
            this.tableLayoutPanel4.TabIndex = 1;
            // 
            // ch_Normal_Sound_LU
            // 
            this.ch_Normal_Sound_LU.AutoSize = true;
            this.ch_Normal_Sound_LU.Location = new System.Drawing.Point(3, 3);
            this.ch_Normal_Sound_LU.Name = "ch_Normal_Sound_LU";
            this.ch_Normal_Sound_LU.Size = new System.Drawing.Size(104, 17);
            this.ch_Normal_Sound_LU.TabIndex = 0;
            this.ch_Normal_Sound_LU.Text = "Normal Sound";
            this.ch_Normal_Sound_LU.UseVisualStyleBackColor = true;
            // 
            // ch_Abnormal_Sound_LU
            // 
            this.ch_Abnormal_Sound_LU.AutoSize = true;
            this.ch_Abnormal_Sound_LU.Location = new System.Drawing.Point(3, 26);
            this.ch_Abnormal_Sound_LU.Name = "ch_Abnormal_Sound_LU";
            this.ch_Abnormal_Sound_LU.Size = new System.Drawing.Size(119, 17);
            this.ch_Abnormal_Sound_LU.TabIndex = 1;
            this.ch_Abnormal_Sound_LU.Text = "Abnormal Sound";
            this.ch_Abnormal_Sound_LU.UseVisualStyleBackColor = true;
            // 
            // ch_Breathing_Difficulty_LU
            // 
            this.ch_Breathing_Difficulty_LU.AutoSize = true;
            this.ch_Breathing_Difficulty_LU.Dock = System.Windows.Forms.DockStyle.Top;
            this.ch_Breathing_Difficulty_LU.Location = new System.Drawing.Point(3, 49);
            this.ch_Breathing_Difficulty_LU.Name = "ch_Breathing_Difficulty_LU";
            this.ch_Breathing_Difficulty_LU.Size = new System.Drawing.Size(131, 19);
            this.ch_Breathing_Difficulty_LU.TabIndex = 2;
            this.ch_Breathing_Difficulty_LU.Text = "Breathing Difficulty";
            this.ch_Breathing_Difficulty_LU.UseCompatibleTextRendering = true;
            this.ch_Breathing_Difficulty_LU.UseVisualStyleBackColor = true;
            // 
            // ch_Coughing_LU
            // 
            this.ch_Coughing_LU.AutoSize = true;
            this.ch_Coughing_LU.Location = new System.Drawing.Point(3, 74);
            this.ch_Coughing_LU.Name = "ch_Coughing_LU";
            this.ch_Coughing_LU.Size = new System.Drawing.Size(78, 17);
            this.ch_Coughing_LU.TabIndex = 3;
            this.ch_Coughing_LU.Text = "Coughing";
            this.ch_Coughing_LU.UseVisualStyleBackColor = true;
            // 
            // ch_Congestion_LU
            // 
            this.ch_Congestion_LU.AutoSize = true;
            this.ch_Congestion_LU.Location = new System.Drawing.Point(3, 97);
            this.ch_Congestion_LU.Name = "ch_Congestion_LU";
            this.ch_Congestion_LU.Size = new System.Drawing.Size(89, 17);
            this.ch_Congestion_LU.TabIndex = 4;
            this.ch_Congestion_LU.Text = "Congestion";
            this.ch_Congestion_LU.UseVisualStyleBackColor = true;
            // 
            // ch_Other_LU
            // 
            this.ch_Other_LU.AutoSize = true;
            this.ch_Other_LU.Location = new System.Drawing.Point(3, 120);
            this.ch_Other_LU.Name = "ch_Other_LU";
            this.ch_Other_LU.Size = new System.Drawing.Size(58, 17);
            this.ch_Other_LU.TabIndex = 5;
            this.ch_Other_LU.Text = "Other";
            this.ch_Other_LU.UseVisualStyleBackColor = true;
            this.ch_Other_LU.CheckedChanged += new System.EventHandler(this.checkBox27_CheckedChanged);
            // 
            // txt_Other_LU
            // 
            this.txt_Other_LU.Location = new System.Drawing.Point(140, 120);
            this.txt_Other_LU.Name = "txt_Other_LU";
            this.txt_Other_LU.Size = new System.Drawing.Size(52, 20);
            this.txt_Other_LU.TabIndex = 12;
            // 
            // groupBox5
            // 
            this.groupBox5.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.groupBox5.AutoSize = true;
            this.groupBox5.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.groupBox5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.groupBox5.Controls.Add(this.tableLayoutPanel5);
            this.groupBox5.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.groupBox5.Location = new System.Drawing.Point(295, 300);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(206, 245);
            this.groupBox5.TabIndex = 9;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Abdomen";
            // 
            // tableLayoutPanel5
            // 
            this.tableLayoutPanel5.ColumnCount = 2;
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel5.Controls.Add(this.ch_Normal_AB, 0, 0);
            this.tableLayoutPanel5.Controls.Add(this.ch_Enlarged_AB, 0, 1);
            this.tableLayoutPanel5.Controls.Add(this.ch_Mass_AB, 0, 2);
            this.tableLayoutPanel5.Controls.Add(this.ch_Fluid_AB, 0, 3);
            this.tableLayoutPanel5.Controls.Add(this.ch_Other_AB, 0, 4);
            this.tableLayoutPanel5.Controls.Add(this.txt_Other_AB, 1, 4);
            this.tableLayoutPanel5.Location = new System.Drawing.Point(6, 24);
            this.tableLayoutPanel5.Name = "tableLayoutPanel5";
            this.tableLayoutPanel5.RowCount = 5;
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel5.Size = new System.Drawing.Size(194, 202);
            this.tableLayoutPanel5.TabIndex = 1;
            // 
            // ch_Normal_AB
            // 
            this.ch_Normal_AB.AutoSize = true;
            this.ch_Normal_AB.Cursor = System.Windows.Forms.Cursors.AppStarting;
            this.ch_Normal_AB.Location = new System.Drawing.Point(3, 3);
            this.ch_Normal_AB.Name = "ch_Normal_AB";
            this.ch_Normal_AB.Size = new System.Drawing.Size(66, 17);
            this.ch_Normal_AB.TabIndex = 0;
            this.ch_Normal_AB.Text = "Normal";
            this.ch_Normal_AB.UseVisualStyleBackColor = true;
            // 
            // ch_Enlarged_AB
            // 
            this.ch_Enlarged_AB.AutoSize = true;
            this.ch_Enlarged_AB.Location = new System.Drawing.Point(3, 26);
            this.ch_Enlarged_AB.Name = "ch_Enlarged_AB";
            this.ch_Enlarged_AB.Size = new System.Drawing.Size(75, 17);
            this.ch_Enlarged_AB.TabIndex = 1;
            this.ch_Enlarged_AB.Text = "Enlarged";
            this.ch_Enlarged_AB.UseVisualStyleBackColor = true;
            // 
            // ch_Mass_AB
            // 
            this.ch_Mass_AB.AutoSize = true;
            this.ch_Mass_AB.Location = new System.Drawing.Point(3, 49);
            this.ch_Mass_AB.Name = "ch_Mass_AB";
            this.ch_Mass_AB.Size = new System.Drawing.Size(55, 17);
            this.ch_Mass_AB.TabIndex = 2;
            this.ch_Mass_AB.Text = "Mass";
            this.ch_Mass_AB.UseVisualStyleBackColor = true;
            this.ch_Mass_AB.CheckedChanged += new System.EventHandler(this.checkBox10_CheckedChanged);
            // 
            // ch_Fluid_AB
            // 
            this.ch_Fluid_AB.AutoSize = true;
            this.ch_Fluid_AB.Location = new System.Drawing.Point(3, 72);
            this.ch_Fluid_AB.Name = "ch_Fluid_AB";
            this.ch_Fluid_AB.Size = new System.Drawing.Size(50, 19);
            this.ch_Fluid_AB.TabIndex = 3;
            this.ch_Fluid_AB.Text = "Fluid";
            this.ch_Fluid_AB.UseCompatibleTextRendering = true;
            this.ch_Fluid_AB.UseVisualStyleBackColor = true;
            // 
            // ch_Other_AB
            // 
            this.ch_Other_AB.AutoSize = true;
            this.ch_Other_AB.Location = new System.Drawing.Point(3, 97);
            this.ch_Other_AB.Name = "ch_Other_AB";
            this.ch_Other_AB.Size = new System.Drawing.Size(58, 17);
            this.ch_Other_AB.TabIndex = 4;
            this.ch_Other_AB.Text = "Other";
            this.ch_Other_AB.UseVisualStyleBackColor = true;
            this.ch_Other_AB.CheckedChanged += new System.EventHandler(this.checkBox22_CheckedChanged);
            // 
            // txt_Other_AB
            // 
            this.txt_Other_AB.Location = new System.Drawing.Point(84, 97);
            this.txt_Other_AB.Name = "txt_Other_AB";
            this.txt_Other_AB.Size = new System.Drawing.Size(79, 20);
            this.txt_Other_AB.TabIndex = 19;
            // 
            // groupBox6
            // 
            this.groupBox6.AutoSize = true;
            this.groupBox6.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.groupBox6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.groupBox6.Controls.Add(this.tableLayoutPanel6);
            this.groupBox6.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.groupBox6.Location = new System.Drawing.Point(21, 300);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(206, 245);
            this.groupBox6.TabIndex = 8;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Heart";
            // 
            // tableLayoutPanel6
            // 
            this.tableLayoutPanel6.ColumnCount = 2;
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel6.Controls.Add(this.ch_Sounds_Normal_H, 0, 0);
            this.tableLayoutPanel6.Controls.Add(this.ch_Arrhythmia_H, 0, 1);
            this.tableLayoutPanel6.Controls.Add(this.ch_Murmur_H, 0, 2);
            this.tableLayoutPanel6.Controls.Add(this.ch_Other_H, 0, 3);
            this.tableLayoutPanel6.Controls.Add(this.txt_Other_H, 1, 3);
            this.tableLayoutPanel6.Location = new System.Drawing.Point(6, 24);
            this.tableLayoutPanel6.Name = "tableLayoutPanel6";
            this.tableLayoutPanel6.RowCount = 4;
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel6.Size = new System.Drawing.Size(194, 202);
            this.tableLayoutPanel6.TabIndex = 0;
            // 
            // ch_Sounds_Normal_H
            // 
            this.ch_Sounds_Normal_H.AutoSize = true;
            this.ch_Sounds_Normal_H.Location = new System.Drawing.Point(3, 3);
            this.ch_Sounds_Normal_H.Name = "ch_Sounds_Normal_H";
            this.ch_Sounds_Normal_H.Size = new System.Drawing.Size(110, 17);
            this.ch_Sounds_Normal_H.TabIndex = 0;
            this.ch_Sounds_Normal_H.Text = "Sounds Normal";
            this.ch_Sounds_Normal_H.UseVisualStyleBackColor = true;
            // 
            // ch_Arrhythmia_H
            // 
            this.ch_Arrhythmia_H.AutoSize = true;
            this.ch_Arrhythmia_H.Dock = System.Windows.Forms.DockStyle.Left;
            this.ch_Arrhythmia_H.Location = new System.Drawing.Point(3, 26);
            this.ch_Arrhythmia_H.Name = "ch_Arrhythmia_H";
            this.ch_Arrhythmia_H.Size = new System.Drawing.Size(85, 19);
            this.ch_Arrhythmia_H.TabIndex = 1;
            this.ch_Arrhythmia_H.Text = "Arrhythmia";
            this.ch_Arrhythmia_H.UseCompatibleTextRendering = true;
            this.ch_Arrhythmia_H.UseVisualStyleBackColor = true;
            // 
            // ch_Murmur_H
            // 
            this.ch_Murmur_H.AutoSize = true;
            this.ch_Murmur_H.Location = new System.Drawing.Point(3, 51);
            this.ch_Murmur_H.Name = "ch_Murmur_H";
            this.ch_Murmur_H.Size = new System.Drawing.Size(71, 17);
            this.ch_Murmur_H.TabIndex = 2;
            this.ch_Murmur_H.Text = "Murmur";
            this.ch_Murmur_H.UseVisualStyleBackColor = true;
            // 
            // ch_Other_H
            // 
            this.ch_Other_H.AutoSize = true;
            this.ch_Other_H.Location = new System.Drawing.Point(3, 74);
            this.ch_Other_H.Name = "ch_Other_H";
            this.ch_Other_H.Size = new System.Drawing.Size(58, 17);
            this.ch_Other_H.TabIndex = 10;
            this.ch_Other_H.Text = "Other";
            this.ch_Other_H.UseVisualStyleBackColor = true;
            this.ch_Other_H.CheckedChanged += new System.EventHandler(this.checkBox32_CheckedChanged);
            // 
            // txt_Other_H
            // 
            this.txt_Other_H.Location = new System.Drawing.Point(119, 74);
            this.txt_Other_H.Name = "txt_Other_H";
            this.txt_Other_H.Size = new System.Drawing.Size(69, 20);
            this.txt_Other_H.TabIndex = 11;
            this.txt_Other_H.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // circularButton3
            // 
            this.circularButton3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.circularButton3.AutoSize = true;
            this.circularButton3.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.circularButton3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.circularButton3.FlatAppearance.BorderSize = 0;
            this.circularButton3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.circularButton3.Image = ((System.Drawing.Image)(resources.GetObject("circularButton3.Image")));
            this.circularButton3.Location = new System.Drawing.Point(725, 544);
            this.circularButton3.Name = "circularButton3";
            this.circularButton3.Size = new System.Drawing.Size(56, 56);
            this.circularButton3.TabIndex = 36;
            this.circularButton3.UseVisualStyleBackColor = true;
            this.circularButton3.Click += new System.EventHandler(this.circularButton3_Click);
            // 
            // circularButton1
            // 
            this.circularButton1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.circularButton1.AutoSize = true;
            this.circularButton1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.circularButton1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.circularButton1.FlatAppearance.BorderSize = 0;
            this.circularButton1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.circularButton1.Image = ((System.Drawing.Image)(resources.GetObject("circularButton1.Image")));
            this.circularButton1.Location = new System.Drawing.Point(669, 544);
            this.circularButton1.Name = "circularButton1";
            this.circularButton1.Size = new System.Drawing.Size(56, 56);
            this.circularButton1.TabIndex = 34;
            this.circularButton1.UseVisualStyleBackColor = true;
            this.circularButton1.Click += new System.EventHandler(this.circularButton1_Click);
            // 
            // Physical_Examination1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.ClientSize = new System.Drawing.Size(800, 612);
            this.Controls.Add(this.circularButton3);
            this.Controls.Add(this.circularButton1);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox6);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Name = "Physical_Examination1";
            this.Text = "Physical_Examination";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Physical_Examination1_FormClosing);
            this.Load += new System.EventHandler(this.Physical_Examination1_Load);
            this.groupBox4.ResumeLayout(false);
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel3.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.tableLayoutPanel4.ResumeLayout(false);
            this.tableLayoutPanel4.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.tableLayoutPanel5.ResumeLayout(false);
            this.tableLayoutPanel5.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.tableLayoutPanel6.ResumeLayout(false);
            this.tableLayoutPanel6.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.CheckBox ch_Normal_MLL;
        private System.Windows.Forms.CheckBox ch_Pain_on_Palpation_MLL;
        private System.Windows.Forms.ComboBox cobo_Lameness_MLL;
        private System.Windows.Forms.ComboBox cobo_PoP_MLL;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.CheckBox ch_Broken_MTG;
        private System.Windows.Forms.CheckBox ch_Loose_MTG;
        private System.Windows.Forms.CheckBox ch_Ulcers_Lesions_MTG;
        private System.Windows.Forms.CheckBox ch_Pyorrhea_MTG;
        private System.Windows.Forms.CheckBox ch_Stain_MTG;
        private System.Windows.Forms.CheckBox ch_Tartar_Degree_MTG;
        private System.Windows.Forms.CheckBox ch_Gingivitis_MTG;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.CheckBox ch_Normal_NAT;
        private System.Windows.Forms.CheckBox ch_Nasal_Discharge_NAT;
        private System.Windows.Forms.CheckBox ch_Inf_Throat_NAT;
        private System.Windows.Forms.CheckBox ch_Inf_Tensile_NAT;
        private System.Windows.Forms.CheckBox ch_Other_NAT;
        private System.Windows.Forms.TextBox txt_Other_NAT;
        private System.Windows.Forms.CheckBox ch_Normal_MTG;
        private System.Windows.Forms.ComboBox cobo_Tartar_MTG;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel4;
        private System.Windows.Forms.CheckBox ch_Normal_Sound_LU;
        private System.Windows.Forms.CheckBox ch_Abnormal_Sound_LU;
        private System.Windows.Forms.CheckBox ch_Breathing_Difficulty_LU;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel5;
        private System.Windows.Forms.CheckBox ch_Normal_AB;
        private System.Windows.Forms.CheckBox ch_Enlarged_AB;
        private System.Windows.Forms.CheckBox ch_Mass_AB;
        private System.Windows.Forms.CheckBox ch_Fluid_AB;
        private System.Windows.Forms.CheckBox ch_Other_AB;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel6;
        private System.Windows.Forms.CheckBox ch_Sounds_Normal_H;
        private System.Windows.Forms.CheckBox ch_Arrhythmia_H;
        private System.Windows.Forms.CheckBox ch_Murmur_H;
        private System.Windows.Forms.CheckBox ch_Other_H;
        private System.Windows.Forms.TextBox txt_Other_H;
        private System.Windows.Forms.TextBox txt_Other_AB;
        private System.Windows.Forms.CheckBox ch_Coughing_LU;
        private System.Windows.Forms.CheckBox ch_Congestion_LU;
        private System.Windows.Forms.CheckBox ch_Other_LU;
        private System.Windows.Forms.TextBox txt_Other_LU;
        private CircularButton circularButton3;
        private CircularButton circularButton1;
        private System.Windows.Forms.CheckBox ch_Lameness_MLL;
    }
}