﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Professional_Vets
{
    public partial class Search_Options : Form
    {
        String vn;

        public Search_Options(String role)
        {
            InitializeComponent();
            vn = role;
        }

        private void Button_Search_Click(object sender, EventArgs e)
        {
            if (rB_Vaccinations.Checked == true)
            {
                this.Hide();
                Search_in_Vaccination SVA = new Search_in_Vaccination(vn);
                SVA.ShowDialog();
            }
            else if (rB_Veterinarys.Checked == true)
            {
                this.Hide();
                Search_in_Veterinary SVE = new Search_in_Veterinary(vn);
                SVE.ShowDialog();
            }
            else if (rB_Boarding.Checked == true)
            {
                this.Hide();
                Search_in_Boarding SBr = new Search_in_Boarding(vn);
                SBr.ShowDialog();
            }
            else if (rB_Daily_Transactions.Checked == true)
            {
                if(vn != "Atahat")
                {
                    this.Hide();
                    Today_Transactions TT = new Today_Transactions(vn);
                    TT.ShowDialog();
                }
                else
                {
                    this.Hide();
                    Search_in_Daily_Transactions SDT = new Search_in_Daily_Transactions(vn);
                    SDT.ShowDialog();
                }
                
            }

        }

        private void Search_Options_Load(object sender, EventArgs e)
        {
           
        }

        private void Search_Options_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.Hide();
            HomePage HP = new HomePage(vn);
            HP.ShowDialog();
        }
    }
}
