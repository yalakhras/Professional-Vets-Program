﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Professional_Vets
{
    public partial class Search_in_Boarding : Form
    {
        String vn;

        public static SqlConnection con = new SqlConnection(Properties.Settings.Default.Database1ConnectionString);

        String Id;
        int Id1;
        int delete_Id;


        public Search_in_Boarding(String role)
        {
            InitializeComponent();
            vn = role;
        }

        private void circularButton1_Click(object sender, EventArgs e)
        {
            this.Hide();
            HomePage HP = new HomePage(vn);
            HP.ShowDialog();
        }

        private void Search_in_Boarding_Load(object sender, EventArgs e)
        {
            if (con.State == ConnectionState.Open)
            {
                con.Close();
            }

            con.Open();
            fill_grid();
        }

        public void fill_grid()
        {
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from Boarding";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void txt_search_TextChanged(object sender, EventArgs e)
        {
            con = new SqlConnection(Properties.Settings.Default.Database1ConnectionString);
            con.Open();

            SqlDataAdapter dataAdp = new SqlDataAdapter("select * from Boarding where Owner like '" + txt_search.Text + "%'", con);
            DataTable dt = new DataTable("Boarding");
            dataAdp.Fill(dt);
            dataGridView1.DataSource = dt;
            
            
        }

        private void Search_in_Boarding_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.Hide();
            HomePage HP = new HomePage(vn);
            HP.ShowDialog();
        }


        private void dataGridView1_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            Id = dataGridView1.Rows[e.RowIndex].Cells["No"].Value.ToString();
            if(Id == "")
            {
                Id1 = 0;
            }

            else
            {
                Id1 = Convert.ToInt32(dataGridView1.Rows[e.RowIndex].Cells["No"].Value.ToString());
            }

            if (Id1 == 0)
            {
                SqlCommand cmd = con.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "Insert into Boarding Vaues ('" + dataGridView1.Rows[e.RowIndex].Cells["Pet"].Value.ToString() + "', '" + dataGridView1.Rows[e.RowIndex].Cells["Age"].Value.ToString() + "', '" + dataGridView1.Rows[e.RowIndex].Cells["Species"].Value.ToString() + "', '" + dataGridView1.Rows[e.RowIndex].Cells["Breed"].Value.ToString() + "', '" + dataGridView1.Rows[e.RowIndex].Cells["Sex"].Value.ToString() + "', '" + dataGridView1.Rows[e.RowIndex].Cells["Color_Hair"].Value.ToString() + "', '" + dataGridView1.Rows[e.RowIndex].Cells["Owner"].Value.ToString() + "', '" + dataGridView1.Rows[e.RowIndex].Cells["Address"].Value.ToString() + "', '" + dataGridView1.Rows[e.RowIndex].Cells["Mobile"].Value.ToString() + "', '" + dataGridView1.Rows[e.RowIndex].Cells["Email"].Value.ToString() + "', '" + dataGridView1.Rows[e.RowIndex].Cells["Number_of_Boarding_Days"].Value.ToString() + "', '" + dataGridView1.Rows[e.RowIndex].Cells["Food"].Value.ToString() + "', '" + dataGridView1.Rows[e.RowIndex].Cells["Medications"].Value.ToString() + "', '" + dataGridView1.Rows[e.RowIndex].Cells["Other"].Value.ToString() + "')";

                cmd.ExecuteNonQuery();
                fill_grid();
            }

            else
            {
                SqlCommand cmd = con.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "Update Boarding set Pet = '" + dataGridView1.Rows[e.RowIndex].Cells["Pet"].Value.ToString() + "', Age = '" + dataGridView1.Rows[e.RowIndex].Cells["Age"].Value.ToString() + "', Species = '" + dataGridView1.Rows[e.RowIndex].Cells["Species"].Value.ToString() + "', Breed = '" + dataGridView1.Rows[e.RowIndex].Cells["Breed"].Value.ToString() + "', Sex = '" + dataGridView1.Rows[e.RowIndex].Cells["Sex"].Value.ToString() + "', Color_Hair = '" + dataGridView1.Rows[e.RowIndex].Cells["Color_Hair"].Value.ToString() + "', Owner = '" + dataGridView1.Rows[e.RowIndex].Cells["Owner"].Value.ToString() + "', Address = '" + dataGridView1.Rows[e.RowIndex].Cells["Address"].Value.ToString() + "', Mobile = '" + dataGridView1.Rows[e.RowIndex].Cells["Mobile"].Value.ToString() + "', Email = '" + dataGridView1.Rows[e.RowIndex].Cells["Email"].Value.ToString() + "', Number_of_Boarding_Days = '" + dataGridView1.Rows[e.RowIndex].Cells["Number_of_Boarding_Days"].Value.ToString() + "', Food = '" + dataGridView1.Rows[e.RowIndex].Cells["Food"].Value.ToString() + "', Medications = '" + dataGridView1.Rows[e.RowIndex].Cells["Medications"].Value.ToString() + "', Other = '" + dataGridView1.Rows[e.RowIndex].Cells["Other"].Value.ToString() + "' Where No= "+ Id1 + ""; 
                
                cmd.ExecuteNonQuery();

                MessageBox.Show("The Data was Updated");
                fill_grid();

            }
        }

        private void deleteRecordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "Delete from Boarding Where No="+ delete_Id + "";

            MessageBox.Show("Selected Row was Deleted");
            cmd.ExecuteNonQuery();
            fill_grid();
        }

        private void dataGridView1_CellMouseUp(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                delete_Id = Convert.ToInt32(dataGridView1.Rows[e.RowIndex].Cells["No"].Value.ToString());
                this.contextMenuStrip1.Show(this.dataGridView1, e.Location);
                contextMenuStrip1.Show(Cursor.Position);
            }
        }
    }
}
