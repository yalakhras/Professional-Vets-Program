﻿namespace Professional_Vets
{
    partial class Worn_and_Flea_Control
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Worn_and_Flea_Control));
            this.button12 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.rtxt_Notes_WFC = new System.Windows.Forms.RichTextBox();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.NDate1_WFC = new System.Windows.Forms.DateTimePicker();
            this.Date1_WFC = new System.Windows.Forms.DateTimePicker();
            this.Dr_Name4_WFC = new System.Windows.Forms.TextBox();
            this.Dr_Name3_WFC = new System.Windows.Forms.TextBox();
            this.Dr_Name2_WFC = new System.Windows.Forms.TextBox();
            this.VB2_WFC = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.VB1_WFC = new System.Windows.Forms.TextBox();
            this.VB3_WFC = new System.Windows.Forms.TextBox();
            this.VB4_WFC = new System.Windows.Forms.TextBox();
            this.Dr_Name1_WFC = new System.Windows.Forms.TextBox();
            this.Date2_WFC = new System.Windows.Forms.DateTimePicker();
            this.Date3_WFC = new System.Windows.Forms.DateTimePicker();
            this.Date4_WFC = new System.Windows.Forms.DateTimePicker();
            this.NDate2_WFC = new System.Windows.Forms.DateTimePicker();
            this.NDate3_WFC = new System.Windows.Forms.DateTimePicker();
            this.NDate4_WFC = new System.Windows.Forms.DateTimePicker();
            this.Dr_Name5_WFC = new System.Windows.Forms.TextBox();
            this.NDate5_WFC = new System.Windows.Forms.DateTimePicker();
            this.VB6_WFC = new System.Windows.Forms.TextBox();
            this.Date6_WFC = new System.Windows.Forms.DateTimePicker();
            this.Dr_Name6_WFC = new System.Windows.Forms.TextBox();
            this.NDate6_WFC = new System.Windows.Forms.DateTimePicker();
            this.VB7_WFC = new System.Windows.Forms.TextBox();
            this.Date7_WFC = new System.Windows.Forms.DateTimePicker();
            this.Dr_Name7_WFC = new System.Windows.Forms.TextBox();
            this.NDate7_WFC = new System.Windows.Forms.DateTimePicker();
            this.VB5_WFC = new System.Windows.Forms.TextBox();
            this.Date5_WFC = new System.Windows.Forms.DateTimePicker();
            this.VB8_WFC = new System.Windows.Forms.TextBox();
            this.Date8_WFC = new System.Windows.Forms.DateTimePicker();
            this.Dr_Name8_WFC = new System.Windows.Forms.TextBox();
            this.NDate8_WFC = new System.Windows.Forms.DateTimePicker();
            this.VB9_WFC = new System.Windows.Forms.TextBox();
            this.Date9_WFC = new System.Windows.Forms.DateTimePicker();
            this.Dr_Name9_WFC = new System.Windows.Forms.TextBox();
            this.NDate9_WFC = new System.Windows.Forms.DateTimePicker();
            this.VB10_WFC = new System.Windows.Forms.TextBox();
            this.Date10_WFC = new System.Windows.Forms.DateTimePicker();
            this.Dr_Name10_WFC = new System.Windows.Forms.TextBox();
            this.NDate10_WFC = new System.Windows.Forms.DateTimePicker();
            this.VB11_WFC = new System.Windows.Forms.TextBox();
            this.Date11_WFC = new System.Windows.Forms.DateTimePicker();
            this.Dr_Name11_WFC = new System.Windows.Forms.TextBox();
            this.NDate11_WFC = new System.Windows.Forms.DateTimePicker();
            this.VB12_WFC = new System.Windows.Forms.TextBox();
            this.Date12_WFC = new System.Windows.Forms.DateTimePicker();
            this.Dr_Name12_WFC = new System.Windows.Forms.TextBox();
            this.NDate12_WFC = new System.Windows.Forms.DateTimePicker();
            this.circularButton2 = new Professional_Vets.CircularButton();
            this.circularButton5 = new Professional_Vets.CircularButton();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // button12
            // 
            this.button12.BackColor = System.Drawing.Color.Blue;
            this.button12.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button12.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.button12.ForeColor = System.Drawing.Color.White;
            this.button12.Location = new System.Drawing.Point(12, 30);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(336, 23);
            this.button12.TabIndex = 0;
            this.button12.Text = "Worn and Flea Control ";
            this.button12.UseCompatibleTextRendering = true;
            this.button12.UseVisualStyleBackColor = false;
            // 
            // button13
            // 
            this.button13.BackColor = System.Drawing.Color.Blue;
            this.button13.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button13.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.button13.ForeColor = System.Drawing.Color.White;
            this.button13.Location = new System.Drawing.Point(600, 35);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(307, 23);
            this.button13.TabIndex = 53;
            this.button13.Text = "Notes for Worn and Flea Control";
            this.button13.UseCompatibleTextRendering = true;
            this.button13.UseVisualStyleBackColor = false;
            // 
            // rtxt_Notes_WFC
            // 
            this.rtxt_Notes_WFC.Location = new System.Drawing.Point(600, 64);
            this.rtxt_Notes_WFC.Name = "rtxt_Notes_WFC";
            this.rtxt_Notes_WFC.Size = new System.Drawing.Size(307, 342);
            this.rtxt_Notes_WFC.TabIndex = 54;
            this.rtxt_Notes_WFC.Text = "Notes";
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.AutoSize = true;
            this.tableLayoutPanel1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.tableLayoutPanel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.tableLayoutPanel1.ColumnCount = 4;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.Controls.Add(this.NDate1_WFC, 3, 1);
            this.tableLayoutPanel1.Controls.Add(this.Date1_WFC, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.Dr_Name4_WFC, 2, 4);
            this.tableLayoutPanel1.Controls.Add(this.Dr_Name3_WFC, 2, 3);
            this.tableLayoutPanel1.Controls.Add(this.Dr_Name2_WFC, 2, 2);
            this.tableLayoutPanel1.Controls.Add(this.VB2_WFC, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.button1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.button2, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.button3, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.button4, 3, 0);
            this.tableLayoutPanel1.Controls.Add(this.VB1_WFC, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.VB3_WFC, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.VB4_WFC, 1, 4);
            this.tableLayoutPanel1.Controls.Add(this.Dr_Name1_WFC, 2, 1);
            this.tableLayoutPanel1.Controls.Add(this.Date2_WFC, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.Date3_WFC, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.Date4_WFC, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.NDate2_WFC, 3, 2);
            this.tableLayoutPanel1.Controls.Add(this.NDate3_WFC, 3, 3);
            this.tableLayoutPanel1.Controls.Add(this.NDate4_WFC, 3, 4);
            this.tableLayoutPanel1.Controls.Add(this.Dr_Name5_WFC, 2, 5);
            this.tableLayoutPanel1.Controls.Add(this.NDate5_WFC, 3, 5);
            this.tableLayoutPanel1.Controls.Add(this.VB6_WFC, 1, 6);
            this.tableLayoutPanel1.Controls.Add(this.Date6_WFC, 0, 6);
            this.tableLayoutPanel1.Controls.Add(this.Dr_Name6_WFC, 2, 6);
            this.tableLayoutPanel1.Controls.Add(this.NDate6_WFC, 3, 6);
            this.tableLayoutPanel1.Controls.Add(this.VB7_WFC, 1, 7);
            this.tableLayoutPanel1.Controls.Add(this.Date7_WFC, 0, 7);
            this.tableLayoutPanel1.Controls.Add(this.Dr_Name7_WFC, 2, 7);
            this.tableLayoutPanel1.Controls.Add(this.NDate7_WFC, 3, 7);
            this.tableLayoutPanel1.Controls.Add(this.VB5_WFC, 1, 5);
            this.tableLayoutPanel1.Controls.Add(this.Date5_WFC, 0, 5);
            this.tableLayoutPanel1.Controls.Add(this.VB8_WFC, 1, 8);
            this.tableLayoutPanel1.Controls.Add(this.Date8_WFC, 0, 8);
            this.tableLayoutPanel1.Controls.Add(this.Dr_Name8_WFC, 2, 8);
            this.tableLayoutPanel1.Controls.Add(this.NDate8_WFC, 3, 8);
            this.tableLayoutPanel1.Controls.Add(this.VB9_WFC, 1, 9);
            this.tableLayoutPanel1.Controls.Add(this.Date9_WFC, 0, 9);
            this.tableLayoutPanel1.Controls.Add(this.Dr_Name9_WFC, 2, 9);
            this.tableLayoutPanel1.Controls.Add(this.NDate9_WFC, 3, 9);
            this.tableLayoutPanel1.Controls.Add(this.VB10_WFC, 1, 10);
            this.tableLayoutPanel1.Controls.Add(this.Date10_WFC, 0, 10);
            this.tableLayoutPanel1.Controls.Add(this.Dr_Name10_WFC, 2, 10);
            this.tableLayoutPanel1.Controls.Add(this.NDate10_WFC, 3, 10);
            this.tableLayoutPanel1.Controls.Add(this.VB11_WFC, 1, 11);
            this.tableLayoutPanel1.Controls.Add(this.Date11_WFC, 0, 11);
            this.tableLayoutPanel1.Controls.Add(this.Dr_Name11_WFC, 2, 11);
            this.tableLayoutPanel1.Controls.Add(this.NDate11_WFC, 3, 11);
            this.tableLayoutPanel1.Controls.Add(this.VB12_WFC, 1, 12);
            this.tableLayoutPanel1.Controls.Add(this.Date12_WFC, 0, 12);
            this.tableLayoutPanel1.Controls.Add(this.Dr_Name12_WFC, 2, 12);
            this.tableLayoutPanel1.Controls.Add(this.NDate12_WFC, 3, 12);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(12, 59);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 13;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.Size = new System.Drawing.Size(503, 339);
            this.tableLayoutPanel1.TabIndex = 49;
            // 
            // NDate1_WFC
            // 
            this.NDate1_WFC.CustomFormat = " ";
            this.NDate1_WFC.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.NDate1_WFC.Location = new System.Drawing.Point(370, 30);
            this.NDate1_WFC.Name = "NDate1_WFC";
            this.NDate1_WFC.Size = new System.Drawing.Size(129, 20);
            this.NDate1_WFC.TabIndex = 8;
            this.NDate1_WFC.Value = new System.DateTime(2000, 1, 1, 0, 0, 0, 0);
            this.NDate1_WFC.ValueChanged += new System.EventHandler(this.NDate1_WFC_ValueChanged);
            // 
            // Date1_WFC
            // 
            this.Date1_WFC.CustomFormat = " ";
            this.Date1_WFC.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.Date1_WFC.Location = new System.Drawing.Point(3, 30);
            this.Date1_WFC.Name = "Date1_WFC";
            this.Date1_WFC.Size = new System.Drawing.Size(129, 20);
            this.Date1_WFC.TabIndex = 5;
            this.Date1_WFC.Value = new System.DateTime(2000, 1, 1, 0, 0, 0, 0);
            this.Date1_WFC.ValueChanged += new System.EventHandler(this.Date1_WFC_ValueChanged);
            // 
            // Dr_Name4_WFC
            // 
            this.Dr_Name4_WFC.Location = new System.Drawing.Point(290, 108);
            this.Dr_Name4_WFC.Name = "Dr_Name4_WFC";
            this.Dr_Name4_WFC.Size = new System.Drawing.Size(74, 20);
            this.Dr_Name4_WFC.TabIndex = 19;
            // 
            // Dr_Name3_WFC
            // 
            this.Dr_Name3_WFC.Location = new System.Drawing.Point(290, 82);
            this.Dr_Name3_WFC.Name = "Dr_Name3_WFC";
            this.Dr_Name3_WFC.Size = new System.Drawing.Size(74, 20);
            this.Dr_Name3_WFC.TabIndex = 15;
            // 
            // Dr_Name2_WFC
            // 
            this.Dr_Name2_WFC.Location = new System.Drawing.Point(290, 56);
            this.Dr_Name2_WFC.Name = "Dr_Name2_WFC";
            this.Dr_Name2_WFC.Size = new System.Drawing.Size(74, 20);
            this.Dr_Name2_WFC.TabIndex = 11;
            // 
            // VB2_WFC
            // 
            this.VB2_WFC.Dock = System.Windows.Forms.DockStyle.Fill;
            this.VB2_WFC.Location = new System.Drawing.Point(138, 56);
            this.VB2_WFC.Name = "VB2_WFC";
            this.VB2_WFC.Size = new System.Drawing.Size(146, 20);
            this.VB2_WFC.TabIndex = 10;
            this.VB2_WFC.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Blue;
            this.button1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button1.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(2, 2);
            this.button1.Margin = new System.Windows.Forms.Padding(2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(131, 23);
            this.button1.TabIndex = 1;
            this.button1.Text = "Date";
            this.button1.UseVisualStyleBackColor = false;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Blue;
            this.button2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button2.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.Location = new System.Drawing.Point(137, 2);
            this.button2.Margin = new System.Windows.Forms.Padding(2);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(148, 23);
            this.button2.TabIndex = 2;
            this.button2.Text = "Vaccine/ Batch No.";
            this.button2.UseVisualStyleBackColor = false;
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.Blue;
            this.button3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button3.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.button3.ForeColor = System.Drawing.Color.White;
            this.button3.Location = new System.Drawing.Point(289, 2);
            this.button3.Margin = new System.Windows.Forms.Padding(2);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(76, 23);
            this.button3.TabIndex = 3;
            this.button3.Text = "Dr. Name";
            this.button3.UseCompatibleTextRendering = true;
            this.button3.UseVisualStyleBackColor = false;
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.Blue;
            this.button4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button4.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.button4.ForeColor = System.Drawing.Color.White;
            this.button4.Location = new System.Drawing.Point(369, 2);
            this.button4.Margin = new System.Windows.Forms.Padding(2);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(132, 23);
            this.button4.TabIndex = 4;
            this.button4.Text = "Next Date";
            this.button4.UseVisualStyleBackColor = false;
            // 
            // VB1_WFC
            // 
            this.VB1_WFC.Dock = System.Windows.Forms.DockStyle.Fill;
            this.VB1_WFC.Location = new System.Drawing.Point(138, 30);
            this.VB1_WFC.Name = "VB1_WFC";
            this.VB1_WFC.Size = new System.Drawing.Size(146, 20);
            this.VB1_WFC.TabIndex = 6;
            this.VB1_WFC.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // VB3_WFC
            // 
            this.VB3_WFC.Dock = System.Windows.Forms.DockStyle.Fill;
            this.VB3_WFC.Location = new System.Drawing.Point(138, 82);
            this.VB3_WFC.Name = "VB3_WFC";
            this.VB3_WFC.Size = new System.Drawing.Size(146, 20);
            this.VB3_WFC.TabIndex = 14;
            this.VB3_WFC.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // VB4_WFC
            // 
            this.VB4_WFC.Dock = System.Windows.Forms.DockStyle.Fill;
            this.VB4_WFC.Location = new System.Drawing.Point(138, 108);
            this.VB4_WFC.Name = "VB4_WFC";
            this.VB4_WFC.Size = new System.Drawing.Size(146, 20);
            this.VB4_WFC.TabIndex = 18;
            this.VB4_WFC.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Dr_Name1_WFC
            // 
            this.Dr_Name1_WFC.Location = new System.Drawing.Point(290, 30);
            this.Dr_Name1_WFC.Name = "Dr_Name1_WFC";
            this.Dr_Name1_WFC.Size = new System.Drawing.Size(74, 20);
            this.Dr_Name1_WFC.TabIndex = 7;
            // 
            // Date2_WFC
            // 
            this.Date2_WFC.CustomFormat = " ";
            this.Date2_WFC.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.Date2_WFC.Location = new System.Drawing.Point(3, 56);
            this.Date2_WFC.Name = "Date2_WFC";
            this.Date2_WFC.Size = new System.Drawing.Size(129, 20);
            this.Date2_WFC.TabIndex = 9;
            this.Date2_WFC.Value = new System.DateTime(2000, 1, 1, 0, 0, 0, 0);
            this.Date2_WFC.ValueChanged += new System.EventHandler(this.Date2_WFC_ValueChanged);
            // 
            // Date3_WFC
            // 
            this.Date3_WFC.CustomFormat = " ";
            this.Date3_WFC.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.Date3_WFC.Location = new System.Drawing.Point(3, 82);
            this.Date3_WFC.Name = "Date3_WFC";
            this.Date3_WFC.Size = new System.Drawing.Size(129, 20);
            this.Date3_WFC.TabIndex = 13;
            this.Date3_WFC.Value = new System.DateTime(2000, 1, 1, 0, 0, 0, 0);
            this.Date3_WFC.ValueChanged += new System.EventHandler(this.Date3_WFC_ValueChanged);
            // 
            // Date4_WFC
            // 
            this.Date4_WFC.CustomFormat = " ";
            this.Date4_WFC.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.Date4_WFC.Location = new System.Drawing.Point(3, 108);
            this.Date4_WFC.Name = "Date4_WFC";
            this.Date4_WFC.Size = new System.Drawing.Size(129, 20);
            this.Date4_WFC.TabIndex = 17;
            this.Date4_WFC.Value = new System.DateTime(2000, 1, 1, 0, 0, 0, 0);
            this.Date4_WFC.ValueChanged += new System.EventHandler(this.Date4_WFC_ValueChanged);
            // 
            // NDate2_WFC
            // 
            this.NDate2_WFC.CustomFormat = " ";
            this.NDate2_WFC.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.NDate2_WFC.Location = new System.Drawing.Point(370, 56);
            this.NDate2_WFC.Name = "NDate2_WFC";
            this.NDate2_WFC.Size = new System.Drawing.Size(129, 20);
            this.NDate2_WFC.TabIndex = 12;
            this.NDate2_WFC.Value = new System.DateTime(2000, 1, 1, 0, 0, 0, 0);
            this.NDate2_WFC.ValueChanged += new System.EventHandler(this.NDate2_WFC_ValueChanged);
            // 
            // NDate3_WFC
            // 
            this.NDate3_WFC.CustomFormat = " ";
            this.NDate3_WFC.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.NDate3_WFC.Location = new System.Drawing.Point(370, 82);
            this.NDate3_WFC.Name = "NDate3_WFC";
            this.NDate3_WFC.Size = new System.Drawing.Size(129, 20);
            this.NDate3_WFC.TabIndex = 16;
            this.NDate3_WFC.Value = new System.DateTime(2000, 1, 1, 0, 0, 0, 0);
            this.NDate3_WFC.ValueChanged += new System.EventHandler(this.NDate3_WFC_ValueChanged);
            // 
            // NDate4_WFC
            // 
            this.NDate4_WFC.CustomFormat = " ";
            this.NDate4_WFC.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.NDate4_WFC.Location = new System.Drawing.Point(370, 108);
            this.NDate4_WFC.Name = "NDate4_WFC";
            this.NDate4_WFC.Size = new System.Drawing.Size(129, 20);
            this.NDate4_WFC.TabIndex = 20;
            this.NDate4_WFC.Value = new System.DateTime(2000, 1, 1, 0, 0, 0, 0);
            this.NDate4_WFC.ValueChanged += new System.EventHandler(this.NDate4_WFC_ValueChanged);
            // 
            // Dr_Name5_WFC
            // 
            this.Dr_Name5_WFC.Location = new System.Drawing.Point(290, 134);
            this.Dr_Name5_WFC.Name = "Dr_Name5_WFC";
            this.Dr_Name5_WFC.Size = new System.Drawing.Size(74, 20);
            this.Dr_Name5_WFC.TabIndex = 23;
            // 
            // NDate5_WFC
            // 
            this.NDate5_WFC.CustomFormat = " ";
            this.NDate5_WFC.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.NDate5_WFC.Location = new System.Drawing.Point(370, 134);
            this.NDate5_WFC.Name = "NDate5_WFC";
            this.NDate5_WFC.Size = new System.Drawing.Size(129, 20);
            this.NDate5_WFC.TabIndex = 24;
            this.NDate5_WFC.Value = new System.DateTime(2000, 1, 1, 0, 0, 0, 0);
            this.NDate5_WFC.ValueChanged += new System.EventHandler(this.NDate5_WFC_ValueChanged);
            // 
            // VB6_WFC
            // 
            this.VB6_WFC.Dock = System.Windows.Forms.DockStyle.Fill;
            this.VB6_WFC.Location = new System.Drawing.Point(138, 160);
            this.VB6_WFC.Name = "VB6_WFC";
            this.VB6_WFC.Size = new System.Drawing.Size(146, 20);
            this.VB6_WFC.TabIndex = 26;
            this.VB6_WFC.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Date6_WFC
            // 
            this.Date6_WFC.CustomFormat = " ";
            this.Date6_WFC.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.Date6_WFC.Location = new System.Drawing.Point(3, 160);
            this.Date6_WFC.Name = "Date6_WFC";
            this.Date6_WFC.Size = new System.Drawing.Size(129, 20);
            this.Date6_WFC.TabIndex = 25;
            this.Date6_WFC.Value = new System.DateTime(2000, 1, 1, 0, 0, 0, 0);
            this.Date6_WFC.ValueChanged += new System.EventHandler(this.Date6_WFC_ValueChanged);
            // 
            // Dr_Name6_WFC
            // 
            this.Dr_Name6_WFC.Location = new System.Drawing.Point(290, 160);
            this.Dr_Name6_WFC.Name = "Dr_Name6_WFC";
            this.Dr_Name6_WFC.Size = new System.Drawing.Size(74, 20);
            this.Dr_Name6_WFC.TabIndex = 27;
            // 
            // NDate6_WFC
            // 
            this.NDate6_WFC.CustomFormat = " ";
            this.NDate6_WFC.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.NDate6_WFC.Location = new System.Drawing.Point(370, 160);
            this.NDate6_WFC.Name = "NDate6_WFC";
            this.NDate6_WFC.Size = new System.Drawing.Size(129, 20);
            this.NDate6_WFC.TabIndex = 28;
            this.NDate6_WFC.Value = new System.DateTime(2000, 1, 1, 0, 0, 0, 0);
            this.NDate6_WFC.ValueChanged += new System.EventHandler(this.NDate6_WFC_ValueChanged);
            // 
            // VB7_WFC
            // 
            this.VB7_WFC.Dock = System.Windows.Forms.DockStyle.Fill;
            this.VB7_WFC.Location = new System.Drawing.Point(138, 186);
            this.VB7_WFC.Name = "VB7_WFC";
            this.VB7_WFC.Size = new System.Drawing.Size(146, 20);
            this.VB7_WFC.TabIndex = 30;
            this.VB7_WFC.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Date7_WFC
            // 
            this.Date7_WFC.CustomFormat = " ";
            this.Date7_WFC.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.Date7_WFC.Location = new System.Drawing.Point(3, 186);
            this.Date7_WFC.Name = "Date7_WFC";
            this.Date7_WFC.Size = new System.Drawing.Size(129, 20);
            this.Date7_WFC.TabIndex = 29;
            this.Date7_WFC.Value = new System.DateTime(2000, 1, 1, 0, 0, 0, 0);
            this.Date7_WFC.ValueChanged += new System.EventHandler(this.Date7_WFC_ValueChanged);
            // 
            // Dr_Name7_WFC
            // 
            this.Dr_Name7_WFC.Location = new System.Drawing.Point(290, 186);
            this.Dr_Name7_WFC.Name = "Dr_Name7_WFC";
            this.Dr_Name7_WFC.Size = new System.Drawing.Size(74, 20);
            this.Dr_Name7_WFC.TabIndex = 31;
            // 
            // NDate7_WFC
            // 
            this.NDate7_WFC.CustomFormat = " ";
            this.NDate7_WFC.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.NDate7_WFC.Location = new System.Drawing.Point(370, 186);
            this.NDate7_WFC.Name = "NDate7_WFC";
            this.NDate7_WFC.Size = new System.Drawing.Size(129, 20);
            this.NDate7_WFC.TabIndex = 32;
            this.NDate7_WFC.Value = new System.DateTime(2000, 1, 1, 0, 0, 0, 0);
            this.NDate7_WFC.ValueChanged += new System.EventHandler(this.NDate7_WFC_ValueChanged);
            // 
            // VB5_WFC
            // 
            this.VB5_WFC.Dock = System.Windows.Forms.DockStyle.Fill;
            this.VB5_WFC.Location = new System.Drawing.Point(138, 134);
            this.VB5_WFC.Name = "VB5_WFC";
            this.VB5_WFC.Size = new System.Drawing.Size(146, 20);
            this.VB5_WFC.TabIndex = 22;
            this.VB5_WFC.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Date5_WFC
            // 
            this.Date5_WFC.CustomFormat = " ";
            this.Date5_WFC.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.Date5_WFC.Location = new System.Drawing.Point(3, 134);
            this.Date5_WFC.Name = "Date5_WFC";
            this.Date5_WFC.Size = new System.Drawing.Size(129, 20);
            this.Date5_WFC.TabIndex = 21;
            this.Date5_WFC.Value = new System.DateTime(2000, 1, 1, 0, 0, 0, 0);
            this.Date5_WFC.ValueChanged += new System.EventHandler(this.Date5_WFC_ValueChanged);
            // 
            // VB8_WFC
            // 
            this.VB8_WFC.Dock = System.Windows.Forms.DockStyle.Fill;
            this.VB8_WFC.Location = new System.Drawing.Point(138, 212);
            this.VB8_WFC.Name = "VB8_WFC";
            this.VB8_WFC.Size = new System.Drawing.Size(146, 20);
            this.VB8_WFC.TabIndex = 34;
            this.VB8_WFC.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Date8_WFC
            // 
            this.Date8_WFC.CustomFormat = " ";
            this.Date8_WFC.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.Date8_WFC.Location = new System.Drawing.Point(3, 212);
            this.Date8_WFC.Name = "Date8_WFC";
            this.Date8_WFC.Size = new System.Drawing.Size(129, 20);
            this.Date8_WFC.TabIndex = 33;
            this.Date8_WFC.Value = new System.DateTime(2000, 1, 1, 0, 0, 0, 0);
            this.Date8_WFC.ValueChanged += new System.EventHandler(this.Date8_WFC_ValueChanged);
            // 
            // Dr_Name8_WFC
            // 
            this.Dr_Name8_WFC.Location = new System.Drawing.Point(290, 212);
            this.Dr_Name8_WFC.Name = "Dr_Name8_WFC";
            this.Dr_Name8_WFC.Size = new System.Drawing.Size(74, 20);
            this.Dr_Name8_WFC.TabIndex = 35;
            // 
            // NDate8_WFC
            // 
            this.NDate8_WFC.CustomFormat = " ";
            this.NDate8_WFC.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.NDate8_WFC.Location = new System.Drawing.Point(370, 212);
            this.NDate8_WFC.Name = "NDate8_WFC";
            this.NDate8_WFC.Size = new System.Drawing.Size(129, 20);
            this.NDate8_WFC.TabIndex = 36;
            this.NDate8_WFC.Value = new System.DateTime(2000, 1, 1, 0, 0, 0, 0);
            this.NDate8_WFC.ValueChanged += new System.EventHandler(this.NDate8_WFC_ValueChanged);
            // 
            // VB9_WFC
            // 
            this.VB9_WFC.Dock = System.Windows.Forms.DockStyle.Fill;
            this.VB9_WFC.Location = new System.Drawing.Point(138, 238);
            this.VB9_WFC.Name = "VB9_WFC";
            this.VB9_WFC.Size = new System.Drawing.Size(146, 20);
            this.VB9_WFC.TabIndex = 38;
            this.VB9_WFC.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Date9_WFC
            // 
            this.Date9_WFC.CustomFormat = " ";
            this.Date9_WFC.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.Date9_WFC.Location = new System.Drawing.Point(3, 238);
            this.Date9_WFC.Name = "Date9_WFC";
            this.Date9_WFC.Size = new System.Drawing.Size(129, 20);
            this.Date9_WFC.TabIndex = 37;
            this.Date9_WFC.Value = new System.DateTime(2000, 1, 1, 0, 0, 0, 0);
            this.Date9_WFC.ValueChanged += new System.EventHandler(this.Date9_WFC_ValueChanged);
            // 
            // Dr_Name9_WFC
            // 
            this.Dr_Name9_WFC.Location = new System.Drawing.Point(290, 238);
            this.Dr_Name9_WFC.Name = "Dr_Name9_WFC";
            this.Dr_Name9_WFC.Size = new System.Drawing.Size(74, 20);
            this.Dr_Name9_WFC.TabIndex = 39;
            // 
            // NDate9_WFC
            // 
            this.NDate9_WFC.CustomFormat = " ";
            this.NDate9_WFC.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.NDate9_WFC.Location = new System.Drawing.Point(370, 238);
            this.NDate9_WFC.Name = "NDate9_WFC";
            this.NDate9_WFC.Size = new System.Drawing.Size(129, 20);
            this.NDate9_WFC.TabIndex = 40;
            this.NDate9_WFC.Value = new System.DateTime(2000, 1, 1, 0, 0, 0, 0);
            this.NDate9_WFC.ValueChanged += new System.EventHandler(this.NDate9_WFC_ValueChanged);
            // 
            // VB10_WFC
            // 
            this.VB10_WFC.Dock = System.Windows.Forms.DockStyle.Fill;
            this.VB10_WFC.Location = new System.Drawing.Point(138, 264);
            this.VB10_WFC.Name = "VB10_WFC";
            this.VB10_WFC.Size = new System.Drawing.Size(146, 20);
            this.VB10_WFC.TabIndex = 42;
            this.VB10_WFC.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Date10_WFC
            // 
            this.Date10_WFC.CustomFormat = " ";
            this.Date10_WFC.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.Date10_WFC.Location = new System.Drawing.Point(3, 264);
            this.Date10_WFC.Name = "Date10_WFC";
            this.Date10_WFC.Size = new System.Drawing.Size(129, 20);
            this.Date10_WFC.TabIndex = 41;
            this.Date10_WFC.Value = new System.DateTime(2000, 1, 1, 0, 0, 0, 0);
            this.Date10_WFC.ValueChanged += new System.EventHandler(this.Date10_WFC_ValueChanged);
            // 
            // Dr_Name10_WFC
            // 
            this.Dr_Name10_WFC.Location = new System.Drawing.Point(290, 264);
            this.Dr_Name10_WFC.Name = "Dr_Name10_WFC";
            this.Dr_Name10_WFC.Size = new System.Drawing.Size(74, 20);
            this.Dr_Name10_WFC.TabIndex = 43;
            // 
            // NDate10_WFC
            // 
            this.NDate10_WFC.CustomFormat = " ";
            this.NDate10_WFC.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.NDate10_WFC.Location = new System.Drawing.Point(370, 264);
            this.NDate10_WFC.Name = "NDate10_WFC";
            this.NDate10_WFC.Size = new System.Drawing.Size(129, 20);
            this.NDate10_WFC.TabIndex = 44;
            this.NDate10_WFC.Value = new System.DateTime(2000, 1, 1, 0, 0, 0, 0);
            this.NDate10_WFC.ValueChanged += new System.EventHandler(this.NDate10_WFC_ValueChanged);
            // 
            // VB11_WFC
            // 
            this.VB11_WFC.Dock = System.Windows.Forms.DockStyle.Fill;
            this.VB11_WFC.Location = new System.Drawing.Point(138, 290);
            this.VB11_WFC.Name = "VB11_WFC";
            this.VB11_WFC.Size = new System.Drawing.Size(146, 20);
            this.VB11_WFC.TabIndex = 46;
            this.VB11_WFC.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Date11_WFC
            // 
            this.Date11_WFC.CustomFormat = " ";
            this.Date11_WFC.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.Date11_WFC.Location = new System.Drawing.Point(3, 290);
            this.Date11_WFC.Name = "Date11_WFC";
            this.Date11_WFC.Size = new System.Drawing.Size(129, 20);
            this.Date11_WFC.TabIndex = 45;
            this.Date11_WFC.Value = new System.DateTime(2000, 1, 1, 0, 0, 0, 0);
            this.Date11_WFC.ValueChanged += new System.EventHandler(this.Date11_WFC_ValueChanged);
            // 
            // Dr_Name11_WFC
            // 
            this.Dr_Name11_WFC.Location = new System.Drawing.Point(290, 290);
            this.Dr_Name11_WFC.Name = "Dr_Name11_WFC";
            this.Dr_Name11_WFC.Size = new System.Drawing.Size(74, 20);
            this.Dr_Name11_WFC.TabIndex = 47;
            // 
            // NDate11_WFC
            // 
            this.NDate11_WFC.CustomFormat = " ";
            this.NDate11_WFC.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.NDate11_WFC.Location = new System.Drawing.Point(370, 290);
            this.NDate11_WFC.Name = "NDate11_WFC";
            this.NDate11_WFC.Size = new System.Drawing.Size(129, 20);
            this.NDate11_WFC.TabIndex = 48;
            this.NDate11_WFC.Value = new System.DateTime(2000, 1, 1, 0, 0, 0, 0);
            this.NDate11_WFC.ValueChanged += new System.EventHandler(this.NDate11_WFC_ValueChanged);
            // 
            // VB12_WFC
            // 
            this.VB12_WFC.Dock = System.Windows.Forms.DockStyle.Fill;
            this.VB12_WFC.Location = new System.Drawing.Point(138, 316);
            this.VB12_WFC.Name = "VB12_WFC";
            this.VB12_WFC.Size = new System.Drawing.Size(146, 20);
            this.VB12_WFC.TabIndex = 50;
            this.VB12_WFC.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Date12_WFC
            // 
            this.Date12_WFC.CustomFormat = " ";
            this.Date12_WFC.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.Date12_WFC.Location = new System.Drawing.Point(3, 316);
            this.Date12_WFC.Name = "Date12_WFC";
            this.Date12_WFC.Size = new System.Drawing.Size(129, 20);
            this.Date12_WFC.TabIndex = 49;
            this.Date12_WFC.Value = new System.DateTime(2000, 1, 1, 0, 0, 0, 0);
            this.Date12_WFC.ValueChanged += new System.EventHandler(this.Date12_WFC_ValueChanged);
            // 
            // Dr_Name12_WFC
            // 
            this.Dr_Name12_WFC.Location = new System.Drawing.Point(290, 316);
            this.Dr_Name12_WFC.Name = "Dr_Name12_WFC";
            this.Dr_Name12_WFC.Size = new System.Drawing.Size(74, 20);
            this.Dr_Name12_WFC.TabIndex = 51;
            // 
            // NDate12_WFC
            // 
            this.NDate12_WFC.CustomFormat = " ";
            this.NDate12_WFC.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.NDate12_WFC.Location = new System.Drawing.Point(370, 316);
            this.NDate12_WFC.Name = "NDate12_WFC";
            this.NDate12_WFC.Size = new System.Drawing.Size(129, 20);
            this.NDate12_WFC.TabIndex = 52;
            this.NDate12_WFC.Value = new System.DateTime(2000, 1, 1, 0, 0, 0, 0);
            this.NDate12_WFC.ValueChanged += new System.EventHandler(this.NDate12_WFC_ValueChanged);
            // 
            // circularButton2
            // 
            this.circularButton2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.circularButton2.AutoSize = true;
            this.circularButton2.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.circularButton2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.circularButton2.FlatAppearance.BorderSize = 0;
            this.circularButton2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.circularButton2.Image = ((System.Drawing.Image)(resources.GetObject("circularButton2.Image")));
            this.circularButton2.Location = new System.Drawing.Point(851, 418);
            this.circularButton2.Name = "circularButton2";
            this.circularButton2.Size = new System.Drawing.Size(56, 56);
            this.circularButton2.TabIndex = 57;
            this.circularButton2.UseVisualStyleBackColor = true;
            this.circularButton2.Click += new System.EventHandler(this.circularButton2_Click);
            // 
            // circularButton5
            // 
            this.circularButton5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.circularButton5.AutoSize = true;
            this.circularButton5.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.circularButton5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.circularButton5.FlatAppearance.BorderSize = 0;
            this.circularButton5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.circularButton5.Image = ((System.Drawing.Image)(resources.GetObject("circularButton5.Image")));
            this.circularButton5.Location = new System.Drawing.Point(795, 418);
            this.circularButton5.Name = "circularButton5";
            this.circularButton5.Size = new System.Drawing.Size(56, 56);
            this.circularButton5.TabIndex = 55;
            this.circularButton5.UseVisualStyleBackColor = true;
            this.circularButton5.Click += new System.EventHandler(this.circularButton5_Click);
            // 
            // Worn_and_Flea_Control
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.ClientSize = new System.Drawing.Size(919, 486);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Controls.Add(this.circularButton2);
            this.Controls.Add(this.circularButton5);
            this.Controls.Add(this.button13);
            this.Controls.Add(this.rtxt_Notes_WFC);
            this.Controls.Add(this.button12);
            this.Name = "Worn_and_Flea_Control";
            this.Text = "Worn_and_Flea_Control";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.RichTextBox rtxt_Notes_WFC;
        private CircularButton circularButton2;
        private CircularButton circularButton5;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.DateTimePicker NDate1_WFC;
        private System.Windows.Forms.DateTimePicker Date1_WFC;
        private System.Windows.Forms.TextBox Dr_Name4_WFC;
        private System.Windows.Forms.TextBox Dr_Name3_WFC;
        private System.Windows.Forms.TextBox Dr_Name2_WFC;
        private System.Windows.Forms.TextBox VB2_WFC;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.TextBox VB1_WFC;
        private System.Windows.Forms.TextBox VB3_WFC;
        private System.Windows.Forms.TextBox VB4_WFC;
        private System.Windows.Forms.TextBox Dr_Name1_WFC;
        private System.Windows.Forms.DateTimePicker Date2_WFC;
        private System.Windows.Forms.DateTimePicker Date3_WFC;
        private System.Windows.Forms.DateTimePicker Date4_WFC;
        private System.Windows.Forms.DateTimePicker NDate2_WFC;
        private System.Windows.Forms.DateTimePicker NDate3_WFC;
        private System.Windows.Forms.DateTimePicker NDate4_WFC;
        private System.Windows.Forms.DateTimePicker Date5_WFC;
        private System.Windows.Forms.TextBox Dr_Name5_WFC;
        private System.Windows.Forms.DateTimePicker NDate5_WFC;
        private System.Windows.Forms.TextBox VB6_WFC;
        private System.Windows.Forms.DateTimePicker Date6_WFC;
        private System.Windows.Forms.TextBox Dr_Name6_WFC;
        private System.Windows.Forms.DateTimePicker NDate6_WFC;
        private System.Windows.Forms.TextBox VB7_WFC;
        private System.Windows.Forms.DateTimePicker Date7_WFC;
        private System.Windows.Forms.TextBox Dr_Name7_WFC;
        private System.Windows.Forms.DateTimePicker NDate7_WFC;
        private System.Windows.Forms.TextBox VB5_WFC;
        private System.Windows.Forms.TextBox VB8_WFC;
        private System.Windows.Forms.DateTimePicker Date8_WFC;
        private System.Windows.Forms.TextBox Dr_Name8_WFC;
        private System.Windows.Forms.DateTimePicker NDate8_WFC;
        private System.Windows.Forms.TextBox VB9_WFC;
        private System.Windows.Forms.DateTimePicker Date9_WFC;
        private System.Windows.Forms.TextBox Dr_Name9_WFC;
        private System.Windows.Forms.DateTimePicker NDate9_WFC;
        private System.Windows.Forms.TextBox VB10_WFC;
        private System.Windows.Forms.DateTimePicker Date10_WFC;
        private System.Windows.Forms.TextBox Dr_Name10_WFC;
        private System.Windows.Forms.DateTimePicker NDate10_WFC;
        private System.Windows.Forms.TextBox VB11_WFC;
        private System.Windows.Forms.DateTimePicker Date11_WFC;
        private System.Windows.Forms.TextBox Dr_Name11_WFC;
        private System.Windows.Forms.DateTimePicker NDate11_WFC;
        private System.Windows.Forms.TextBox VB12_WFC;
        private System.Windows.Forms.DateTimePicker Date12_WFC;
        private System.Windows.Forms.TextBox Dr_Name12_WFC;
        private System.Windows.Forms.DateTimePicker NDate12_WFC;
    }
}