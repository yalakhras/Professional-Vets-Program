﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Professional_Vets
{
    public partial class Physical_Examination : Form
    {
        String vn, ow, mb, pt;
        DateTime dat;
        
        SqlCommand cmd;
        SqlConnection con;
        String AN, PI, IT, LE, DD, HL, LU, GR, SH, PA, SC;
        String NoEy;
        String NoEa;
        
        public Physical_Examination(String role, String owner, String mobile, String pet, DateTime dat1)
        {
            InitializeComponent();
            vn = role;
            ow = owner;
            mb = mobile;
            pt = pet;
            dat = dat1;
                                             
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void toolTip1_Popup(object sender, PopupEventArgs e)
        {

        }

        private void Physical_Examination_Load(object sender, EventArgs e)
        {
            ///// Show & Hide the Text Box & Combo Box when check the checkBox /////////
            ///
            /// Coat And Skin
            /// 
            ///checkBox12 & textBox6////
            if (ch_Other_CAS.Checked)
            {
                txt_Other_CAS.Visible = true;
            }
            else
            {
                txt_Other_CAS.Visible = false;
            }


            ////////////Eyes
            ///
            ////// checkBox15 & comboBox1 //////
            if (ch_Cataract_Eyes.Checked)
            {
                cobo_Cataract_Eyes.Visible = true;
            }
            else
            {
                cobo_Cataract_Eyes.Visible = false;
            }

            /////// checkBox16 &comboBox2 //////////

            if (ch_Discharges_Eyes.Checked)
            {
                cobo_Discharges_Eyes.Visible = true;
            }
            else
            {
                cobo_Discharges_Eyes.Visible = false;
            }


            ///////////checkBox17 & comboBox3 /////////

            if (ch_Inflamed_Eyes.Checked)
            {
                cobo_Inflamed_Eyes.Visible = true;
            }
            else
            {
                cobo_Inflamed_Eyes.Visible = false;
            }


            ///////////checkBox18 & comboBox4//////////


            if (ch_Dry_Eye_Eyes.Checked)
            {
                cobo_Dry_Eye_Eyes.Visible = true;
            }
            else
            {
                cobo_Dry_Eye_Eyes.Visible = false;
            }


            ////////checkBox24 & comboBox5////////////


            if (ch_Ulcers_Lesions_Eyes.Checked)
            {
                cobo_Ulcers_Lesions_Eyes.Visible = true;
            }
            else
            {
                cobo_Ulcers_Lesions_Eyes.Visible = false;
            }


            /////////checkBox19 & comboBox6///////////

            if (ch_Infected_Eyes.Checked)
            {
                cobo_Infected_Eyes.Visible = true;
            }
            else
            {
                cobo_Infected_Eyes.Visible = false;
            }


            ////////checkBox23 & textBox7////////

            if (ch_Other_Eyes.Checked)
            {
                txt_Other_Eyes.Visible = true;
            }
            else
            {
                txt_Other_Eyes.Visible = false;
            }


            ///////////// Ears
            ///////////checkBox20 & comboBox7/////////
            if (ch_Inflamed_Ears.Checked)
            {
                cobo_Inflamed_Ears.Visible = true;
            }
            else
            {
                cobo_Inflamed_Ears.Visible = false;
            }


            ////////checkBox21 & comboBox8/////////
            if (ch_Yeast_Inf_Ears.Checked)
            {
                cobo_Yeast_Inf_Ears.Visible = true;
            }
            else
            {
                cobo_Yeast_Inf_Ears.Visible = false;
            }


            ////////checkBox22 & comboBox9/////////
            if (ch_Bacterial_Ears.Checked)
            {
                cobo_Bacterial_Ears.Visible = true;
            }
            else
            {
                cobo_Bacterial_Ears.Visible = false;
            }


            ////////checkBox25 & comboBox10/////////
            if (ch_Itchy_Ears.Checked)
            {
                cobo_Itchy_Ears.Visible = true;
            }
            else
            {
                cobo_Itchy_Ears.Visible = false;
            }

            ////////checkBox28 & comboBox11/////////
            if (ch_Mites_Ears.Checked)
            {
                cobo_Mites_Ears.Visible = true;
            }
            else
            {
                cobo_Mites_Ears.Visible = false;
            }


            ////////checkBox26 & comboBox12/////////
            if (ch_Excessive_Debris_Hair_Ears.Checked)
            {
                cobo_Excessive_Debris_Hair_Ears.Visible = true;
            }
            else
            {
                cobo_Excessive_Debris_Hair_Ears.Visible = false;
            }


            ////////checkBox27 & textBox8/////////
            if (ch_Other_Ears.Checked)
            {
                txt_Other_Ears.Visible = true;
            }
            else
            {
                txt_Other_Ears.Visible = false;
            }


        }

        private void checkedListBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void groupBox5_Enter(object sender, EventArgs e)
        {

        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void circularButton1_Click(object sender, EventArgs e)
        {
            this.Hide();
            HomePage HP = new HomePage(vn);
            HP.ShowDialog();
        }


        private void tableLayoutPanel1_Paint_1(object sender, PaintEventArgs e)
        {

        }

        private void groupBox3_Enter(object sender, EventArgs e)
        {

        }

        private void checkBox7_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void checkBox15_CheckedChanged(object sender, EventArgs e)
        {
            cobo_Cataract_Eyes.Visible = (ch_Cataract_Eyes.CheckState == CheckState.Checked);
        }

        private void comboBox12_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            
        }

        private void checkBox12_CheckedChanged(object sender, EventArgs e)
        {
            txt_Other_CAS.Visible = (ch_Other_CAS.CheckState == CheckState.Checked);
        }

        private void checkBox16_CheckedChanged(object sender, EventArgs e)
        {
            cobo_Discharges_Eyes.Visible = (ch_Discharges_Eyes.CheckState == CheckState.Checked);
        }

        private void checkBox23_CheckedChanged(object sender, EventArgs e)
        {
            txt_Other_Eyes.Visible = (ch_Other_Eyes.CheckState == CheckState.Checked);
        }

        private void checkBox19_CheckedChanged(object sender, EventArgs e)
        {
            cobo_Infected_Eyes.Visible = (ch_Infected_Eyes.CheckState == CheckState.Checked);
        }

        private void txtRT_KeyPress(object sender, KeyPressEventArgs e)
        {
            
        }

        private void txtHR_KeyPress(object sender, KeyPressEventArgs e)
        {
            
        }

        private void txtRR_KeyPress(object sender, KeyPressEventArgs e)
        {
            
        }

        private void txtCRT_KeyPress(object sender, KeyPressEventArgs e)
        {
            
        }

        private void Physical_Examination_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.Hide();
            HomePage HP = new HomePage(vn);
            HP.ShowDialog();
        }

        private void txtWight_KeyPress(object sender, KeyPressEventArgs e)
        {
            
        }

        private void checkBox24_CheckedChanged(object sender, EventArgs e)
        {
            cobo_Ulcers_Lesions_Eyes.Visible = (ch_Ulcers_Lesions_Eyes.CheckState == CheckState.Checked);
        }

        private void checkBox18_CheckedChanged(object sender, EventArgs e)
        {
            cobo_Dry_Eye_Eyes.Visible = (ch_Dry_Eye_Eyes.CheckState == CheckState.Checked);
        }

        private void checkBox17_CheckedChanged(object sender, EventArgs e)
        {
            cobo_Inflamed_Eyes.Visible = (ch_Inflamed_Eyes.CheckState == CheckState.Checked);
        }

        private void checkBox20_CheckedChanged(object sender, EventArgs e)
        {
            cobo_Inflamed_Ears.Visible = (ch_Inflamed_Ears.CheckState == CheckState.Checked);
        }

        private void checkBox21_CheckedChanged(object sender, EventArgs e)
        {
            cobo_Yeast_Inf_Ears.Visible = (ch_Yeast_Inf_Ears.CheckState == CheckState.Checked);
        }

        private void checkBox22_CheckedChanged(object sender, EventArgs e)
        {
            cobo_Bacterial_Ears.Visible = (ch_Bacterial_Ears.CheckState == CheckState.Checked);
        }

        private void checkBox25_CheckedChanged(object sender, EventArgs e)
        {
            cobo_Itchy_Ears.Visible = (ch_Itchy_Ears.CheckState == CheckState.Checked);
        }

        private void checkBox28_CheckedChanged(object sender, EventArgs e)
        {
            cobo_Mites_Ears.Visible = (ch_Mites_Ears.CheckState == CheckState.Checked);
        }

        private void checkBox26_CheckedChanged(object sender, EventArgs e)
        {
            cobo_Excessive_Debris_Hair_Ears.Visible = (ch_Excessive_Debris_Hair_Ears.CheckState == CheckState.Checked);
        }

        private void checkBox27_CheckedChanged(object sender, EventArgs e)
        {
            txt_Other_Ears.Visible = (ch_Other_Ears.CheckState == CheckState.Checked);
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }


        
        private void circularButton3_Click(object sender, EventArgs e)
        {
            con = new SqlConnection(Properties.Settings.Default.Database1ConnectionString);
            con.Open();

            // If statement for Coat & Normal
            
            AN = ch_Appear_Normal_CAS.Checked == true ? "Yes" : "NO";
            PI = ch_Pigment_CAS.Checked == true ? "Yes" : "NO";
            IT = ch_Itchy_CAS.Checked == true ? "Yes" : "NO";
            LE = ch_Lesion_CAS.Checked == true ? "Yes" : "NO";
            DD = ch_Dry_Dull_CAS.Checked == true ? "Yes" : "NO";
            HL = ch_Hair_Loss_CAS.Checked == true ? "Yes" : "NO";
            LU = ch_Lumps_CAS.Checked == true ? "Yes" : "NO";
            GR = ch_Greasy_CAS.Checked == true ? "Yes" : "NO";
            SH = ch_Shedding_CAS.Checked == true ? "Yes" : "NO";
            PA = ch_Parasites_CAS.Checked == true ? "Yes" : "NO";
            SC = ch_Scaly_CAS.Checked == true ? "Yes" : "NO";

            // If statement for Eyes

            NoEy = ch_Normal_Eyes.Checked == true ? "Yes" : "NO";

            // If statement for Ears

            NoEa = ch_Normal_Ears.Checked == true ? "Yes" : "NO";


            cmd = new SqlCommand("Insert INTO Ph_Ex (Date, Vet_Name, Owner, Mobile, Pet, RT, HR, RR, CRT, Wight, Appear_Normal_CAS, Pigment_CAS, Itchy_CAS, Lesion_CAS, Dry_Dull_CAS, Hair_Loss_CAS, Lumps_CAS, Greasy_CAS, Shedding_CAS, Parasites_CAS, Scaly_CAS, Other_CAS, Normal_Eyes, Cataract_Eyes, Discharges_Eyes, Inflamed_Eyes, Dry_Eye_Eyes, Ulcers_Lesions_Eyes, Infected_Eyes, Other_Eyes, Normal_Ears, Inflamed_Ears, Yeast_Inf_Ears, Bacterial_Ears, Itchy_Ears, Mites_Ears, Excessive_Debris_Hair_Ears, Other_Ears) VALUES (@Date, @Vet_Name, @Owner, @Mobile, @Pet, @RT, @HR, @RR, @CRT, @Wight, @Appear_Normal_CAS, @Pigment_CAS, @Itchy_CAS, @Lesion_CAS, @Dry_Dull_CAS, @Hair_Loss_CAS, @Lumps_CAS, @Greasy_CAS, @Shedding_CAS, @Parasites_CAS, @Scaly_CAS, @Other_CAS, @Normal_Eyes, @Cataract_Eyes, @Discharges_Eyes, @Inflamed_Eyes, @Dry_Eye_Eyes, @Ulcers_Lesions_Eyes, @Infected_Eyes, @Other_Eyes, @Normal_Ears, @Inflamed_Ears, @Yeast_Inf_Ears, @Bacterial_Ears, @Itchy_Ears, @Mites_Ears, @Excessive_Debris_Hair_Ears, @Other_Ears)", con);

            // Vet_Name, Owner, Mobile, Pet
            cmd.Parameters.AddWithValue("@Vet_Name", vn);
            cmd.Parameters.AddWithValue("@Owner", ow);
            cmd.Parameters.AddWithValue("@Mobile", mb);
            cmd.Parameters.AddWithValue("@Pet", pt);
            //            cmd.Parameters.AddWithValue("@Date", DateTime.Now);
            cmd.Parameters.AddWithValue("@Date", dat);

            // Vital Signs (at rest)
            cmd.Parameters.AddWithValue("@RT", txtRT.Text);
            cmd.Parameters.AddWithValue("@HR", txtHR.Text);
            cmd.Parameters.AddWithValue("@RR", txtRR.Text);
            cmd.Parameters.AddWithValue("@CRT", txtCRT.Text);
            cmd.Parameters.AddWithValue("@Wight", txtWight.Text);

            // Coat And Skin
            cmd.Parameters.AddWithValue("@Appear_Normal_CAS", AN);
            cmd.Parameters.AddWithValue("@Pigment_CAS", PI);
            cmd.Parameters.AddWithValue("@Itchy_CAS", IT);
            cmd.Parameters.AddWithValue("@Lesion_CAS", LE);
            cmd.Parameters.AddWithValue("@Dry_Dull_CAS", DD);
            cmd.Parameters.AddWithValue("@Hair_Loss_CAS", HL);
            cmd.Parameters.AddWithValue("@Lumps_CAS", LU);
            cmd.Parameters.AddWithValue("@Greasy_CAS", GR);
            cmd.Parameters.AddWithValue("@Shedding_CAS", SH);
            cmd.Parameters.AddWithValue("@Parasites_CAS", PA);
            cmd.Parameters.AddWithValue("@Scaly_CAS", SC);
            cmd.Parameters.AddWithValue("@Other_CAS", txt_Other_CAS.Text);

            // Eyes
            cmd.Parameters.AddWithValue("@Normal_Eyes", NoEy);

            if (cobo_Cataract_Eyes.SelectedItem != null)
            {
                cmd.Parameters.AddWithValue("@Cataract_Eyes", cobo_Cataract_Eyes.SelectedItem.ToString());
            }
            else
            { cmd.Parameters.AddWithValue("@Cataract_Eyes", "null"); }

            if (cobo_Discharges_Eyes.SelectedItem != null)
            {
                cmd.Parameters.AddWithValue("@Discharges_Eyes", cobo_Discharges_Eyes.SelectedItem.ToString());
            }
            else
            { cmd.Parameters.AddWithValue("@Discharges_Eyes", "null"); }

            if (cobo_Inflamed_Eyes.SelectedItem != null)
            {
                cmd.Parameters.AddWithValue("@Inflamed_Eyes", cobo_Inflamed_Eyes.SelectedItem.ToString());
            }
            else
            { cmd.Parameters.AddWithValue("@Inflamed_Eyes", "null"); }

            if (cobo_Dry_Eye_Eyes.SelectedItem != null)
            {
                cmd.Parameters.AddWithValue("@Dry_Eye_Eyes", cobo_Dry_Eye_Eyes.SelectedItem.ToString());
            }
            else
            { cmd.Parameters.AddWithValue("@Dry_Eye_Eyes", "null"); }

            if (cobo_Ulcers_Lesions_Eyes.SelectedItem != null)
            {
                cmd.Parameters.AddWithValue("@Ulcers_Lesions_Eyes", cobo_Ulcers_Lesions_Eyes.SelectedItem.ToString());
            }
            else
            { cmd.Parameters.AddWithValue("@Ulcers_Lesions_Eyes", "null"); }

            if (cobo_Infected_Eyes.SelectedItem != null)
            {
                cmd.Parameters.AddWithValue("@Infected_Eyes", cobo_Infected_Eyes.SelectedItem.ToString());
            }
            else
            { cmd.Parameters.AddWithValue("@Infected_Eyes", "null"); }

            cmd.Parameters.AddWithValue("@Other_Eyes", txt_Other_Eyes.Text);

            // Ears
            cmd.Parameters.AddWithValue("@Normal_Ears", NoEa);

            if (cobo_Inflamed_Ears.SelectedItem != null)
            {
                cmd.Parameters.AddWithValue("@Inflamed_Ears", cobo_Inflamed_Ears.SelectedItem.ToString());
            }
            else
            { cmd.Parameters.AddWithValue("@Inflamed_Ears", "null"); }

            if (cobo_Yeast_Inf_Ears.SelectedItem != null)
            {
                cmd.Parameters.AddWithValue("@Yeast_Inf_Ears", cobo_Yeast_Inf_Ears.SelectedItem.ToString());
            }
            else
            { cmd.Parameters.AddWithValue("@Yeast_Inf_Ears", "null"); }

            if (cobo_Bacterial_Ears.SelectedItem != null)
            {
                cmd.Parameters.AddWithValue("@Bacterial_Ears", cobo_Bacterial_Ears.SelectedItem.ToString());
            }
            else
            { cmd.Parameters.AddWithValue("@Bacterial_Ears", "null"); }

            if (cobo_Itchy_Ears.SelectedItem != null)
            {
                cmd.Parameters.AddWithValue("@Itchy_Ears", cobo_Itchy_Ears.SelectedIndex.ToString());
            }
            else
            { cmd.Parameters.AddWithValue("@Itchy_Ears", "null"); }

            if (cobo_Mites_Ears.SelectedItem != null)
            {
                cmd.Parameters.AddWithValue("@Mites_Ears", cobo_Mites_Ears.SelectedItem.ToString());
            }
            else
            { cmd.Parameters.AddWithValue("@Mites_Ears", "null"); }

            if (cobo_Excessive_Debris_Hair_Ears.SelectedItem != null)
            {
                cmd.Parameters.AddWithValue("@Excessive_Debris_Hair_Ears", cobo_Excessive_Debris_Hair_Ears.SelectedItem.ToString());
            }
            else
            { cmd.Parameters.AddWithValue("@Excessive_Debris_Hair_Ears", "null"); }

            cmd.Parameters.AddWithValue("@Other_Ears", txt_Other_Ears.Text);


            cmd.ExecuteNonQuery();
            con.Close();

            // Open the Next Form
            this.Hide();
            Physical_Examination1 PhE1 = new Physical_Examination1(vn, ow, mb, pt, dat);
            PhE1.ShowDialog();
            
        }
    }
    }
