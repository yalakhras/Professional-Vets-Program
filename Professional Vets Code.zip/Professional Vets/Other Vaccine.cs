﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Professional_Vets
{
    public partial class Other_Vaccine : Form
    {
        String vn, ow, mb, pt;

        SqlCommand cmd;
        SqlConnection con;


        private void circularButton2_Click(object sender, EventArgs e)
        {
            con = new SqlConnection(Properties.Settings.Default.Database1ConnectionString);
            con.Open();
            cmd = new SqlCommand("Insert INTO Other_Vaccine (Vet_Name, Owner, Mobile, Pet, Date_1, Vaccine_Batch_1, Dr_Name_1, Next_Date_1, Date_2, Vaccine_Batch_2, Dr_Name_2, Next_Date_2, Date_3, Vaccine_Batch_3, Dr_Name_3, Next_Date_3, Date_4, Vaccine_Batch_4, Dr_Name_4, Next_Date_4, Date_5, Vaccine_Batch_5, Dr_Name_5, Next_Date_5, Date_6, Vaccine_Batch_6, Dr_Name_6, Next_Date_6, Notes) VALUES (@Vet_Name, @Owner, @Mobile, @Pet, @Date_1, @Vaccine_Batch_1, @Dr_Name_1, @Next_Date_1, @Date_2, @Vaccine_Batch_2, @Dr_Name_2, @Next_Date_2, @Date_3, @Vaccine_Batch_3, @Dr_Name_3, @Next_Date_3, @Date_4, @Vaccine_Batch_4, @Dr_Name_4, @Next_Date_4, @Date_5, @Vaccine_Batch_5, @Dr_Name_5, @Next_Date_5, @Date_6, @Vaccine_Batch_6, @Dr_Name_6, @Next_Date_6, @Notes)", con);

            // Primary Vaccination record
            cmd.Parameters.AddWithValue("@Vet_Name", vn);
            cmd.Parameters.AddWithValue("@Owner", ow);
            cmd.Parameters.AddWithValue("@Mobile", mb);
            cmd.Parameters.AddWithValue("@Pet", pt);

            cmd.Parameters.AddWithValue("@Date_1", Date1_OV.Value.ToShortDateString());
            cmd.Parameters.AddWithValue("@Vaccine_Batch_1", VB1_OV.Text);
            cmd.Parameters.AddWithValue("@Dr_Name_1", Dr_Name1_OV.Text);
            cmd.Parameters.AddWithValue("@Next_Date_1", NDate1_OV.Value.ToShortDateString());

            cmd.Parameters.AddWithValue("@Date_2", Date2_OV.Value.ToShortDateString());
            cmd.Parameters.AddWithValue("@Vaccine_Batch_2", VB2_OV.Text);
            cmd.Parameters.AddWithValue("@Dr_Name_2", Dr_Name2_OV.Text);
            cmd.Parameters.AddWithValue("@Next_Date_2", NDate2_OV.Value.ToShortDateString());

            cmd.Parameters.AddWithValue("@Date_3", Date3_OV.Value.ToShortDateString());
            cmd.Parameters.AddWithValue("@Vaccine_Batch_3", VB3_OV.Text);
            cmd.Parameters.AddWithValue("@Dr_Name_3", Dr_Name3_OV.Text);
            cmd.Parameters.AddWithValue("@Next_Date_3", NDate3_OV.Value.ToShortDateString());

            cmd.Parameters.AddWithValue("@Date_4", Date4_OV.Value.ToShortDateString());
            cmd.Parameters.AddWithValue("@Vaccine_Batch_4", VB4_OV.Text);
            cmd.Parameters.AddWithValue("@Dr_Name_4", Dr_Name4_OV.Text);
            cmd.Parameters.AddWithValue("@Next_Date_4", NDate4_OV.Value.ToShortDateString());

            cmd.Parameters.AddWithValue("@Date_5", Date5_OV.Value.ToShortDateString());
            cmd.Parameters.AddWithValue("@Vaccine_Batch_5", VB5_OV.Text);
            cmd.Parameters.AddWithValue("@Dr_Name_5", Dr_Name5_OV.Text);
            cmd.Parameters.AddWithValue("@Next_Date_5", NDate5_OV.Value.ToShortDateString());

            cmd.Parameters.AddWithValue("@Date_6", Date6_OV.Value.ToShortDateString());
            cmd.Parameters.AddWithValue("@Vaccine_Batch_6", VB6_OV.Text);
            cmd.Parameters.AddWithValue("@Dr_Name_6", Dr_Name6_OV.Text);
            cmd.Parameters.AddWithValue("@Next_Date_6", NDate6_OV.Value.ToShortDateString());

            cmd.Parameters.AddWithValue("@Notes", rtxt_Notes_OV.Text);

            cmd.ExecuteNonQuery();
            con.Close();

            this.Hide();
            Annual_Vaccination AV = new Annual_Vaccination(vn, ow, mb, pt);
            AV.ShowDialog();

        }

        private void NDate1_OV_ValueChanged(object sender, EventArgs e)
        {
            NDate1_OV.CustomFormat = "dd/MM/yyyy";
        }

        private void NDate2_OV_ValueChanged(object sender, EventArgs e)
        {
            NDate2_OV.CustomFormat = "dd/MM/yyyy";
        }

        private void NDate3_OV_ValueChanged(object sender, EventArgs e)
        {
            NDate3_OV.CustomFormat = "dd/MM/yyyy";
        }

        private void NDate4_OV_ValueChanged(object sender, EventArgs e)
        {
            NDate4_OV.CustomFormat = "dd/MM/yyyy";
        }

        private void NDate5_OV_ValueChanged(object sender, EventArgs e)
        {
            NDate5_OV.CustomFormat = "dd/MM/yyyy";
        }

        private void NDate6_OV_ValueChanged(object sender, EventArgs e)
        {
            NDate6_OV.CustomFormat = "dd/MM/yyyy";
        }

        private void Date1_OV_ValueChanged(object sender, EventArgs e)
        {
            Date1_OV.CustomFormat = "dd/MM/yyyy";
        }

        private void Date2_OV_ValueChanged(object sender, EventArgs e)
        {
            Date2_OV.CustomFormat = "dd/MM/yyyy";
        }

        private void Date3_OV_ValueChanged(object sender, EventArgs e)
        {
            Date3_OV.CustomFormat = "dd/MM/yyyy";
        }

        private void Date4_OV_ValueChanged(object sender, EventArgs e)
        {
            Date4_OV.CustomFormat = "dd/MM/yyyy";
        }

        private void Date5_OV_ValueChanged(object sender, EventArgs e)
        {
            Date5_OV.CustomFormat = "dd/MM/yyyy";
        }

        private void Date6_OV_ValueChanged(object sender, EventArgs e)
        {
            Date6_OV.CustomFormat = "dd/MM/yyyy";
        }

        private void Other_Vaccine_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.Hide();
            HomePage HP = new HomePage(vn);
            HP.ShowDialog();
        }

        public Other_Vaccine(String role, String owner, String mobile, String pet)
        {
            InitializeComponent();
            vn = role;
            ow = owner;
            mb = mobile;
            pt = pet;
        }

        private void Other_Vaccine_Load(object sender, EventArgs e)
        {

        }

        private void circularButton5_Click(object sender, EventArgs e)
        {
            this.Hide();
            HomePage HP = new HomePage(vn);
            HP.ShowDialog();
        }
    }
}
