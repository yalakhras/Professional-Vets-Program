﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Professional_Vets
{
    public partial class Today_Transactions : Form
    {
        String vn;

        public static SqlConnection con = new SqlConnection(Properties.Settings.Default.Database1ConnectionString);

        String Id;
        int Id1;
        int delete_Id;

        public Today_Transactions(String role)
        {
            InitializeComponent();
            dateTimePicker1.Value = DateTime.Now;
            vn = role;
        }

        private void CircularButton1_Click(object sender, EventArgs e)
        {
            this.Hide();
            HomePage HP = new HomePage(vn);
            HP.ShowDialog();
        }

        private void Today_Transactions_Load(object sender, EventArgs e)
        {
            if (con.State == ConnectionState.Open)
            {
                con.Close();
            }

            con = new SqlConnection(Properties.Settings.Default.Database1ConnectionString);
            con.Open();

            
            SqlDataAdapter da = new SqlDataAdapter("select * from DTran where Date ='" + dateTimePicker1.Value.ToShortDateString() + "'", con);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
            Fill_grid();
        }

        public void Fill_grid()
        {
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from DTran where Date ='" + dateTimePicker1.Value.ToShortDateString() + "'";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void DataGridView1_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            Id = dataGridView1.Rows[e.RowIndex].Cells["No"].Value.ToString();
            if (Id == "")
            {
                Id1 = 0;
            }

            else
            {
                Id1 = Convert.ToInt32(dataGridView1.Rows[e.RowIndex].Cells["No"].Value.ToString());
            }

            if (Id1 == 0)
            {
                SqlCommand cmd = con.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "Insert into DTran Vaues ('" + dataGridView1.Rows[e.RowIndex].Cells["Action_1"].Value.ToString() + "', '" + dataGridView1.Rows[e.RowIndex].Cells["Price_1"].Value.ToString() + "', '" + dataGridView1.Rows[e.RowIndex].Cells["Paid_1"].Value.ToString() + "', '" + dataGridView1.Rows[e.RowIndex].Cells["More_Info_1"].Value.ToString() + "', '" + dataGridView1.Rows[e.RowIndex].Cells["Action_2"].Value.ToString() + "','" + dataGridView1.Rows[e.RowIndex].Cells["Price_2"].Value.ToString() + "', '" + dataGridView1.Rows[e.RowIndex].Cells["Paid_2"].Value.ToString() + "', '" + dataGridView1.Rows[e.RowIndex].Cells["More_Info_2"].Value.ToString() + "', '" + dataGridView1.Rows[e.RowIndex].Cells["Action_3"].Value.ToString() + "', '" + dataGridView1.Rows[e.RowIndex].Cells["Price_3"].Value.ToString() + "', '" + dataGridView1.Rows[e.RowIndex].Cells["Paid_3"].Value.ToString() + "', '" + dataGridView1.Rows[e.RowIndex].Cells["More_Info_3"].Value.ToString() + "', '" + dataGridView1.Rows[e.RowIndex].Cells["Action_4"].Value.ToString() + "', '" + dataGridView1.Rows[e.RowIndex].Cells["Price_4"].Value.ToString() + "', '" + dataGridView1.Rows[e.RowIndex].Cells["Paid_4"].Value.ToString() + "', '" + dataGridView1.Rows[e.RowIndex].Cells["More_Info_4"].Value.ToString() + "', '" + dataGridView1.Rows[e.RowIndex].Cells["Action_5"].Value.ToString() + "', '" + dataGridView1.Rows[e.RowIndex].Cells["Price_5"].Value.ToString() + "', '" + dataGridView1.Rows[e.RowIndex].Cells["Paid_5"].Value.ToString() + "', '" + dataGridView1.Rows[e.RowIndex].Cells["More_Info_5"].Value.ToString() + "', '" + dataGridView1.Rows[e.RowIndex].Cells["Action_6"].Value.ToString() + "', '" + dataGridView1.Rows[e.RowIndex].Cells["Price_6"].Value.ToString() + "', '" + dataGridView1.Rows[e.RowIndex].Cells["Paid_6"].Value.ToString() + "', '" + dataGridView1.Rows[e.RowIndex].Cells["More_Info_6"].Value.ToString() + "', '" + dataGridView1.Rows[e.RowIndex].Cells["Action_7"].Value.ToString() + "', '" + dataGridView1.Rows[e.RowIndex].Cells["Price_7"].Value.ToString() + "', '" + dataGridView1.Rows[e.RowIndex].Cells["Paid_7"].Value.ToString() + "', '" + dataGridView1.Rows[e.RowIndex].Cells["More_Info_7"].Value.ToString() + "', '" + dataGridView1.Rows[e.RowIndex].Cells["Action_8"].Value.ToString() + "', '" + dataGridView1.Rows[e.RowIndex].Cells["Price_8"].Value.ToString() + "', '" + dataGridView1.Rows[e.RowIndex].Cells["Paid_8"].Value.ToString() + "', '" + dataGridView1.Rows[e.RowIndex].Cells["More_Info_8"].Value.ToString() + "', '" + dataGridView1.Rows[e.RowIndex].Cells["Action_9"].Value.ToString() + "', '" + dataGridView1.Rows[e.RowIndex].Cells["Price_9"].Value.ToString() + "', '" + dataGridView1.Rows[e.RowIndex].Cells["Paid_9"].Value.ToString() + "', '" + dataGridView1.Rows[e.RowIndex].Cells["More_Info_9"].Value.ToString() + "', '" + dataGridView1.Rows[e.RowIndex].Cells["Action_10"].Value.ToString() + "', '" + dataGridView1.Rows[e.RowIndex].Cells["Price_10"].Value.ToString() + "', '" + dataGridView1.Rows[e.RowIndex].Cells["Paid_10"].Value.ToString() + "', '" + dataGridView1.Rows[e.RowIndex].Cells["More_Info_10"].Value.ToString() + "', '" + dataGridView1.Rows[e.RowIndex].Cells["Action_11"].Value.ToString() + "', '" + dataGridView1.Rows[e.RowIndex].Cells["Price_11"].Value.ToString() + "', '" + dataGridView1.Rows[e.RowIndex].Cells["Paid_11"].Value.ToString() + "', '" + dataGridView1.Rows[e.RowIndex].Cells["More_Info_11"].Value.ToString() + "',  '" + dataGridView1.Rows[e.RowIndex].Cells["Action_12"].Value.ToString() + "', '" + dataGridView1.Rows[e.RowIndex].Cells["Price_12"].Value.ToString() + "', '" + dataGridView1.Rows[e.RowIndex].Cells["Paid_12"].Value.ToString() + "', '" + dataGridView1.Rows[e.RowIndex].Cells["More_Info_12"].Value.ToString() + "', '" + dataGridView1.Rows[e.RowIndex].Cells["Action_13"].Value.ToString() + "', '" + dataGridView1.Rows[e.RowIndex].Cells["Price_13"].Value.ToString() + "', '" + dataGridView1.Rows[e.RowIndex].Cells["Paid_13"].Value.ToString() + "', '" + dataGridView1.Rows[e.RowIndex].Cells["More_Info_13"].Value.ToString() + "',  '" + dataGridView1.Rows[e.RowIndex].Cells["Action_14"].Value.ToString() + "', '" + dataGridView1.Rows[e.RowIndex].Cells["Price_14"].Value.ToString() + "', '" + dataGridView1.Rows[e.RowIndex].Cells["Paid_14"].Value.ToString() + "', '" + dataGridView1.Rows[e.RowIndex].Cells["More_Info_14"].Value.ToString() + "',  '" + dataGridView1.Rows[e.RowIndex].Cells["Action_15"].Value.ToString() + "', '" + dataGridView1.Rows[e.RowIndex].Cells["Price_15"].Value.ToString() + "', '" + dataGridView1.Rows[e.RowIndex].Cells["Paid_15"].Value.ToString() + "', '" + dataGridView1.Rows[e.RowIndex].Cells["More_Info_15"].Value.ToString() + "')";

                cmd.ExecuteNonQuery();
                Fill_grid();
            }

            else
            {
                SqlCommand cmd = con.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "Update DTran set Action_1 ='" + dataGridView1.Rows[e.RowIndex].Cells["Action_1"].Value.ToString() + "', Price_1 ='" + dataGridView1.Rows[e.RowIndex].Cells["Price_1"].Value.ToString() + "', Paid_1 ='" + dataGridView1.Rows[e.RowIndex].Cells["Paid_1"].Value.ToString() + "', More_Info_1 ='" + dataGridView1.Rows[e.RowIndex].Cells["More_Info_1"].Value.ToString() + "', Action_2 ='" + dataGridView1.Rows[e.RowIndex].Cells["Action_2"].Value.ToString() + "', Price_2 ='" + dataGridView1.Rows[e.RowIndex].Cells["Price_2"].Value.ToString() + "', Paid_2 ='" + dataGridView1.Rows[e.RowIndex].Cells["Paid_2"].Value.ToString() + "', More_Info_2 ='" + dataGridView1.Rows[e.RowIndex].Cells["More_Info_2"].Value.ToString() + "', Action_3 ='" + dataGridView1.Rows[e.RowIndex].Cells["Action_3"].Value.ToString() + "', Price_3 ='" + dataGridView1.Rows[e.RowIndex].Cells["Price_3"].Value.ToString() + "', Paid_3 ='" + dataGridView1.Rows[e.RowIndex].Cells["Paid_3"].Value.ToString() + "', More_Info_3 ='" + dataGridView1.Rows[e.RowIndex].Cells["More_Info_3"].Value.ToString() + "', Action_4 ='" + dataGridView1.Rows[e.RowIndex].Cells["Action_4"].Value.ToString() + "', Price_4 ='" + dataGridView1.Rows[e.RowIndex].Cells["Price_4"].Value.ToString() + "', Paid_4 ='" + dataGridView1.Rows[e.RowIndex].Cells["Paid_4"].Value.ToString() + "', More_Info_4 ='" + dataGridView1.Rows[e.RowIndex].Cells["More_Info_4"].Value.ToString() + "', Action_5 ='" + dataGridView1.Rows[e.RowIndex].Cells["Action_5"].Value.ToString() + "', Price_5 ='" + dataGridView1.Rows[e.RowIndex].Cells["Price_5"].Value.ToString() + "', Paid_5 ='" + dataGridView1.Rows[e.RowIndex].Cells["Paid_5"].Value.ToString() + "', More_Info_5 ='" + dataGridView1.Rows[e.RowIndex].Cells["More_Info_5"].Value.ToString() + "', Action_6 ='" + dataGridView1.Rows[e.RowIndex].Cells["Action_6"].Value.ToString() + "', Price_6 ='" + dataGridView1.Rows[e.RowIndex].Cells["Price_6"].Value.ToString() + "', Paid_6 ='" + dataGridView1.Rows[e.RowIndex].Cells["Paid_6"].Value.ToString() + "', More_Info_6 ='" + dataGridView1.Rows[e.RowIndex].Cells["More_Info_6"].Value.ToString() + "', Action_7 ='" + dataGridView1.Rows[e.RowIndex].Cells["Action_7"].Value.ToString() + "', Price_7 ='" + dataGridView1.Rows[e.RowIndex].Cells["Price_7"].Value.ToString() + "', Paid_7 ='" + dataGridView1.Rows[e.RowIndex].Cells["Paid_7"].Value.ToString() + "', More_Info_7 ='" + dataGridView1.Rows[e.RowIndex].Cells["More_Info_7"].Value.ToString() + "', Action_8 ='" + dataGridView1.Rows[e.RowIndex].Cells["Action_8"].Value.ToString() + "', Price_8 ='" + dataGridView1.Rows[e.RowIndex].Cells["Price_8"].Value.ToString() + "', Paid_8 ='" + dataGridView1.Rows[e.RowIndex].Cells["Paid_8"].Value.ToString() + "', More_Info_8 ='" + dataGridView1.Rows[e.RowIndex].Cells["More_Info_8"].Value.ToString() + "', Action_9 ='" + dataGridView1.Rows[e.RowIndex].Cells["Action_9"].Value.ToString() + "', Price_9 ='" + dataGridView1.Rows[e.RowIndex].Cells["Price_9"].Value.ToString() + "', Paid_9 ='" + dataGridView1.Rows[e.RowIndex].Cells["Paid_9"].Value.ToString() + "', More_Info_9 ='" + dataGridView1.Rows[e.RowIndex].Cells["More_Info_9"].Value.ToString() + "', Action_10 ='" + dataGridView1.Rows[e.RowIndex].Cells["Action_10"].Value.ToString() + "', Price_10 ='" + dataGridView1.Rows[e.RowIndex].Cells["Price_10"].Value.ToString() + "', Paid_10 ='" + dataGridView1.Rows[e.RowIndex].Cells["Paid_10"].Value.ToString() + "', More_Info_10 ='" + dataGridView1.Rows[e.RowIndex].Cells["More_Info_10"].Value.ToString() + "', Action_11 ='" + dataGridView1.Rows[e.RowIndex].Cells["Action_11"].Value.ToString() + "', Price_11 ='" + dataGridView1.Rows[e.RowIndex].Cells["Price_11"].Value.ToString() + "', Paid_11 ='" + dataGridView1.Rows[e.RowIndex].Cells["Paid_11"].Value.ToString() + "', More_Info_11 ='" + dataGridView1.Rows[e.RowIndex].Cells["More_Info_11"].Value.ToString() + "',  Action_12 ='" + dataGridView1.Rows[e.RowIndex].Cells["Action_12"].Value.ToString() + "', Price_12 ='" + dataGridView1.Rows[e.RowIndex].Cells["Price_12"].Value.ToString() + "', Paid_12 ='" + dataGridView1.Rows[e.RowIndex].Cells["Paid_12"].Value.ToString() + "', More_Info_12 ='" + dataGridView1.Rows[e.RowIndex].Cells["More_Info_12"].Value.ToString() + "', Action_13 ='" + dataGridView1.Rows[e.RowIndex].Cells["Action_13"].Value.ToString() + "', Price_13 ='" + dataGridView1.Rows[e.RowIndex].Cells["Price_13"].Value.ToString() + "', Paid_13 ='" + dataGridView1.Rows[e.RowIndex].Cells["Paid_13"].Value.ToString() + "', More_Info_13 ='" + dataGridView1.Rows[e.RowIndex].Cells["More_Info_13"].Value.ToString() + "',  Action_14 ='" + dataGridView1.Rows[e.RowIndex].Cells["Action_14"].Value.ToString() + "', Price_14 ='" + dataGridView1.Rows[e.RowIndex].Cells["Price_14"].Value.ToString() + "', Paid_14 ='" + dataGridView1.Rows[e.RowIndex].Cells["Paid_14"].Value.ToString() + "', More_Info_14 ='" + dataGridView1.Rows[e.RowIndex].Cells["More_Info_14"].Value.ToString() + "',  Action_15 ='" + dataGridView1.Rows[e.RowIndex].Cells["Action_15"].Value.ToString() + "', Price_15 ='" + dataGridView1.Rows[e.RowIndex].Cells["Price_15"].Value.ToString() + "', Paid_15 ='" + dataGridView1.Rows[e.RowIndex].Cells["Paid_15"].Value.ToString() + "', More_Info_15 ='" + dataGridView1.Rows[e.RowIndex].Cells["More_Info_15"].Value.ToString() + "' Where No= " + Id1 + "";

                cmd.ExecuteNonQuery();

                MessageBox.Show("The Data was Updated");
                Fill_grid();

            }
        }

        private void DataGridView1_CellMouseUp(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                delete_Id = Convert.ToInt32(dataGridView1.Rows[e.RowIndex].Cells["No"].Value.ToString());
                this.contextMenuStrip1.Show(this.dataGridView1, e.Location);
                contextMenuStrip1.Show(Cursor.Position);
            }
        }

        private void DeleteRecordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "Delete from DTran Where No=" + delete_Id + "";

            MessageBox.Show("Selected Row was Deleted");
            cmd.ExecuteNonQuery();
            Fill_grid();
        }

        private void Today_Transactions_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.Hide();
            HomePage HP = new HomePage(vn);
            HP.ShowDialog();
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            dateTimePicker1.CustomFormat = "dd/MM/yyyy";
        }
    }
}
