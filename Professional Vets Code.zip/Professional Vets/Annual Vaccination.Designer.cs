﻿namespace Professional_Vets
{
    partial class Annual_Vaccination
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Annual_Vaccination));
            this.button13 = new System.Windows.Forms.Button();
            this.rtxt_Notes_AV = new System.Windows.Forms.RichTextBox();
            this.button5 = new System.Windows.Forms.Button();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.NDate1_AV = new System.Windows.Forms.DateTimePicker();
            this.Date1_AV = new System.Windows.Forms.DateTimePicker();
            this.Dr_Name4_AV = new System.Windows.Forms.TextBox();
            this.Dr_Name3_AV = new System.Windows.Forms.TextBox();
            this.Dr_Name2_AV = new System.Windows.Forms.TextBox();
            this.VB2_AV = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.VB1_AV = new System.Windows.Forms.TextBox();
            this.VB3_AV = new System.Windows.Forms.TextBox();
            this.VB4_AV = new System.Windows.Forms.TextBox();
            this.Dr_Name1_AV = new System.Windows.Forms.TextBox();
            this.Date2_AV = new System.Windows.Forms.DateTimePicker();
            this.Date3_AV = new System.Windows.Forms.DateTimePicker();
            this.Date4_AV = new System.Windows.Forms.DateTimePicker();
            this.NDate2_AV = new System.Windows.Forms.DateTimePicker();
            this.NDate3_AV = new System.Windows.Forms.DateTimePicker();
            this.NDate4_AV = new System.Windows.Forms.DateTimePicker();
            this.Dr_Name5_AV = new System.Windows.Forms.TextBox();
            this.NDate5_AV = new System.Windows.Forms.DateTimePicker();
            this.VB6_AV = new System.Windows.Forms.TextBox();
            this.Date6_AV = new System.Windows.Forms.DateTimePicker();
            this.Dr_Name6_AV = new System.Windows.Forms.TextBox();
            this.NDate6_AV = new System.Windows.Forms.DateTimePicker();
            this.VB7_AV = new System.Windows.Forms.TextBox();
            this.Date7_AV = new System.Windows.Forms.DateTimePicker();
            this.Dr_Name7_AV = new System.Windows.Forms.TextBox();
            this.NDate7_AV = new System.Windows.Forms.DateTimePicker();
            this.VB5_AV = new System.Windows.Forms.TextBox();
            this.Date5_AV = new System.Windows.Forms.DateTimePicker();
            this.VB8_AV = new System.Windows.Forms.TextBox();
            this.Date8_AV = new System.Windows.Forms.DateTimePicker();
            this.Dr_Name8_AV = new System.Windows.Forms.TextBox();
            this.NDate8_AV = new System.Windows.Forms.DateTimePicker();
            this.VB9_AV = new System.Windows.Forms.TextBox();
            this.Date9_AV = new System.Windows.Forms.DateTimePicker();
            this.Dr_Name9_AV = new System.Windows.Forms.TextBox();
            this.NDate9_AV = new System.Windows.Forms.DateTimePicker();
            this.VB10_AV = new System.Windows.Forms.TextBox();
            this.Date10_AV = new System.Windows.Forms.DateTimePicker();
            this.Dr_Name10_AV = new System.Windows.Forms.TextBox();
            this.NDate10_AV = new System.Windows.Forms.DateTimePicker();
            this.VB11_AV = new System.Windows.Forms.TextBox();
            this.Date11_AV = new System.Windows.Forms.DateTimePicker();
            this.Dr_Name11_AV = new System.Windows.Forms.TextBox();
            this.NDate11_AV = new System.Windows.Forms.DateTimePicker();
            this.VB12_AV = new System.Windows.Forms.TextBox();
            this.Date12_AV = new System.Windows.Forms.DateTimePicker();
            this.Dr_Name12_AV = new System.Windows.Forms.TextBox();
            this.NDate12_AV = new System.Windows.Forms.DateTimePicker();
            this.circularButton3 = new Professional_Vets.CircularButton();
            this.circularButton6 = new Professional_Vets.CircularButton();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // button13
            // 
            this.button13.BackColor = System.Drawing.Color.Blue;
            this.button13.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.button13.ForeColor = System.Drawing.Color.White;
            this.button13.Location = new System.Drawing.Point(573, 30);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(299, 23);
            this.button13.TabIndex = 53;
            this.button13.Text = "Notes for Annual Vaccination";
            this.button13.UseCompatibleTextRendering = true;
            this.button13.UseVisualStyleBackColor = false;
            // 
            // rtxt_Notes_AV
            // 
            this.rtxt_Notes_AV.Location = new System.Drawing.Point(573, 59);
            this.rtxt_Notes_AV.Name = "rtxt_Notes_AV";
            this.rtxt_Notes_AV.Size = new System.Drawing.Size(299, 342);
            this.rtxt_Notes_AV.TabIndex = 54;
            this.rtxt_Notes_AV.Text = "Notes";
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.Blue;
            this.button5.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.button5.ForeColor = System.Drawing.Color.White;
            this.button5.Location = new System.Drawing.Point(12, 30);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(336, 23);
            this.button5.TabIndex = 0;
            this.button5.Text = "Annual Vaccination";
            this.button5.UseCompatibleTextRendering = true;
            this.button5.UseVisualStyleBackColor = false;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 4;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.Controls.Add(this.NDate1_AV, 3, 1);
            this.tableLayoutPanel1.Controls.Add(this.Date1_AV, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.Dr_Name4_AV, 2, 4);
            this.tableLayoutPanel1.Controls.Add(this.Dr_Name3_AV, 2, 3);
            this.tableLayoutPanel1.Controls.Add(this.Dr_Name2_AV, 2, 2);
            this.tableLayoutPanel1.Controls.Add(this.VB2_AV, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.button1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.button2, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.button3, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.button4, 3, 0);
            this.tableLayoutPanel1.Controls.Add(this.VB1_AV, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.VB3_AV, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.VB4_AV, 1, 4);
            this.tableLayoutPanel1.Controls.Add(this.Dr_Name1_AV, 2, 1);
            this.tableLayoutPanel1.Controls.Add(this.Date2_AV, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.Date3_AV, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.Date4_AV, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.NDate2_AV, 3, 2);
            this.tableLayoutPanel1.Controls.Add(this.NDate3_AV, 3, 3);
            this.tableLayoutPanel1.Controls.Add(this.NDate4_AV, 3, 4);
            this.tableLayoutPanel1.Controls.Add(this.Dr_Name5_AV, 2, 5);
            this.tableLayoutPanel1.Controls.Add(this.NDate5_AV, 3, 5);
            this.tableLayoutPanel1.Controls.Add(this.VB6_AV, 1, 6);
            this.tableLayoutPanel1.Controls.Add(this.Date6_AV, 0, 6);
            this.tableLayoutPanel1.Controls.Add(this.Dr_Name6_AV, 2, 6);
            this.tableLayoutPanel1.Controls.Add(this.NDate6_AV, 3, 6);
            this.tableLayoutPanel1.Controls.Add(this.VB7_AV, 1, 7);
            this.tableLayoutPanel1.Controls.Add(this.Date7_AV, 0, 7);
            this.tableLayoutPanel1.Controls.Add(this.Dr_Name7_AV, 2, 7);
            this.tableLayoutPanel1.Controls.Add(this.NDate7_AV, 3, 7);
            this.tableLayoutPanel1.Controls.Add(this.VB5_AV, 1, 5);
            this.tableLayoutPanel1.Controls.Add(this.Date5_AV, 0, 5);
            this.tableLayoutPanel1.Controls.Add(this.VB8_AV, 1, 8);
            this.tableLayoutPanel1.Controls.Add(this.Date8_AV, 0, 8);
            this.tableLayoutPanel1.Controls.Add(this.Dr_Name8_AV, 2, 8);
            this.tableLayoutPanel1.Controls.Add(this.NDate8_AV, 3, 8);
            this.tableLayoutPanel1.Controls.Add(this.VB9_AV, 1, 9);
            this.tableLayoutPanel1.Controls.Add(this.Date9_AV, 0, 9);
            this.tableLayoutPanel1.Controls.Add(this.Dr_Name9_AV, 2, 9);
            this.tableLayoutPanel1.Controls.Add(this.NDate9_AV, 3, 9);
            this.tableLayoutPanel1.Controls.Add(this.VB10_AV, 1, 10);
            this.tableLayoutPanel1.Controls.Add(this.Date10_AV, 0, 10);
            this.tableLayoutPanel1.Controls.Add(this.Dr_Name10_AV, 2, 10);
            this.tableLayoutPanel1.Controls.Add(this.NDate10_AV, 3, 10);
            this.tableLayoutPanel1.Controls.Add(this.VB11_AV, 1, 11);
            this.tableLayoutPanel1.Controls.Add(this.Date11_AV, 0, 11);
            this.tableLayoutPanel1.Controls.Add(this.Dr_Name11_AV, 2, 11);
            this.tableLayoutPanel1.Controls.Add(this.NDate11_AV, 3, 11);
            this.tableLayoutPanel1.Controls.Add(this.VB12_AV, 1, 12);
            this.tableLayoutPanel1.Controls.Add(this.Date12_AV, 0, 12);
            this.tableLayoutPanel1.Controls.Add(this.Dr_Name12_AV, 2, 12);
            this.tableLayoutPanel1.Controls.Add(this.NDate12_AV, 3, 12);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(12, 59);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 13;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.Size = new System.Drawing.Size(505, 342);
            this.tableLayoutPanel1.TabIndex = 50;
            // 
            // NDate1_AV
            // 
            this.NDate1_AV.CustomFormat = " ";
            this.NDate1_AV.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.NDate1_AV.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.NDate1_AV.Location = new System.Drawing.Point(370, 30);
            this.NDate1_AV.Name = "NDate1_AV";
            this.NDate1_AV.Size = new System.Drawing.Size(129, 20);
            this.NDate1_AV.TabIndex = 8;
            this.NDate1_AV.Value = new System.DateTime(2000, 1, 1, 0, 0, 0, 0);
            this.NDate1_AV.ValueChanged += new System.EventHandler(this.NDate1_AV_ValueChanged);
            // 
            // Date1_AV
            // 
            this.Date1_AV.CustomFormat = " ";
            this.Date1_AV.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.Date1_AV.Location = new System.Drawing.Point(3, 30);
            this.Date1_AV.Name = "Date1_AV";
            this.Date1_AV.Size = new System.Drawing.Size(129, 20);
            this.Date1_AV.TabIndex = 5;
            this.Date1_AV.Value = new System.DateTime(2000, 1, 1, 0, 0, 0, 0);
            this.Date1_AV.ValueChanged += new System.EventHandler(this.Date1_AV_ValueChanged);
            // 
            // Dr_Name4_AV
            // 
            this.Dr_Name4_AV.Location = new System.Drawing.Point(290, 108);
            this.Dr_Name4_AV.Name = "Dr_Name4_AV";
            this.Dr_Name4_AV.Size = new System.Drawing.Size(74, 20);
            this.Dr_Name4_AV.TabIndex = 19;
            // 
            // Dr_Name3_AV
            // 
            this.Dr_Name3_AV.Location = new System.Drawing.Point(290, 82);
            this.Dr_Name3_AV.Name = "Dr_Name3_AV";
            this.Dr_Name3_AV.Size = new System.Drawing.Size(74, 20);
            this.Dr_Name3_AV.TabIndex = 15;
            // 
            // Dr_Name2_AV
            // 
            this.Dr_Name2_AV.Location = new System.Drawing.Point(290, 56);
            this.Dr_Name2_AV.Name = "Dr_Name2_AV";
            this.Dr_Name2_AV.Size = new System.Drawing.Size(74, 20);
            this.Dr_Name2_AV.TabIndex = 11;
            // 
            // VB2_AV
            // 
            this.VB2_AV.Dock = System.Windows.Forms.DockStyle.Fill;
            this.VB2_AV.Location = new System.Drawing.Point(138, 56);
            this.VB2_AV.Name = "VB2_AV";
            this.VB2_AV.Size = new System.Drawing.Size(146, 20);
            this.VB2_AV.TabIndex = 10;
            this.VB2_AV.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Blue;
            this.button1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button1.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(2, 2);
            this.button1.Margin = new System.Windows.Forms.Padding(2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(131, 23);
            this.button1.TabIndex = 1;
            this.button1.Text = "Date";
            this.button1.UseVisualStyleBackColor = false;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Blue;
            this.button2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button2.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.Location = new System.Drawing.Point(137, 2);
            this.button2.Margin = new System.Windows.Forms.Padding(2);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(148, 23);
            this.button2.TabIndex = 2;
            this.button2.Text = "Vaccine/ Batch No.";
            this.button2.UseVisualStyleBackColor = false;
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.Blue;
            this.button3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button3.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.button3.ForeColor = System.Drawing.Color.White;
            this.button3.Location = new System.Drawing.Point(289, 2);
            this.button3.Margin = new System.Windows.Forms.Padding(2);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(76, 23);
            this.button3.TabIndex = 3;
            this.button3.Text = "Dr. Name";
            this.button3.UseCompatibleTextRendering = true;
            this.button3.UseVisualStyleBackColor = false;
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.Blue;
            this.button4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button4.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.button4.ForeColor = System.Drawing.Color.White;
            this.button4.Location = new System.Drawing.Point(369, 2);
            this.button4.Margin = new System.Windows.Forms.Padding(2);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(134, 23);
            this.button4.TabIndex = 4;
            this.button4.Text = "Next Date";
            this.button4.UseVisualStyleBackColor = false;
            // 
            // VB1_AV
            // 
            this.VB1_AV.Dock = System.Windows.Forms.DockStyle.Fill;
            this.VB1_AV.Location = new System.Drawing.Point(138, 30);
            this.VB1_AV.Name = "VB1_AV";
            this.VB1_AV.Size = new System.Drawing.Size(146, 20);
            this.VB1_AV.TabIndex = 6;
            this.VB1_AV.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // VB3_AV
            // 
            this.VB3_AV.Dock = System.Windows.Forms.DockStyle.Fill;
            this.VB3_AV.Location = new System.Drawing.Point(138, 82);
            this.VB3_AV.Name = "VB3_AV";
            this.VB3_AV.Size = new System.Drawing.Size(146, 20);
            this.VB3_AV.TabIndex = 14;
            this.VB3_AV.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // VB4_AV
            // 
            this.VB4_AV.Dock = System.Windows.Forms.DockStyle.Fill;
            this.VB4_AV.Location = new System.Drawing.Point(138, 108);
            this.VB4_AV.Name = "VB4_AV";
            this.VB4_AV.Size = new System.Drawing.Size(146, 20);
            this.VB4_AV.TabIndex = 18;
            this.VB4_AV.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Dr_Name1_AV
            // 
            this.Dr_Name1_AV.Location = new System.Drawing.Point(290, 30);
            this.Dr_Name1_AV.Name = "Dr_Name1_AV";
            this.Dr_Name1_AV.Size = new System.Drawing.Size(74, 20);
            this.Dr_Name1_AV.TabIndex = 7;
            // 
            // Date2_AV
            // 
            this.Date2_AV.CustomFormat = " ";
            this.Date2_AV.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.Date2_AV.Location = new System.Drawing.Point(3, 56);
            this.Date2_AV.Name = "Date2_AV";
            this.Date2_AV.Size = new System.Drawing.Size(129, 20);
            this.Date2_AV.TabIndex = 9;
            this.Date2_AV.Value = new System.DateTime(2000, 1, 1, 0, 0, 0, 0);
            this.Date2_AV.ValueChanged += new System.EventHandler(this.Date2_AV_ValueChanged);
            // 
            // Date3_AV
            // 
            this.Date3_AV.CustomFormat = " ";
            this.Date3_AV.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.Date3_AV.Location = new System.Drawing.Point(3, 82);
            this.Date3_AV.Name = "Date3_AV";
            this.Date3_AV.Size = new System.Drawing.Size(129, 20);
            this.Date3_AV.TabIndex = 13;
            this.Date3_AV.Value = new System.DateTime(2000, 1, 1, 0, 0, 0, 0);
            this.Date3_AV.ValueChanged += new System.EventHandler(this.Date3_AV_ValueChanged);
            // 
            // Date4_AV
            // 
            this.Date4_AV.CustomFormat = " ";
            this.Date4_AV.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.Date4_AV.Location = new System.Drawing.Point(3, 108);
            this.Date4_AV.Name = "Date4_AV";
            this.Date4_AV.Size = new System.Drawing.Size(129, 20);
            this.Date4_AV.TabIndex = 17;
            this.Date4_AV.Value = new System.DateTime(2000, 1, 1, 0, 0, 0, 0);
            this.Date4_AV.ValueChanged += new System.EventHandler(this.Date4_AV_ValueChanged);
            // 
            // NDate2_AV
            // 
            this.NDate2_AV.CustomFormat = " ";
            this.NDate2_AV.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.NDate2_AV.Location = new System.Drawing.Point(370, 56);
            this.NDate2_AV.Name = "NDate2_AV";
            this.NDate2_AV.Size = new System.Drawing.Size(129, 20);
            this.NDate2_AV.TabIndex = 12;
            this.NDate2_AV.Value = new System.DateTime(2000, 1, 1, 0, 0, 0, 0);
            this.NDate2_AV.ValueChanged += new System.EventHandler(this.NDate2_AV_ValueChanged);
            // 
            // NDate3_AV
            // 
            this.NDate3_AV.CustomFormat = " ";
            this.NDate3_AV.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.NDate3_AV.Location = new System.Drawing.Point(370, 82);
            this.NDate3_AV.Name = "NDate3_AV";
            this.NDate3_AV.Size = new System.Drawing.Size(129, 20);
            this.NDate3_AV.TabIndex = 16;
            this.NDate3_AV.Value = new System.DateTime(2000, 1, 1, 0, 0, 0, 0);
            this.NDate3_AV.ValueChanged += new System.EventHandler(this.NDate3_AV_ValueChanged);
            // 
            // NDate4_AV
            // 
            this.NDate4_AV.CustomFormat = " ";
            this.NDate4_AV.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.NDate4_AV.Location = new System.Drawing.Point(370, 108);
            this.NDate4_AV.Name = "NDate4_AV";
            this.NDate4_AV.Size = new System.Drawing.Size(129, 20);
            this.NDate4_AV.TabIndex = 20;
            this.NDate4_AV.Value = new System.DateTime(2000, 1, 1, 0, 0, 0, 0);
            this.NDate4_AV.ValueChanged += new System.EventHandler(this.NDate4_AV_ValueChanged);
            // 
            // Dr_Name5_AV
            // 
            this.Dr_Name5_AV.Location = new System.Drawing.Point(290, 134);
            this.Dr_Name5_AV.Name = "Dr_Name5_AV";
            this.Dr_Name5_AV.Size = new System.Drawing.Size(74, 20);
            this.Dr_Name5_AV.TabIndex = 23;
            // 
            // NDate5_AV
            // 
            this.NDate5_AV.CustomFormat = " ";
            this.NDate5_AV.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.NDate5_AV.Location = new System.Drawing.Point(370, 134);
            this.NDate5_AV.Name = "NDate5_AV";
            this.NDate5_AV.Size = new System.Drawing.Size(129, 20);
            this.NDate5_AV.TabIndex = 24;
            this.NDate5_AV.Value = new System.DateTime(2000, 1, 1, 0, 0, 0, 0);
            this.NDate5_AV.ValueChanged += new System.EventHandler(this.NDate5_AV_ValueChanged);
            // 
            // VB6_AV
            // 
            this.VB6_AV.Dock = System.Windows.Forms.DockStyle.Fill;
            this.VB6_AV.Location = new System.Drawing.Point(138, 160);
            this.VB6_AV.Name = "VB6_AV";
            this.VB6_AV.Size = new System.Drawing.Size(146, 20);
            this.VB6_AV.TabIndex = 26;
            this.VB6_AV.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Date6_AV
            // 
            this.Date6_AV.CustomFormat = " ";
            this.Date6_AV.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.Date6_AV.Location = new System.Drawing.Point(3, 160);
            this.Date6_AV.Name = "Date6_AV";
            this.Date6_AV.Size = new System.Drawing.Size(129, 20);
            this.Date6_AV.TabIndex = 25;
            this.Date6_AV.Value = new System.DateTime(2000, 1, 1, 0, 0, 0, 0);
            this.Date6_AV.ValueChanged += new System.EventHandler(this.Date6_AV_ValueChanged);
            // 
            // Dr_Name6_AV
            // 
            this.Dr_Name6_AV.Location = new System.Drawing.Point(290, 160);
            this.Dr_Name6_AV.Name = "Dr_Name6_AV";
            this.Dr_Name6_AV.Size = new System.Drawing.Size(74, 20);
            this.Dr_Name6_AV.TabIndex = 27;
            // 
            // NDate6_AV
            // 
            this.NDate6_AV.CustomFormat = " ";
            this.NDate6_AV.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.NDate6_AV.Location = new System.Drawing.Point(370, 160);
            this.NDate6_AV.Name = "NDate6_AV";
            this.NDate6_AV.Size = new System.Drawing.Size(129, 20);
            this.NDate6_AV.TabIndex = 28;
            this.NDate6_AV.Value = new System.DateTime(2000, 1, 1, 0, 0, 0, 0);
            this.NDate6_AV.ValueChanged += new System.EventHandler(this.NDate6_AV_ValueChanged);
            // 
            // VB7_AV
            // 
            this.VB7_AV.Dock = System.Windows.Forms.DockStyle.Fill;
            this.VB7_AV.Location = new System.Drawing.Point(138, 186);
            this.VB7_AV.Name = "VB7_AV";
            this.VB7_AV.Size = new System.Drawing.Size(146, 20);
            this.VB7_AV.TabIndex = 30;
            this.VB7_AV.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Date7_AV
            // 
            this.Date7_AV.CustomFormat = " ";
            this.Date7_AV.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.Date7_AV.Location = new System.Drawing.Point(3, 186);
            this.Date7_AV.Name = "Date7_AV";
            this.Date7_AV.Size = new System.Drawing.Size(129, 20);
            this.Date7_AV.TabIndex = 29;
            this.Date7_AV.Value = new System.DateTime(2000, 1, 1, 0, 0, 0, 0);
            this.Date7_AV.ValueChanged += new System.EventHandler(this.Date7_AV_ValueChanged);
            // 
            // Dr_Name7_AV
            // 
            this.Dr_Name7_AV.Location = new System.Drawing.Point(290, 186);
            this.Dr_Name7_AV.Name = "Dr_Name7_AV";
            this.Dr_Name7_AV.Size = new System.Drawing.Size(74, 20);
            this.Dr_Name7_AV.TabIndex = 31;
            // 
            // NDate7_AV
            // 
            this.NDate7_AV.CustomFormat = " ";
            this.NDate7_AV.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.NDate7_AV.Location = new System.Drawing.Point(370, 186);
            this.NDate7_AV.Name = "NDate7_AV";
            this.NDate7_AV.Size = new System.Drawing.Size(129, 20);
            this.NDate7_AV.TabIndex = 32;
            this.NDate7_AV.Value = new System.DateTime(2000, 1, 1, 0, 0, 0, 0);
            this.NDate7_AV.ValueChanged += new System.EventHandler(this.NDate7_AV_ValueChanged);
            // 
            // VB5_AV
            // 
            this.VB5_AV.Dock = System.Windows.Forms.DockStyle.Fill;
            this.VB5_AV.Location = new System.Drawing.Point(138, 134);
            this.VB5_AV.Name = "VB5_AV";
            this.VB5_AV.Size = new System.Drawing.Size(146, 20);
            this.VB5_AV.TabIndex = 22;
            this.VB5_AV.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Date5_AV
            // 
            this.Date5_AV.CustomFormat = " ";
            this.Date5_AV.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.Date5_AV.Location = new System.Drawing.Point(3, 134);
            this.Date5_AV.Name = "Date5_AV";
            this.Date5_AV.Size = new System.Drawing.Size(129, 20);
            this.Date5_AV.TabIndex = 21;
            this.Date5_AV.Value = new System.DateTime(2000, 1, 1, 0, 0, 0, 0);
            this.Date5_AV.ValueChanged += new System.EventHandler(this.Date5_AV_ValueChanged);
            // 
            // VB8_AV
            // 
            this.VB8_AV.Dock = System.Windows.Forms.DockStyle.Fill;
            this.VB8_AV.Location = new System.Drawing.Point(138, 212);
            this.VB8_AV.Name = "VB8_AV";
            this.VB8_AV.Size = new System.Drawing.Size(146, 20);
            this.VB8_AV.TabIndex = 34;
            this.VB8_AV.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Date8_AV
            // 
            this.Date8_AV.CustomFormat = " ";
            this.Date8_AV.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.Date8_AV.Location = new System.Drawing.Point(3, 212);
            this.Date8_AV.Name = "Date8_AV";
            this.Date8_AV.Size = new System.Drawing.Size(129, 20);
            this.Date8_AV.TabIndex = 33;
            this.Date8_AV.Value = new System.DateTime(2000, 1, 1, 0, 0, 0, 0);
            this.Date8_AV.ValueChanged += new System.EventHandler(this.Date8_AV_ValueChanged);
            // 
            // Dr_Name8_AV
            // 
            this.Dr_Name8_AV.Location = new System.Drawing.Point(290, 212);
            this.Dr_Name8_AV.Name = "Dr_Name8_AV";
            this.Dr_Name8_AV.Size = new System.Drawing.Size(74, 20);
            this.Dr_Name8_AV.TabIndex = 35;
            // 
            // NDate8_AV
            // 
            this.NDate8_AV.CustomFormat = " ";
            this.NDate8_AV.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.NDate8_AV.Location = new System.Drawing.Point(370, 212);
            this.NDate8_AV.Name = "NDate8_AV";
            this.NDate8_AV.Size = new System.Drawing.Size(129, 20);
            this.NDate8_AV.TabIndex = 36;
            this.NDate8_AV.Value = new System.DateTime(2000, 1, 1, 0, 0, 0, 0);
            this.NDate8_AV.ValueChanged += new System.EventHandler(this.NDate8_AV_ValueChanged);
            // 
            // VB9_AV
            // 
            this.VB9_AV.Dock = System.Windows.Forms.DockStyle.Fill;
            this.VB9_AV.Location = new System.Drawing.Point(138, 238);
            this.VB9_AV.Name = "VB9_AV";
            this.VB9_AV.Size = new System.Drawing.Size(146, 20);
            this.VB9_AV.TabIndex = 38;
            this.VB9_AV.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Date9_AV
            // 
            this.Date9_AV.CustomFormat = " ";
            this.Date9_AV.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.Date9_AV.Location = new System.Drawing.Point(3, 238);
            this.Date9_AV.Name = "Date9_AV";
            this.Date9_AV.Size = new System.Drawing.Size(129, 20);
            this.Date9_AV.TabIndex = 37;
            this.Date9_AV.Value = new System.DateTime(2000, 1, 1, 0, 0, 0, 0);
            this.Date9_AV.ValueChanged += new System.EventHandler(this.Date9_AV_ValueChanged);
            // 
            // Dr_Name9_AV
            // 
            this.Dr_Name9_AV.Location = new System.Drawing.Point(290, 238);
            this.Dr_Name9_AV.Name = "Dr_Name9_AV";
            this.Dr_Name9_AV.Size = new System.Drawing.Size(74, 20);
            this.Dr_Name9_AV.TabIndex = 39;
            // 
            // NDate9_AV
            // 
            this.NDate9_AV.CustomFormat = " ";
            this.NDate9_AV.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.NDate9_AV.Location = new System.Drawing.Point(370, 238);
            this.NDate9_AV.Name = "NDate9_AV";
            this.NDate9_AV.Size = new System.Drawing.Size(129, 20);
            this.NDate9_AV.TabIndex = 40;
            this.NDate9_AV.Value = new System.DateTime(2000, 1, 1, 0, 0, 0, 0);
            this.NDate9_AV.ValueChanged += new System.EventHandler(this.NDate9_AV_ValueChanged);
            // 
            // VB10_AV
            // 
            this.VB10_AV.Dock = System.Windows.Forms.DockStyle.Fill;
            this.VB10_AV.Location = new System.Drawing.Point(138, 264);
            this.VB10_AV.Name = "VB10_AV";
            this.VB10_AV.Size = new System.Drawing.Size(146, 20);
            this.VB10_AV.TabIndex = 42;
            this.VB10_AV.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Date10_AV
            // 
            this.Date10_AV.CustomFormat = " ";
            this.Date10_AV.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.Date10_AV.Location = new System.Drawing.Point(3, 264);
            this.Date10_AV.Name = "Date10_AV";
            this.Date10_AV.Size = new System.Drawing.Size(129, 20);
            this.Date10_AV.TabIndex = 41;
            this.Date10_AV.Value = new System.DateTime(2000, 1, 1, 0, 0, 0, 0);
            this.Date10_AV.ValueChanged += new System.EventHandler(this.Date10_AV_ValueChanged);
            // 
            // Dr_Name10_AV
            // 
            this.Dr_Name10_AV.Location = new System.Drawing.Point(290, 264);
            this.Dr_Name10_AV.Name = "Dr_Name10_AV";
            this.Dr_Name10_AV.Size = new System.Drawing.Size(74, 20);
            this.Dr_Name10_AV.TabIndex = 43;
            // 
            // NDate10_AV
            // 
            this.NDate10_AV.CustomFormat = " ";
            this.NDate10_AV.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.NDate10_AV.Location = new System.Drawing.Point(370, 264);
            this.NDate10_AV.Name = "NDate10_AV";
            this.NDate10_AV.Size = new System.Drawing.Size(129, 20);
            this.NDate10_AV.TabIndex = 44;
            this.NDate10_AV.Value = new System.DateTime(2000, 1, 1, 0, 0, 0, 0);
            this.NDate10_AV.ValueChanged += new System.EventHandler(this.NDate10_AV_ValueChanged);
            // 
            // VB11_AV
            // 
            this.VB11_AV.Dock = System.Windows.Forms.DockStyle.Fill;
            this.VB11_AV.Location = new System.Drawing.Point(138, 290);
            this.VB11_AV.Name = "VB11_AV";
            this.VB11_AV.Size = new System.Drawing.Size(146, 20);
            this.VB11_AV.TabIndex = 46;
            this.VB11_AV.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Date11_AV
            // 
            this.Date11_AV.CustomFormat = " ";
            this.Date11_AV.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.Date11_AV.Location = new System.Drawing.Point(3, 290);
            this.Date11_AV.Name = "Date11_AV";
            this.Date11_AV.Size = new System.Drawing.Size(129, 20);
            this.Date11_AV.TabIndex = 45;
            this.Date11_AV.Value = new System.DateTime(2000, 1, 1, 0, 0, 0, 0);
            this.Date11_AV.ValueChanged += new System.EventHandler(this.Date11_AV_ValueChanged);
            // 
            // Dr_Name11_AV
            // 
            this.Dr_Name11_AV.Location = new System.Drawing.Point(290, 290);
            this.Dr_Name11_AV.Name = "Dr_Name11_AV";
            this.Dr_Name11_AV.Size = new System.Drawing.Size(74, 20);
            this.Dr_Name11_AV.TabIndex = 47;
            // 
            // NDate11_AV
            // 
            this.NDate11_AV.CustomFormat = " ";
            this.NDate11_AV.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.NDate11_AV.Location = new System.Drawing.Point(370, 290);
            this.NDate11_AV.Name = "NDate11_AV";
            this.NDate11_AV.Size = new System.Drawing.Size(129, 20);
            this.NDate11_AV.TabIndex = 48;
            this.NDate11_AV.Value = new System.DateTime(2000, 1, 1, 0, 0, 0, 0);
            this.NDate11_AV.ValueChanged += new System.EventHandler(this.NDate11_AV_ValueChanged);
            // 
            // VB12_AV
            // 
            this.VB12_AV.Dock = System.Windows.Forms.DockStyle.Fill;
            this.VB12_AV.Location = new System.Drawing.Point(138, 316);
            this.VB12_AV.Name = "VB12_AV";
            this.VB12_AV.Size = new System.Drawing.Size(146, 20);
            this.VB12_AV.TabIndex = 50;
            this.VB12_AV.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Date12_AV
            // 
            this.Date12_AV.CustomFormat = " ";
            this.Date12_AV.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.Date12_AV.Location = new System.Drawing.Point(3, 316);
            this.Date12_AV.Name = "Date12_AV";
            this.Date12_AV.Size = new System.Drawing.Size(129, 20);
            this.Date12_AV.TabIndex = 49;
            this.Date12_AV.Value = new System.DateTime(2000, 1, 1, 0, 0, 0, 0);
            this.Date12_AV.ValueChanged += new System.EventHandler(this.Date12_AV_ValueChanged);
            // 
            // Dr_Name12_AV
            // 
            this.Dr_Name12_AV.Location = new System.Drawing.Point(290, 316);
            this.Dr_Name12_AV.Name = "Dr_Name12_AV";
            this.Dr_Name12_AV.Size = new System.Drawing.Size(74, 20);
            this.Dr_Name12_AV.TabIndex = 51;
            // 
            // NDate12_AV
            // 
            this.NDate12_AV.CustomFormat = " ";
            this.NDate12_AV.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.NDate12_AV.Location = new System.Drawing.Point(370, 316);
            this.NDate12_AV.Name = "NDate12_AV";
            this.NDate12_AV.Size = new System.Drawing.Size(129, 20);
            this.NDate12_AV.TabIndex = 52;
            this.NDate12_AV.Value = new System.DateTime(2000, 1, 1, 0, 0, 0, 0);
            this.NDate12_AV.ValueChanged += new System.EventHandler(this.NDate12_AV_ValueChanged);
            // 
            // circularButton3
            // 
            this.circularButton3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.circularButton3.AutoSize = true;
            this.circularButton3.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.circularButton3.FlatAppearance.BorderSize = 0;
            this.circularButton3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.circularButton3.Image = ((System.Drawing.Image)(resources.GetObject("circularButton3.Image")));
            this.circularButton3.Location = new System.Drawing.Point(811, 423);
            this.circularButton3.Name = "circularButton3";
            this.circularButton3.Size = new System.Drawing.Size(61, 61);
            this.circularButton3.TabIndex = 60;
            this.circularButton3.UseVisualStyleBackColor = true;
            this.circularButton3.Click += new System.EventHandler(this.circularButton3_Click);
            // 
            // circularButton6
            // 
            this.circularButton6.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.circularButton6.AutoSize = true;
            this.circularButton6.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.circularButton6.FlatAppearance.BorderSize = 0;
            this.circularButton6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.circularButton6.Image = ((System.Drawing.Image)(resources.GetObject("circularButton6.Image")));
            this.circularButton6.Location = new System.Drawing.Point(760, 428);
            this.circularButton6.Name = "circularButton6";
            this.circularButton6.Size = new System.Drawing.Size(56, 56);
            this.circularButton6.TabIndex = 58;
            this.circularButton6.UseVisualStyleBackColor = true;
            this.circularButton6.Click += new System.EventHandler(this.circularButton6_Click);
            // 
            // Annual_Vaccination
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.ClientSize = new System.Drawing.Size(884, 496);
            this.Controls.Add(this.circularButton3);
            this.Controls.Add(this.circularButton6);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Controls.Add(this.button13);
            this.Controls.Add(this.rtxt_Notes_AV);
            this.Controls.Add(this.button5);
            this.Name = "Annual_Vaccination";
            this.Text = "Annual_Vaccination";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Annual_Vaccination_FormClosing);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.RichTextBox rtxt_Notes_AV;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.DateTimePicker NDate1_AV;
        private System.Windows.Forms.DateTimePicker Date1_AV;
        private System.Windows.Forms.TextBox Dr_Name4_AV;
        private System.Windows.Forms.TextBox Dr_Name3_AV;
        private System.Windows.Forms.TextBox Dr_Name2_AV;
        private System.Windows.Forms.TextBox VB2_AV;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.TextBox VB1_AV;
        private System.Windows.Forms.TextBox VB3_AV;
        private System.Windows.Forms.TextBox VB4_AV;
        private System.Windows.Forms.TextBox Dr_Name1_AV;
        private System.Windows.Forms.DateTimePicker Date2_AV;
        private System.Windows.Forms.DateTimePicker Date3_AV;
        private System.Windows.Forms.DateTimePicker Date4_AV;
        private System.Windows.Forms.DateTimePicker NDate2_AV;
        private System.Windows.Forms.DateTimePicker NDate3_AV;
        private System.Windows.Forms.DateTimePicker NDate4_AV;
        private System.Windows.Forms.TextBox Dr_Name5_AV;
        private System.Windows.Forms.DateTimePicker NDate5_AV;
        private System.Windows.Forms.TextBox VB6_AV;
        private System.Windows.Forms.DateTimePicker Date6_AV;
        private System.Windows.Forms.TextBox Dr_Name6_AV;
        private System.Windows.Forms.DateTimePicker NDate6_AV;
        private System.Windows.Forms.TextBox VB7_AV;
        private System.Windows.Forms.DateTimePicker Date7_AV;
        private System.Windows.Forms.TextBox Dr_Name7_AV;
        private System.Windows.Forms.DateTimePicker NDate7_AV;
        private System.Windows.Forms.TextBox VB5_AV;
        private System.Windows.Forms.DateTimePicker Date5_AV;
        private System.Windows.Forms.TextBox VB8_AV;
        private System.Windows.Forms.DateTimePicker Date8_AV;
        private System.Windows.Forms.TextBox Dr_Name8_AV;
        private System.Windows.Forms.DateTimePicker NDate8_AV;
        private System.Windows.Forms.TextBox VB9_AV;
        private System.Windows.Forms.DateTimePicker Date9_AV;
        private System.Windows.Forms.TextBox Dr_Name9_AV;
        private System.Windows.Forms.DateTimePicker NDate9_AV;
        private System.Windows.Forms.TextBox VB10_AV;
        private System.Windows.Forms.DateTimePicker Date10_AV;
        private System.Windows.Forms.TextBox Dr_Name10_AV;
        private System.Windows.Forms.DateTimePicker NDate10_AV;
        private System.Windows.Forms.TextBox VB11_AV;
        private System.Windows.Forms.DateTimePicker Date11_AV;
        private System.Windows.Forms.TextBox Dr_Name11_AV;
        private System.Windows.Forms.DateTimePicker NDate11_AV;
        private System.Windows.Forms.TextBox VB12_AV;
        private System.Windows.Forms.DateTimePicker Date12_AV;
        private System.Windows.Forms.TextBox Dr_Name12_AV;
        private System.Windows.Forms.DateTimePicker NDate12_AV;
        private CircularButton circularButton3;
        private CircularButton circularButton6;
    }
}