﻿namespace Professional_Vets
{
    partial class Vaccination_Records
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Vaccination_Records));
            this.cobo_Species = new System.Windows.Forms.ComboBox();
            this.cobo_Sex = new System.Windows.Forms.ComboBox();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.Date_of_neuter_or_spay = new System.Windows.Forms.Button();
            this.Breed = new System.Windows.Forms.Button();
            this.txt_Breed = new System.Windows.Forms.TextBox();
            this.Sex = new System.Windows.Forms.Button();
            this.Species = new System.Windows.Forms.Button();
            this.Date_of_Birth = new System.Windows.Forms.Button();
            this.Pet_Name = new System.Windows.Forms.Button();
            this.txt_PetName = new System.Windows.Forms.TextBox();
            this.txt_Color_Eyes = new System.Windows.Forms.TextBox();
            this.txt_Color_Hair = new System.Windows.Forms.TextBox();
            this.txt_IR = new System.Windows.Forms.TextBox();
            this.Color_Eyes = new System.Windows.Forms.Button();
            this.Color_Hair = new System.Windows.Forms.Button();
            this.IR = new System.Windows.Forms.Button();
            this.Description = new System.Windows.Forms.Button();
            this.rtxt_Description = new System.Windows.Forms.RichTextBox();
            this.txt_Date_of_Birth = new System.Windows.Forms.DateTimePicker();
            this.txt_Date_of_neuter_or_spay = new System.Windows.Forms.DateTimePicker();
            this.button5 = new System.Windows.Forms.Button();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.Email = new System.Windows.Forms.Button();
            this.txt_Mobile = new System.Windows.Forms.TextBox();
            this.Mobile = new System.Windows.Forms.Button();
            this.Tel_No = new System.Windows.Forms.Button();
            this.Address = new System.Windows.Forms.Button();
            this.Owner_Button = new System.Windows.Forms.Button();
            this.txt_Owner = new System.Windows.Forms.TextBox();
            this.rtxt_Address = new System.Windows.Forms.TextBox();
            this.txt_Email = new System.Windows.Forms.RichTextBox();
            this.txt_Tel_No = new System.Windows.Forms.TextBox();
            this.button18 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.rtxt_Notes = new System.Windows.Forms.RichTextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.dtp_date = new System.Windows.Forms.DateTimePicker();
            this.label6 = new System.Windows.Forms.Label();
            this.circularButton2 = new Professional_Vets.CircularButton();
            this.circularButton5 = new Professional_Vets.CircularButton();
            this.tableLayoutPanel3.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // cobo_Species
            // 
            this.cobo_Species.FormattingEnabled = true;
            this.cobo_Species.Items.AddRange(new object[] {
            "CANINE",
            "FELINE"});
            this.cobo_Species.Location = new System.Drawing.Point(222, 57);
            this.cobo_Species.Name = "cobo_Species";
            this.cobo_Species.Size = new System.Drawing.Size(213, 21);
            this.cobo_Species.TabIndex = 6;
            // 
            // cobo_Sex
            // 
            this.cobo_Sex.FormattingEnabled = true;
            this.cobo_Sex.Items.AddRange(new object[] {
            "Male",
            "Female"});
            this.cobo_Sex.Location = new System.Drawing.Point(221, 83);
            this.cobo_Sex.Margin = new System.Windows.Forms.Padding(2);
            this.cobo_Sex.Name = "cobo_Sex";
            this.cobo_Sex.Size = new System.Drawing.Size(214, 21);
            this.cobo_Sex.TabIndex = 8;
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.AutoSize = true;
            this.tableLayoutPanel3.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.tableLayoutPanel3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.tableLayoutPanel3.ColumnCount = 2;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.Controls.Add(this.Date_of_neuter_or_spay, 0, 5);
            this.tableLayoutPanel3.Controls.Add(this.Breed, 0, 4);
            this.tableLayoutPanel3.Controls.Add(this.txt_Breed, 1, 4);
            this.tableLayoutPanel3.Controls.Add(this.Sex, 0, 3);
            this.tableLayoutPanel3.Controls.Add(this.Species, 0, 2);
            this.tableLayoutPanel3.Controls.Add(this.Date_of_Birth, 0, 1);
            this.tableLayoutPanel3.Controls.Add(this.Pet_Name, 0, 0);
            this.tableLayoutPanel3.Controls.Add(this.txt_PetName, 1, 0);
            this.tableLayoutPanel3.Controls.Add(this.cobo_Species, 1, 2);
            this.tableLayoutPanel3.Controls.Add(this.txt_Color_Eyes, 1, 6);
            this.tableLayoutPanel3.Controls.Add(this.txt_Color_Hair, 1, 7);
            this.tableLayoutPanel3.Controls.Add(this.txt_IR, 1, 8);
            this.tableLayoutPanel3.Controls.Add(this.Color_Eyes, 0, 6);
            this.tableLayoutPanel3.Controls.Add(this.Color_Hair, 0, 7);
            this.tableLayoutPanel3.Controls.Add(this.IR, 0, 8);
            this.tableLayoutPanel3.Controls.Add(this.Description, 0, 9);
            this.tableLayoutPanel3.Controls.Add(this.rtxt_Description, 1, 9);
            this.tableLayoutPanel3.Controls.Add(this.cobo_Sex, 1, 3);
            this.tableLayoutPanel3.Controls.Add(this.txt_Date_of_Birth, 1, 1);
            this.tableLayoutPanel3.Controls.Add(this.txt_Date_of_neuter_or_spay, 1, 5);
            this.tableLayoutPanel3.Location = new System.Drawing.Point(12, 89);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 10;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel3.Size = new System.Drawing.Size(438, 271);
            this.tableLayoutPanel3.TabIndex = 23;
            // 
            // Date_of_neuter_or_spay
            // 
            this.Date_of_neuter_or_spay.BackColor = System.Drawing.SystemColors.Control;
            this.Date_of_neuter_or_spay.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Date_of_neuter_or_spay.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.Date_of_neuter_or_spay.ForeColor = System.Drawing.Color.DarkBlue;
            this.Date_of_neuter_or_spay.Location = new System.Drawing.Point(2, 137);
            this.Date_of_neuter_or_spay.Margin = new System.Windows.Forms.Padding(2);
            this.Date_of_neuter_or_spay.Name = "Date_of_neuter_or_spay";
            this.Date_of_neuter_or_spay.Size = new System.Drawing.Size(215, 23);
            this.Date_of_neuter_or_spay.TabIndex = 11;
            this.Date_of_neuter_or_spay.Text = "Date of neuter or spay";
            this.Date_of_neuter_or_spay.UseCompatibleTextRendering = true;
            this.Date_of_neuter_or_spay.UseVisualStyleBackColor = false;
            this.Date_of_neuter_or_spay.Click += new System.EventHandler(this.button11_Click);
            // 
            // Breed
            // 
            this.Breed.BackColor = System.Drawing.SystemColors.Control;
            this.Breed.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Breed.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.Breed.ForeColor = System.Drawing.Color.DarkBlue;
            this.Breed.Location = new System.Drawing.Point(2, 110);
            this.Breed.Margin = new System.Windows.Forms.Padding(2);
            this.Breed.Name = "Breed";
            this.Breed.Size = new System.Drawing.Size(215, 23);
            this.Breed.TabIndex = 9;
            this.Breed.Text = "Breed";
            this.Breed.UseCompatibleTextRendering = true;
            this.Breed.UseVisualStyleBackColor = false;
            // 
            // txt_Breed
            // 
            this.txt_Breed.Location = new System.Drawing.Point(222, 111);
            this.txt_Breed.Name = "txt_Breed";
            this.txt_Breed.Size = new System.Drawing.Size(213, 20);
            this.txt_Breed.TabIndex = 10;
            // 
            // Sex
            // 
            this.Sex.BackColor = System.Drawing.SystemColors.Control;
            this.Sex.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Sex.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.Sex.ForeColor = System.Drawing.Color.DarkBlue;
            this.Sex.Location = new System.Drawing.Point(2, 83);
            this.Sex.Margin = new System.Windows.Forms.Padding(2);
            this.Sex.Name = "Sex";
            this.Sex.Size = new System.Drawing.Size(215, 23);
            this.Sex.TabIndex = 7;
            this.Sex.Text = "Sex";
            this.Sex.UseCompatibleTextRendering = true;
            this.Sex.UseVisualStyleBackColor = false;
            // 
            // Species
            // 
            this.Species.BackColor = System.Drawing.SystemColors.Control;
            this.Species.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Species.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.Species.ForeColor = System.Drawing.Color.DarkBlue;
            this.Species.Location = new System.Drawing.Point(2, 56);
            this.Species.Margin = new System.Windows.Forms.Padding(2);
            this.Species.Name = "Species";
            this.Species.Size = new System.Drawing.Size(215, 23);
            this.Species.TabIndex = 5;
            this.Species.Text = "Species";
            this.Species.UseCompatibleTextRendering = true;
            this.Species.UseVisualStyleBackColor = false;
            // 
            // Date_of_Birth
            // 
            this.Date_of_Birth.BackColor = System.Drawing.SystemColors.Control;
            this.Date_of_Birth.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Date_of_Birth.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.Date_of_Birth.ForeColor = System.Drawing.Color.DarkBlue;
            this.Date_of_Birth.Location = new System.Drawing.Point(2, 29);
            this.Date_of_Birth.Margin = new System.Windows.Forms.Padding(2);
            this.Date_of_Birth.Name = "Date_of_Birth";
            this.Date_of_Birth.Size = new System.Drawing.Size(215, 23);
            this.Date_of_Birth.TabIndex = 3;
            this.Date_of_Birth.Text = "Date of Birth";
            this.Date_of_Birth.UseCompatibleTextRendering = true;
            this.Date_of_Birth.UseVisualStyleBackColor = false;
            // 
            // Pet_Name
            // 
            this.Pet_Name.BackColor = System.Drawing.SystemColors.Control;
            this.Pet_Name.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Pet_Name.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.Pet_Name.ForeColor = System.Drawing.Color.DarkBlue;
            this.Pet_Name.Location = new System.Drawing.Point(2, 2);
            this.Pet_Name.Margin = new System.Windows.Forms.Padding(2);
            this.Pet_Name.Name = "Pet_Name";
            this.Pet_Name.Size = new System.Drawing.Size(215, 23);
            this.Pet_Name.TabIndex = 1;
            this.Pet_Name.Text = "PET Name";
            this.Pet_Name.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.Pet_Name.UseCompatibleTextRendering = true;
            this.Pet_Name.UseVisualStyleBackColor = false;
            // 
            // txt_PetName
            // 
            this.txt_PetName.Location = new System.Drawing.Point(222, 3);
            this.txt_PetName.Name = "txt_PetName";
            this.txt_PetName.Size = new System.Drawing.Size(213, 20);
            this.txt_PetName.TabIndex = 2;
            // 
            // txt_Color_Eyes
            // 
            this.txt_Color_Eyes.Location = new System.Drawing.Point(222, 165);
            this.txt_Color_Eyes.Name = "txt_Color_Eyes";
            this.txt_Color_Eyes.Size = new System.Drawing.Size(213, 20);
            this.txt_Color_Eyes.TabIndex = 14;
            // 
            // txt_Color_Hair
            // 
            this.txt_Color_Hair.Location = new System.Drawing.Point(222, 192);
            this.txt_Color_Hair.Name = "txt_Color_Hair";
            this.txt_Color_Hair.Size = new System.Drawing.Size(213, 20);
            this.txt_Color_Hair.TabIndex = 16;
            // 
            // txt_IR
            // 
            this.txt_IR.Location = new System.Drawing.Point(222, 219);
            this.txt_IR.Name = "txt_IR";
            this.txt_IR.Size = new System.Drawing.Size(213, 20);
            this.txt_IR.TabIndex = 18;
            // 
            // Color_Eyes
            // 
            this.Color_Eyes.BackColor = System.Drawing.SystemColors.Control;
            this.Color_Eyes.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Color_Eyes.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.Color_Eyes.ForeColor = System.Drawing.Color.DarkBlue;
            this.Color_Eyes.Location = new System.Drawing.Point(2, 164);
            this.Color_Eyes.Margin = new System.Windows.Forms.Padding(2);
            this.Color_Eyes.Name = "Color_Eyes";
            this.Color_Eyes.Size = new System.Drawing.Size(215, 23);
            this.Color_Eyes.TabIndex = 13;
            this.Color_Eyes.Text = "Color/ eyes";
            this.Color_Eyes.UseCompatibleTextRendering = true;
            this.Color_Eyes.UseVisualStyleBackColor = false;
            this.Color_Eyes.Click += new System.EventHandler(this.button1_Click);
            // 
            // Color_Hair
            // 
            this.Color_Hair.BackColor = System.Drawing.SystemColors.Control;
            this.Color_Hair.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Color_Hair.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.Color_Hair.ForeColor = System.Drawing.Color.DarkBlue;
            this.Color_Hair.Location = new System.Drawing.Point(2, 191);
            this.Color_Hair.Margin = new System.Windows.Forms.Padding(2);
            this.Color_Hair.Name = "Color_Hair";
            this.Color_Hair.Size = new System.Drawing.Size(215, 23);
            this.Color_Hair.TabIndex = 15;
            this.Color_Hair.Text = "Color/ hair";
            this.Color_Hair.UseCompatibleTextRendering = true;
            this.Color_Hair.UseVisualStyleBackColor = false;
            // 
            // IR
            // 
            this.IR.BackColor = System.Drawing.SystemColors.Control;
            this.IR.Dock = System.Windows.Forms.DockStyle.Fill;
            this.IR.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.IR.ForeColor = System.Drawing.Color.DarkBlue;
            this.IR.Location = new System.Drawing.Point(2, 218);
            this.IR.Margin = new System.Windows.Forms.Padding(2);
            this.IR.Name = "IR";
            this.IR.Size = new System.Drawing.Size(215, 23);
            this.IR.TabIndex = 17;
            this.IR.Text = "IR (identification and Registration)";
            this.IR.UseCompatibleTextRendering = true;
            this.IR.UseVisualStyleBackColor = false;
            // 
            // Description
            // 
            this.Description.BackColor = System.Drawing.SystemColors.Control;
            this.Description.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Description.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.Description.ForeColor = System.Drawing.Color.DarkBlue;
            this.Description.Location = new System.Drawing.Point(2, 245);
            this.Description.Margin = new System.Windows.Forms.Padding(2);
            this.Description.Name = "Description";
            this.Description.Size = new System.Drawing.Size(215, 24);
            this.Description.TabIndex = 19;
            this.Description.Text = "Description";
            this.Description.UseCompatibleTextRendering = true;
            this.Description.UseVisualStyleBackColor = false;
            // 
            // rtxt_Description
            // 
            this.rtxt_Description.Location = new System.Drawing.Point(221, 245);
            this.rtxt_Description.Margin = new System.Windows.Forms.Padding(2);
            this.rtxt_Description.Name = "rtxt_Description";
            this.rtxt_Description.Size = new System.Drawing.Size(214, 21);
            this.rtxt_Description.TabIndex = 20;
            this.rtxt_Description.Text = "";
            // 
            // txt_Date_of_Birth
            // 
            this.txt_Date_of_Birth.CustomFormat = " ";
            this.txt_Date_of_Birth.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.txt_Date_of_Birth.Location = new System.Drawing.Point(222, 30);
            this.txt_Date_of_Birth.Name = "txt_Date_of_Birth";
            this.txt_Date_of_Birth.Size = new System.Drawing.Size(213, 20);
            this.txt_Date_of_Birth.TabIndex = 4;
            this.txt_Date_of_Birth.Value = new System.DateTime(2000, 1, 1, 0, 0, 0, 0);
            this.txt_Date_of_Birth.ValueChanged += new System.EventHandler(this.txt_Date_of_Birth_ValueChanged);
            // 
            // txt_Date_of_neuter_or_spay
            // 
            this.txt_Date_of_neuter_or_spay.CustomFormat = " ";
            this.txt_Date_of_neuter_or_spay.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.txt_Date_of_neuter_or_spay.Location = new System.Drawing.Point(222, 138);
            this.txt_Date_of_neuter_or_spay.Name = "txt_Date_of_neuter_or_spay";
            this.txt_Date_of_neuter_or_spay.Size = new System.Drawing.Size(213, 20);
            this.txt_Date_of_neuter_or_spay.TabIndex = 12;
            this.txt_Date_of_neuter_or_spay.Value = new System.DateTime(2000, 1, 1, 0, 0, 0, 0);
            this.txt_Date_of_neuter_or_spay.ValueChanged += new System.EventHandler(this.txt_Date_of_neuter_or_spay_ValueChanged);
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.Blue;
            this.button5.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.button5.ForeColor = System.Drawing.Color.White;
            this.button5.Location = new System.Drawing.Point(12, 60);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(336, 23);
            this.button5.TabIndex = 0;
            this.button5.Text = "PET INFORMATION";
            this.button5.UseCompatibleTextRendering = true;
            this.button5.UseVisualStyleBackColor = false;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.AutoSize = true;
            this.tableLayoutPanel1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Controls.Add(this.Email, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.txt_Mobile, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.Mobile, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.Tel_No, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.Address, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.Owner_Button, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.txt_Owner, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.rtxt_Address, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.txt_Email, 1, 4);
            this.tableLayoutPanel1.Controls.Add(this.txt_Tel_No, 1, 2);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(12, 402);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 5;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(446, 137);
            this.tableLayoutPanel1.TabIndex = 25;
            // 
            // Email
            // 
            this.Email.BackColor = System.Drawing.SystemColors.Control;
            this.Email.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Email.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.Email.ForeColor = System.Drawing.Color.DarkBlue;
            this.Email.Location = new System.Drawing.Point(2, 110);
            this.Email.Margin = new System.Windows.Forms.Padding(2);
            this.Email.Name = "Email";
            this.Email.Size = new System.Drawing.Size(219, 25);
            this.Email.TabIndex = 30;
            this.Email.Text = "Email";
            this.Email.UseCompatibleTextRendering = true;
            this.Email.UseVisualStyleBackColor = false;
            // 
            // txt_Mobile
            // 
            this.txt_Mobile.Location = new System.Drawing.Point(226, 84);
            this.txt_Mobile.Name = "txt_Mobile";
            this.txt_Mobile.Size = new System.Drawing.Size(217, 20);
            this.txt_Mobile.TabIndex = 29;
            this.txt_Mobile.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_Mobile_KeyPress);
            // 
            // Mobile
            // 
            this.Mobile.BackColor = System.Drawing.SystemColors.Control;
            this.Mobile.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Mobile.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.Mobile.ForeColor = System.Drawing.Color.DarkBlue;
            this.Mobile.Location = new System.Drawing.Point(2, 83);
            this.Mobile.Margin = new System.Windows.Forms.Padding(2);
            this.Mobile.Name = "Mobile";
            this.Mobile.Size = new System.Drawing.Size(219, 23);
            this.Mobile.TabIndex = 28;
            this.Mobile.Text = "Mobile";
            this.Mobile.UseCompatibleTextRendering = true;
            this.Mobile.UseVisualStyleBackColor = false;
            // 
            // Tel_No
            // 
            this.Tel_No.BackColor = System.Drawing.SystemColors.Control;
            this.Tel_No.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Tel_No.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.Tel_No.ForeColor = System.Drawing.Color.DarkBlue;
            this.Tel_No.Location = new System.Drawing.Point(2, 56);
            this.Tel_No.Margin = new System.Windows.Forms.Padding(2);
            this.Tel_No.Name = "Tel_No";
            this.Tel_No.Size = new System.Drawing.Size(219, 23);
            this.Tel_No.TabIndex = 26;
            this.Tel_No.Text = "Tel No.";
            this.Tel_No.UseCompatibleTextRendering = true;
            this.Tel_No.UseVisualStyleBackColor = false;
            // 
            // Address
            // 
            this.Address.BackColor = System.Drawing.SystemColors.Control;
            this.Address.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Address.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.Address.ForeColor = System.Drawing.Color.DarkBlue;
            this.Address.Location = new System.Drawing.Point(2, 29);
            this.Address.Margin = new System.Windows.Forms.Padding(2);
            this.Address.Name = "Address";
            this.Address.Size = new System.Drawing.Size(219, 23);
            this.Address.TabIndex = 24;
            this.Address.Text = "Address";
            this.Address.UseCompatibleTextRendering = true;
            this.Address.UseVisualStyleBackColor = false;
            // 
            // Owner_Button
            // 
            this.Owner_Button.BackColor = System.Drawing.SystemColors.Control;
            this.Owner_Button.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Owner_Button.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.Owner_Button.ForeColor = System.Drawing.Color.DarkBlue;
            this.Owner_Button.Location = new System.Drawing.Point(2, 2);
            this.Owner_Button.Margin = new System.Windows.Forms.Padding(2);
            this.Owner_Button.Name = "Owner_Button";
            this.Owner_Button.Size = new System.Drawing.Size(219, 23);
            this.Owner_Button.TabIndex = 22;
            this.Owner_Button.Text = "Owner Name";
            this.Owner_Button.UseCompatibleTextRendering = true;
            this.Owner_Button.UseVisualStyleBackColor = false;
            // 
            // txt_Owner
            // 
            this.txt_Owner.Location = new System.Drawing.Point(226, 3);
            this.txt_Owner.Name = "txt_Owner";
            this.txt_Owner.Size = new System.Drawing.Size(217, 20);
            this.txt_Owner.TabIndex = 23;
            // 
            // rtxt_Address
            // 
            this.rtxt_Address.Location = new System.Drawing.Point(226, 30);
            this.rtxt_Address.Name = "rtxt_Address";
            this.rtxt_Address.Size = new System.Drawing.Size(217, 20);
            this.rtxt_Address.TabIndex = 25;
            // 
            // txt_Email
            // 
            this.txt_Email.Location = new System.Drawing.Point(226, 111);
            this.txt_Email.Name = "txt_Email";
            this.txt_Email.Size = new System.Drawing.Size(217, 23);
            this.txt_Email.TabIndex = 31;
            this.txt_Email.Text = "";
            this.txt_Email.TextChanged += new System.EventHandler(this.rtxt_Address1_TextChanged);
            // 
            // txt_Tel_No
            // 
            this.txt_Tel_No.Location = new System.Drawing.Point(226, 57);
            this.txt_Tel_No.Name = "txt_Tel_No";
            this.txt_Tel_No.Size = new System.Drawing.Size(217, 20);
            this.txt_Tel_No.TabIndex = 27;
            this.txt_Tel_No.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_Tel_No_KeyPress);
            // 
            // button18
            // 
            this.button18.BackColor = System.Drawing.Color.Blue;
            this.button18.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.button18.ForeColor = System.Drawing.Color.White;
            this.button18.Location = new System.Drawing.Point(12, 373);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(336, 23);
            this.button18.TabIndex = 21;
            this.button18.Text = "OWNER INFORMATION";
            this.button18.UseCompatibleTextRendering = true;
            this.button18.UseVisualStyleBackColor = false;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Blue;
            this.button2.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.Location = new System.Drawing.Point(512, 60);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(276, 23);
            this.button2.TabIndex = 32;
            this.button2.Text = "Notes for Vaccination Info";
            this.button2.UseCompatibleTextRendering = true;
            this.button2.UseVisualStyleBackColor = false;
            // 
            // rtxt_Notes
            // 
            this.rtxt_Notes.Location = new System.Drawing.Point(512, 89);
            this.rtxt_Notes.Name = "rtxt_Notes";
            this.rtxt_Notes.Size = new System.Drawing.Size(276, 353);
            this.rtxt_Notes.TabIndex = 33;
            this.rtxt_Notes.Text = "Notes";
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panel1.BackColor = System.Drawing.SystemColors.Highlight;
            this.panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel1.Controls.Add(this.dtp_date);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Location = new System.Drawing.Point(0, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(798, 51);
            this.panel1.TabIndex = 36;
            // 
            // dtp_date
            // 
            this.dtp_date.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.dtp_date.Location = new System.Drawing.Point(652, 14);
            this.dtp_date.Name = "dtp_date";
            this.dtp_date.Size = new System.Drawing.Size(136, 20);
            this.dtp_date.TabIndex = 1;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.SystemColors.Highlight;
            this.label6.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold);
            this.label6.Location = new System.Drawing.Point(20, 15);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(234, 19);
            this.label6.TabIndex = 0;
            this.label6.Text = "My Pet Vaccination Records";
            // 
            // circularButton2
            // 
            this.circularButton2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.circularButton2.AutoSize = true;
            this.circularButton2.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.circularButton2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.circularButton2.FlatAppearance.BorderSize = 0;
            this.circularButton2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.circularButton2.Image = ((System.Drawing.Image)(resources.GetObject("circularButton2.Image")));
            this.circularButton2.Location = new System.Drawing.Point(732, 494);
            this.circularButton2.Name = "circularButton2";
            this.circularButton2.Size = new System.Drawing.Size(56, 56);
            this.circularButton2.TabIndex = 35;
            this.circularButton2.UseVisualStyleBackColor = true;
            this.circularButton2.Click += new System.EventHandler(this.circularButton2_Click);
            // 
            // circularButton5
            // 
            this.circularButton5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.circularButton5.AutoSize = true;
            this.circularButton5.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.circularButton5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.circularButton5.FlatAppearance.BorderSize = 0;
            this.circularButton5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.circularButton5.Image = ((System.Drawing.Image)(resources.GetObject("circularButton5.Image")));
            this.circularButton5.Location = new System.Drawing.Point(676, 494);
            this.circularButton5.Name = "circularButton5";
            this.circularButton5.Size = new System.Drawing.Size(56, 56);
            this.circularButton5.TabIndex = 34;
            this.circularButton5.UseVisualStyleBackColor = true;
            this.circularButton5.Click += new System.EventHandler(this.circularButton5_Click);
            // 
            // Vaccination_Records
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.ClientSize = new System.Drawing.Size(800, 562);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.circularButton2);
            this.Controls.Add(this.circularButton5);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.rtxt_Notes);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Controls.Add(this.button18);
            this.Controls.Add(this.tableLayoutPanel3);
            this.Controls.Add(this.button5);
            this.Name = "Vaccination_Records";
            this.Text = "Vaccination_Records";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Vaccination_Records_FormClosing);
            this.Load += new System.EventHandler(this.Vaccination_Records_Load);
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel3.PerformLayout();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.ComboBox cobo_Species;
        private System.Windows.Forms.ComboBox cobo_Sex;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.Button Date_of_neuter_or_spay;
        private System.Windows.Forms.Button Breed;
        private System.Windows.Forms.TextBox txt_Breed;
        private System.Windows.Forms.Button Sex;
        private System.Windows.Forms.Button Species;
        private System.Windows.Forms.Button Date_of_Birth;
        private System.Windows.Forms.Button Pet_Name;
        private System.Windows.Forms.TextBox txt_PetName;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.TextBox txt_Color_Eyes;
        private System.Windows.Forms.TextBox txt_Color_Hair;
        private System.Windows.Forms.TextBox txt_IR;
        private System.Windows.Forms.Button Color_Eyes;
        private System.Windows.Forms.Button Color_Hair;
        private System.Windows.Forms.Button IR;
        private System.Windows.Forms.Button Description;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Button Email;
        private System.Windows.Forms.TextBox txt_Mobile;
        private System.Windows.Forms.Button Mobile;
        private System.Windows.Forms.Button Tel_No;
        private System.Windows.Forms.Button Address;
        private System.Windows.Forms.Button Owner_Button;
        private System.Windows.Forms.TextBox txt_Owner;
        private System.Windows.Forms.TextBox rtxt_Address;
        private System.Windows.Forms.TextBox txt_Tel_No;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.RichTextBox rtxt_Notes;
        private System.Windows.Forms.RichTextBox rtxt_Description;
        private System.Windows.Forms.RichTextBox txt_Email;
        private CircularButton circularButton2;
        private CircularButton circularButton5;
        private System.Windows.Forms.DateTimePicker txt_Date_of_Birth;
        private System.Windows.Forms.DateTimePicker txt_Date_of_neuter_or_spay;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.DateTimePicker dtp_date;
        private System.Windows.Forms.Label label6;
    }
}