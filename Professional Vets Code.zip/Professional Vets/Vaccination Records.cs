﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Professional_Vets
{
    public partial class Vaccination_Records : Form
    {
        String vn, ow, mb, pt;

        SqlCommand cmd;
        SqlConnection con;

        public Vaccination_Records(String role)
        {
            InitializeComponent();
            vn = role;
            

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void textBox15_TextChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void button11_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void Vaccination_Records_Load(object sender, EventArgs e)
        {

        }

        private void txt_Tel_No_KeyPress(object sender, KeyPressEventArgs e)
        {
            //For enter number only

            if ((e.KeyChar >= 48 && e.KeyChar <= 57) || e.KeyChar == 8)
            {


                e.Handled = false;

            }
            else
            {
                MessageBox.Show("Please Enter only Number.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                e.Handled = true;

            }

        }

        private void txt_Mobile_KeyPress(object sender, KeyPressEventArgs e)
        {
            //For enter number only

            if ((e.KeyChar >= 48 && e.KeyChar <= 57) || e.KeyChar == 8)
            {


                e.Handled = false;

            }
            else
            {
                MessageBox.Show("Please Enter only Number.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                e.Handled = true;

            }

        }

        private void circularButton5_Click(object sender, EventArgs e)
        {
            this.Hide();
            HomePage HP = new HomePage(vn);
            HP.ShowDialog();
        }

        private void circularButton2_Click(object sender, EventArgs e)
        {
            con = new SqlConnection(Properties.Settings.Default.Database1ConnectionString);
            con.Open();

            cmd = new SqlCommand("Insert INTO Vaccination_Records(Date, Vet_Name, Pet, Date_of_Birth, Species, Breed, Sex, Date_of_neuter_or_Spay, Color_Eyes, Color_Hair, IR, Description, Owner, Address, Tel, Mobile, Email, Notes) VALUES (@Date, @Vet_Name, @Pet, @Date_of_Birth, @Species, @Breed, @Sex, @Date_of_neuter_or_Spay, @Color_Eyes, @Color_Hair, @IR, @Description, @Owner, @Address, @Tel, @Mobile, @Email, @Notes)", con);

            //vn
            cmd.Parameters.AddWithValue("@Vet_Name", vn);
            cmd.Parameters.AddWithValue("@Date", dtp_date.Value.ToShortDateString());

            // Pet Info
            cmd.Parameters.AddWithValue("@Pet", txt_PetName.Text);
            cmd.Parameters.AddWithValue("@Date_of_Birth", txt_Date_of_Birth.Value.ToShortDateString());

            // Species
            if (cobo_Species.SelectedItem != null)
            {
                cmd.Parameters.AddWithValue("@Species", cobo_Species.SelectedItem.ToString());
            }
            else
            { cmd.Parameters.AddWithValue("@Species", "null"); }

            // Sex
            if (cobo_Sex.SelectedItem != null)
            {
                cmd.Parameters.AddWithValue("@Sex", cobo_Sex.SelectedItem.ToString());
            }
            else
            { cmd.Parameters.AddWithValue("@Sex", "null"); }


            cmd.Parameters.AddWithValue("@Breed", txt_Breed.Text);
            cmd.Parameters.AddWithValue("@Date_of_neuter_or_Spay", txt_Date_of_neuter_or_spay.Value.ToShortDateString());
            cmd.Parameters.AddWithValue("@Color_Eyes", txt_Color_Eyes.Text);
            cmd.Parameters.AddWithValue("@Color_Hair", txt_Color_Hair.Text);
            cmd.Parameters.AddWithValue("@IR", txt_IR.Text);
            cmd.Parameters.AddWithValue("@Description", rtxt_Description.Text);

            // Owner Info
            cmd.Parameters.AddWithValue("@Owner", txt_Owner.Text);
            cmd.Parameters.AddWithValue("@Address", rtxt_Address.Text);
            cmd.Parameters.AddWithValue("@Tel", txt_Tel_No.Text.ToString());
            cmd.Parameters.AddWithValue("@Mobile", txt_Mobile.Text.ToString());
            cmd.Parameters.AddWithValue("@Email", txt_Email.Text);

            cmd.Parameters.AddWithValue("@Notes", rtxt_Notes.Text);


            cmd.ExecuteNonQuery();
            con.Close();


            ow = txt_Owner.Text;
            mb = txt_Mobile.Text;
            pt = txt_PetName.Text;


            this.Hide();
            Primary_Vaccination PV = new Primary_Vaccination(vn, ow, mb, pt);
            PV.ShowDialog();

        }

        private void txt_Date_of_Birth_ValueChanged(object sender, EventArgs e)
        {
            txt_Date_of_Birth.CustomFormat = "dd/MM/yyyy";
        }

        private void txt_Date_of_neuter_or_spay_ValueChanged(object sender, EventArgs e)
        {
            txt_Date_of_neuter_or_spay.CustomFormat = "dd/MM/yyyy";
        }

        private void Vaccination_Records_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.Hide();
            HomePage HP = new HomePage(vn);
            HP.ShowDialog();
        }

 

        private void circularButton3_Click(object sender, EventArgs e)
        {
            
        }

        private void circularButton1_Click(object sender, EventArgs e)
        {
            
        }

        private void rtxt_Address1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}