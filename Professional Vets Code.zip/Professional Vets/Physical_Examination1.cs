﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Professional_Vets
{
    
    public partial class Physical_Examination1 : Form
    {
        String vn, ow, mb, pt;
        DateTime dat;
        
        SqlCommand cmd;
        SqlConnection con;

        // Strings for NAT (Nose and Throat)
        String N_NAT, ND_NAT, ITh_NAT, ITe_NAT;

        // Strings for MTG (Mouth, Teeth, Gums)
        String N_MTG, B_MTG, L_MTG, UL_MTG, Py_MTG, Gg_MTG, S_MTG;

        // Strings for MLL (Mussuloskeletal)
        String N_MLL;

        // Strings for Heart
        String SNH, ARH, MRH;

        // Strings for Abdomen
        String NAB, EAB, MAB, FAB;

        private void Physical_Examination1_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.Hide();
            HomePage HP = new HomePage(vn);
            HP.ShowDialog();
        }

        private void circularButton1_Click(object sender, EventArgs e)
        {
            this.Hide();
            HomePage HP = new HomePage(vn);
            HP.ShowDialog();
        }
        

        // Strings for Lungs
        String NSLU, ANSLU, BDLU, CLU, CgLU;



        public Physical_Examination1(String role, String Owner, String Mobile, String Pet, DateTime dat1)
        {
            InitializeComponent();
            vn = role;
            ow = Owner;
            mb = Mobile;
            pt = Pet;
            dat = dat1;

        }

        private void checkBox10_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            
        }

        private void checkBox12_CheckedChanged(object sender, EventArgs e)
        {
            txt_Other_NAT.Visible = (ch_Other_NAT.CheckState == CheckState.Checked);
        }

        private void Physical_Examination1_Load(object sender, EventArgs e)
        {
            ////// Nose and Throat
            ////////checkBox12 & textBox6/////////
            if (ch_Other_NAT.Checked)
            {
                txt_Other_NAT.Visible = true;
            }
            else
            {
                txt_Other_NAT.Visible = false;
            }


            //////Mouth, Teeth, Gums
            ////////checkBox23 & comboBox13/////////
            if (ch_Tartar_Degree_MTG.Checked)
            {
                cobo_Tartar_MTG.Visible = true;
            }
            else
            {
                cobo_Tartar_MTG.Visible = false;
            }


            //////////// Mussuloskeletal
            ////////checkBox20 & comboBox7/////////
            if (ch_Lameness_MLL.Checked)
            {
                cobo_Lameness_MLL.Visible = true;
            }
            else
            {
                cobo_Lameness_MLL.Visible = false;
            }


            ////////checkBox21 & comboBox8/////////
            if (ch_Pain_on_Palpation_MLL.Checked)
            {
                cobo_PoP_MLL.Visible = true;
            }
            else
            {
                cobo_PoP_MLL.Visible = false;
            }


            /////////////Heart
            ////////checkBox32 & textBox1/////////
            if (ch_Other_H.Checked)
            {
                txt_Other_H.Visible = true;
            }
            else
            {
                txt_Other_H.Visible = false;
            }

            /////////////Abdomen
            ///////////checkBox22 & textBox2/////////
            if (ch_Other_AB.Checked)
            {
                txt_Other_AB.Visible = true;
            }
            else
            {
                txt_Other_AB.Visible = false;
            }

            /////////////Lungs
            ///////////checkBox27 & textBox3/////////
            if (ch_Other_LU.Checked)
            {
                txt_Other_LU.Visible = true;
            }
            else
            {
                txt_Other_LU.Visible = false;
            }




        }

        private void checkBox23_CheckedChanged(object sender, EventArgs e)
        {
            cobo_Tartar_MTG.Visible = (ch_Tartar_Degree_MTG.CheckState == CheckState.Checked);
        }

        private void checkBox20_CheckedChanged(object sender, EventArgs e)
        {
            cobo_Lameness_MLL.Visible = (ch_Lameness_MLL.CheckState == CheckState.Checked);
        }

        private void checkBox21_CheckedChanged(object sender, EventArgs e)
        {
            cobo_PoP_MLL.Visible = (ch_Pain_on_Palpation_MLL.CheckState == CheckState.Checked);
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void checkBox32_CheckedChanged(object sender, EventArgs e)
        {
            txt_Other_H.Visible = (ch_Other_H.CheckState == CheckState.Checked);
        }

        private void checkBox22_CheckedChanged(object sender, EventArgs e)
        {
            txt_Other_AB.Visible = (ch_Other_AB.CheckState == CheckState.Checked);
        }

        private void checkBox27_CheckedChanged(object sender, EventArgs e)
        {
            txt_Other_LU.Visible = (ch_Other_LU.CheckState == CheckState.Checked);
        }

        private void circularButton3_Click(object sender, EventArgs e)
        {
            //IF Statement for Nose and Throat (NAT)
            N_NAT = ch_Normal_NAT.Checked == true ? "Yes" : "No";
            ND_NAT = ch_Nasal_Discharge_NAT.Checked == true ? "Yes" : "No";
            ITh_NAT = ch_Inf_Throat_NAT.Checked == true ? "Yes" : "No";
            ITe_NAT = ch_Inf_Tensile_NAT.Checked == true ? "Yes" : "No";

            // IF Statement for MTG (Mouth, Teeth, Gums)
            N_MTG = ch_Normal_MTG.Checked == true ? "Yes" : "No";
            B_MTG = ch_Broken_MTG.Checked == true ? "Yes" : "No";
            L_MTG = ch_Loose_MTG.Checked == true ? "Yes" : "No";
            UL_MTG = ch_Ulcers_Lesions_MTG.Checked == true ? "Yes" : "No";
            Py_MTG = ch_Pyorrhea_MTG.Checked == true ? "Yes" : "No";
            Gg_MTG = ch_Gingivitis_MTG.Checked == true ? "Yes" : "No";
            S_MTG = ch_Stain_MTG.Checked == true ? "Yes" : "No";

            // IF Statement for MLL (Mussuloskeletal)
            N_MLL = ch_Normal_MLL.Checked == true ? "Yes" : "No";

            // IF Statement for Heart
            SNH = ch_Sounds_Normal_H.Checked == true ? "Yes" : "No";
            ARH = ch_Arrhythmia_H.Checked == true ? "Yes" : "No";
            MRH = ch_Murmur_H.Checked == true ? "Yes" : "No";

            // IF Statement for Abdoen
            NAB = ch_Normal_AB.Checked == true ? "Yes" : "No";
            EAB = ch_Enlarged_AB.Checked == true ? "Yes" : "No";
            MAB = ch_Mass_AB.Checked == true ? "Yes" : "No";
            FAB = ch_Fluid_AB.Checked == true ? "Yes" : "No";

            // IF Statement for Lungs
            NSLU = ch_Normal_Sound_LU.Checked == true ? "Yes" : "No";
            ANSLU = ch_Abnormal_Sound_LU.Checked == true ? "Yes" : "No";
            BDLU = ch_Breathing_Difficulty_LU.Checked == true ? "Yes" : "No";
            CLU = ch_Coughing_LU.Checked == true ? "Yes" : "No";
            CgLU = ch_Congestion_LU.Checked == true ? "Yes" : "No";



            // Connect with DataBase
            con = new SqlConnection(Properties.Settings.Default.Database1ConnectionString);
            con.Open();

            cmd = new SqlCommand("Insert INTO Ph_Ex1(Date, Vet_Name, Owner, Mobile, Pet, Normal_NAT, Nasal_Discharge_NAT, Inf_Throat_NAT, Inf_Tensile_NAT, Other_NAT, Normal_MTG, Broken_MTG, Loose_MTG, Ulcers_Lesions_MTG, Pyorrhea_MTG, Gingivitis_MTG, Stain_MTG, Tartar_Degree_MTG, Normal_MLL, Lameness_MLL, Pain_on_Palpation_MLL, Sounds_Normal_H, Arrhythmia_H, Murmur_H, Other_H, Normal_AB, Enlarged_AB, Mass_AB, Fluid_AB, Other_AB, Normal_Sound_LU, Abnormal_Sound_LU, Breathing_Difficulty_LU, Coughing_LU, Congestion_LU, Other_LU) VALUES (@Date, @Vet_Name, @Owner, @Mobile, @Pet, @Normal_NAT, @Nasal_Discharge_NAT, @Inf_Throat_NAT, @Inf_Tensile_NAT, @Other_NAT, @Normal_MTG, @Broken_MTG, @Loose_MTG, @Ulcers_Lesions_MTG, @Pyorrhea_MTG, @Gingivitis_MTG, @Stain_MTG, @Tartar_Degree_MTG, @Normal_MLL, @Lameness_MLL, @Pain_on_Palpation_MLL, @Sounds_Normal_H, @Arrhythmia_H, @Murmur_H, @Other_H, @Normal_AB, @Enlarged_AB, @Mass_AB, @Fluid_AB, @Other_AB, @Normal_Sound_LU, @Abnormal_Sound_LU, @Breathing_Difficulty_LU, @Coughing_LU, @Congestion_LU, @Other_LU)", con);

            // Vet_Name, Owner, Mobile, Pet
            cmd.Parameters.AddWithValue("@Vet_Name", vn);
            cmd.Parameters.AddWithValue("@Owner", ow);
            cmd.Parameters.AddWithValue("@Mobile", mb);
            cmd.Parameters.AddWithValue("@Pet", pt);
            //            cmd.Parameters.AddWithValue("@Date", DateTime.Now);
            cmd.Parameters.AddWithValue("@Date", dat);

            // Nose and Throat (NAT)
            cmd.Parameters.AddWithValue("@Normal_NAT", N_NAT);
            cmd.Parameters.AddWithValue("@Nasal_Discharge_NAT", ND_NAT);
            cmd.Parameters.AddWithValue("@Inf_Throat_NAT", ITh_NAT);
            cmd.Parameters.AddWithValue("@Inf_Tensile_NAT", ITe_NAT);
            cmd.Parameters.AddWithValue("@Other_NAT", txt_Other_NAT.Text);

            // MTG(Mouth, Teeth, Gums)
            cmd.Parameters.AddWithValue("@Normal_MTG", N_MTG);
            cmd.Parameters.AddWithValue("@Broken_MTG", B_MTG);
            cmd.Parameters.AddWithValue("@Loose_MTG", L_MTG);
            cmd.Parameters.AddWithValue("@Ulcers_Lesions_MTG", UL_MTG);
            cmd.Parameters.AddWithValue("@Pyorrhea_MTG", Py_MTG);
            cmd.Parameters.AddWithValue("@Gingivitis_MTG", Gg_MTG);
            cmd.Parameters.AddWithValue("@Stain_MTG", S_MTG);

            //Tartar Degree

            if (cobo_Tartar_MTG.SelectedItem != null)
            {
                cmd.Parameters.AddWithValue("@Tartar_Degree_MTG", cobo_Tartar_MTG.SelectedItem.ToString());
            }
            else
            { cmd.Parameters.AddWithValue("@Tartar_Degree_MTG", "null"); }

            // MLL(Mussuloskeletal)
            cmd.Parameters.AddWithValue("@Normal_MLL", N_MLL);

            // Lameness

            if (cobo_Lameness_MLL.SelectedItem != null)
            {
                cmd.Parameters.AddWithValue("@Lameness_MLL", cobo_Lameness_MLL.SelectedItem.ToString());
            }
            else
            { cmd.Parameters.AddWithValue("@Lameness_MLL", "null"); }

            // Pain_on_Palpation

            if (cobo_PoP_MLL.SelectedItem != null)
            {
                cmd.Parameters.AddWithValue("@Pain_on_Palpation_MLL", cobo_PoP_MLL.SelectedItem.ToString());
            }
            else
            { cmd.Parameters.AddWithValue("@Pain_on_Palpation_MLL", "null"); }


            // Heart 
            cmd.Parameters.AddWithValue("@Sounds_Normal_H", SNH);
            cmd.Parameters.AddWithValue("@Arrhythmia_H", ARH);
            cmd.Parameters.AddWithValue("@Murmur_H", MRH);
            cmd.Parameters.AddWithValue("@Other_H", txt_Other_H.Text);

            // Abdomen
            cmd.Parameters.AddWithValue("@Normal_AB", NAB);
            cmd.Parameters.AddWithValue("@Enlarged_AB", EAB);
            cmd.Parameters.AddWithValue("@Mass_AB", MAB);
            cmd.Parameters.AddWithValue("@Fluid_AB", FAB);
            cmd.Parameters.AddWithValue("@Other_AB", txt_Other_AB.Text);


            // Lungs
            cmd.Parameters.AddWithValue("@Normal_Sound_LU", NSLU);
            cmd.Parameters.AddWithValue("@Abnormal_Sound_LU", ANSLU);
            cmd.Parameters.AddWithValue("@Breathing_Difficulty_LU", BDLU);
            cmd.Parameters.AddWithValue("@Coughing_LU", CLU);
            cmd.Parameters.AddWithValue("@Congestion_LU", CgLU);
            cmd.Parameters.AddWithValue("@Other_LU", txt_Other_LU.Text);



            cmd.ExecuteNonQuery();
            con.Close();


            // Open the Next Form
            this.Hide();
            Physical_Examination2 PhE2 = new Physical_Examination2(vn, ow, mb, pt, dat);
            PhE2.ShowDialog();

        }
    }
}
