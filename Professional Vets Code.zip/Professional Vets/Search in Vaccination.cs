﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Professional_Vets
{
    public partial class Search_in_Vaccination : Form
    {
        String vn;

        public static SqlConnection con = new SqlConnection(Properties.Settings.Default.Database1ConnectionString);

        String Id;
        int Id1;
        int delete_Id;


        public Search_in_Vaccination(String role)
        {
            InitializeComponent();
            vn = role;
        }

        private void Search_in_Vaccination_Load(object sender, EventArgs e)
        {
            if (con.State == ConnectionState.Open)
            {
                con.Close();
            }

            con.Open();
            fill_grid();
            fill_grid1();
            fill_grid2();
            fill_grid3();
            fill_grid4();


            con = new SqlConnection(Properties.Settings.Default.Database1ConnectionString);
            con.Open();

            SqlDataAdapter dataAdp = new SqlDataAdapter("select * from Vaccination_Records", con);
            SqlDataAdapter dataAdp0 = new SqlDataAdapter("select * from Primary_VR", con);
            SqlDataAdapter dataAdp1 = new SqlDataAdapter("select * from WFC", con);
            SqlDataAdapter dataAdp2 = new SqlDataAdapter("select * from Other_Vaccine", con);
            SqlDataAdapter dataAdp3 = new SqlDataAdapter("select * from Annual_Vaccination", con);

            DataTable dt = new DataTable("Vaccination_Records");
            DataTable dt0 = new DataTable("Primary_VR");
            DataTable dt1 = new DataTable("WFC");
            DataTable dt2 = new DataTable("Other_Vaccine");
            DataTable dt3 = new DataTable("Annual_Vaccination");

            dataAdp.Fill(dt);
            dataAdp0.Fill(dt0);
            dataAdp1.Fill(dt1);
            dataAdp2.Fill(dt2);
            dataAdp3.Fill(dt3);

            dataGridView.DataSource = dt;
            dataGridView1.DataSource = dt0;
            dataGridView2.DataSource = dt1;
            dataGridView3.DataSource = dt2;
            dataGridView4.DataSource = dt3;

        }

        private void dataGridView_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            Id = dataGridView.Rows[e.RowIndex].Cells["No"].Value.ToString();
            if (Id == "")
            {
                Id1 = 0;
            }

            else
            {
                Id1 = Convert.ToInt32(dataGridView.Rows[e.RowIndex].Cells["No"].Value.ToString());
            }

            if (Id1 == 0)
            {
                SqlCommand cmd = con.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "Insert into Vaccination_Records Vaues ('" + dataGridView.Rows[e.RowIndex].Cells["Pet"].Value.ToString() + "', '" + dataGridView.Rows[e.RowIndex].Cells["Species"].Value.ToString() + "', '" + dataGridView.Rows[e.RowIndex].Cells["Breed"].Value.ToString() + "', '" + dataGridView.Rows[e.RowIndex].Cells["Sex"].Value.ToString() + "', '" + dataGridView.Rows[e.RowIndex].Cells["Color_Eyes"].Value.ToString() + "', '" + dataGridView.Rows[e.RowIndex].Cells["Color_Hair"].Value.ToString() + "', '" + dataGridView.Rows[e.RowIndex].Cells["IR"].Value.ToString() + "', '" + dataGridView.Rows[e.RowIndex].Cells["Description"].Value.ToString() + "', '" + dataGridView.Rows[e.RowIndex].Cells["Owner"].Value.ToString() + "', '" + dataGridView.Rows[e.RowIndex].Cells["Address"].Value.ToString() + "', '" + dataGridView.Rows[e.RowIndex].Cells["Tel"].Value.ToString() + "', '" + dataGridView.Rows[e.RowIndex].Cells["Mobile"].Value.ToString() + "', '" + dataGridView.Rows[e.RowIndex].Cells["Email"].Value.ToString() + "', '" + dataGridView.Rows[e.RowIndex].Cells["Notes"].Value.ToString() + "', '" + dataGridView.Rows[e.RowIndex].Cells["Species"].Value.ToString() + "')";

                cmd.ExecuteNonQuery();
                fill_grid();
            }

            else
            {
                SqlCommand cmd = con.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "Update Vaccination_Records set Pet ='" + dataGridView.Rows[e.RowIndex].Cells["Pet"].Value.ToString() + "', Species ='" + dataGridView.Rows[e.RowIndex].Cells["Species"].Value.ToString() + "', Breed ='" + dataGridView.Rows[e.RowIndex].Cells["Breed"].Value.ToString() + "', Sex ='" + dataGridView.Rows[e.RowIndex].Cells["Sex"].Value.ToString() + "', Color_Eyes ='" + dataGridView.Rows[e.RowIndex].Cells["Color_Eyes"].Value.ToString() + "', Color_Hair ='" + dataGridView.Rows[e.RowIndex].Cells["Color_Hair"].Value.ToString() + "', IR ='" + dataGridView.Rows[e.RowIndex].Cells["IR"].Value.ToString() + "', Description ='" + dataGridView.Rows[e.RowIndex].Cells["Description"].Value.ToString() + "', Owner ='" + dataGridView.Rows[e.RowIndex].Cells["Owner"].Value.ToString() + "', Address ='" + dataGridView.Rows[e.RowIndex].Cells["Address"].Value.ToString() + "', Tel ='" + dataGridView.Rows[e.RowIndex].Cells["Tel"].Value.ToString() + "', Mobile ='" + dataGridView.Rows[e.RowIndex].Cells["Mobile"].Value.ToString() + "', Email ='" + dataGridView.Rows[e.RowIndex].Cells["Email"].Value.ToString() + "', Notes ='" + dataGridView.Rows[e.RowIndex].Cells["Notes"].Value.ToString() + "' Where No= " + Id1 + "";

                cmd.ExecuteNonQuery();

                MessageBox.Show("The Data was Updated");
                fill_grid();

            }
        }

        private void dataGridView1_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            Id = dataGridView1.Rows[e.RowIndex].Cells["No"].Value.ToString();
            if (Id == "")
            {
                Id1 = 0;
            }

            else
            {
                Id1 = Convert.ToInt32(dataGridView1.Rows[e.RowIndex].Cells["No"].Value.ToString());
            }

            if (Id1 == 0)
            {
                SqlCommand cmd1 = con.CreateCommand();
                cmd1.CommandType = CommandType.Text;
                cmd1.CommandText = "Insert into Primary_VR Vaues ('" + dataGridView1.Rows[e.RowIndex].Cells["Owner"].Value.ToString() + "', '" + dataGridView1.Rows[e.RowIndex].Cells["Mobile"].Value.ToString() + "', '" + dataGridView1.Rows[e.RowIndex].Cells["Pet"].Value.ToString() + "', '" + dataGridView1.Rows[e.RowIndex].Cells["Vaccine_Batch_1"].Value.ToString() + "', '" + dataGridView1.Rows[e.RowIndex].Cells["Vaccine_Batch_2"].Value.ToString() + "', '" + dataGridView1.Rows[e.RowIndex].Cells["Vaccine_Batch_3"].Value.ToString() + "', '" + dataGridView1.Rows[e.RowIndex].Cells["Vaccine_Batch_4"].Value.ToString() + "', '" + dataGridView1.Rows[e.RowIndex].Cells["Food_Type"].Value.ToString() + "', '" + dataGridView1.Rows[e.RowIndex].Cells["Weight"].Value.ToString() + "', '" + dataGridView1.Rows[e.RowIndex].Cells["Body_Score"].Value.ToString() + "', '" + dataGridView1.Rows[e.RowIndex].Cells["Teeth_Health"].Value.ToString() + "', '" + dataGridView1.Rows[e.RowIndex].Cells["Notes"].Value.ToString() + "')";

                cmd1.ExecuteNonQuery();
                fill_grid1();
            }

            else
            {
                SqlCommand cmd1 = con.CreateCommand();
                cmd1.CommandType = CommandType.Text;
                cmd1.CommandText = "Update Primary_VR set Owner ='" + dataGridView1.Rows[e.RowIndex].Cells["Owner"].Value.ToString() + "', Mobile ='" + dataGridView1.Rows[e.RowIndex].Cells["Mobile"].Value.ToString() + "', Pet ='" + dataGridView1.Rows[e.RowIndex].Cells["Pet"].Value.ToString() + "', Vaccine_Batch_1 ='" + dataGridView1.Rows[e.RowIndex].Cells["Vaccine_Batch_1"].Value.ToString() + "', Vaccine_Batch_2 ='" + dataGridView1.Rows[e.RowIndex].Cells["Vaccine_Batch_2"].Value.ToString() + "', Vaccine_Batch_3 ='" + dataGridView1.Rows[e.RowIndex].Cells["Vaccine_Batch_3"].Value.ToString() + "', Vaccine_Batch_4 ='" + dataGridView1.Rows[e.RowIndex].Cells["Vaccine_Batch_4"].Value.ToString() + "', Food_Type ='" + dataGridView1.Rows[e.RowIndex].Cells["Food_Type"].Value.ToString() + "',  Weight ='" + dataGridView1.Rows[e.RowIndex].Cells["Weight"].Value.ToString() + "', Body_Score ='" + dataGridView1.Rows[e.RowIndex].Cells["Body_Score"].Value.ToString() + "', Teeth_Health ='" + dataGridView1.Rows[e.RowIndex].Cells["Teeth_Health"].Value.ToString() + "', Notes ='" + dataGridView1.Rows[e.RowIndex].Cells["Notes"].Value.ToString() + "' Where No= " + Id1 + "";

                cmd1.ExecuteNonQuery();

                MessageBox.Show("The Data was Updated");
                fill_grid1();

            }
        }

        private void dataGridView2_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            Id = dataGridView2.Rows[e.RowIndex].Cells["No"].Value.ToString();
            if (Id == "")
            {
                Id1 = 0;
            }

            else
            {
                Id1 = Convert.ToInt32(dataGridView2.Rows[e.RowIndex].Cells["No"].Value.ToString());
            }

            if (Id1 == 0)
            {
                SqlCommand cmd2 = con.CreateCommand();
                cmd2.CommandType = CommandType.Text;
                cmd2.CommandText = "Insert into WFC Vaues ('" + dataGridView2.Rows[e.RowIndex].Cells["Owner"].Value.ToString() + "', '" + dataGridView2.Rows[e.RowIndex].Cells["Mobile"].Value.ToString() + "', '" + dataGridView2.Rows[e.RowIndex].Cells["Pet"].Value.ToString() + "', '" + dataGridView2.Rows[e.RowIndex].Cells["Vaccine_Batch_1"].Value.ToString() + "', '" + dataGridView2.Rows[e.RowIndex].Cells["Vaccine_Batch_2"].Value.ToString() + "', '" + dataGridView2.Rows[e.RowIndex].Cells["Vaccine_Batch_3"].Value.ToString() + "', '" + dataGridView2.Rows[e.RowIndex].Cells["Vaccine_Batch_4"].Value.ToString() + "', '" + dataGridView2.Rows[e.RowIndex].Cells["Vaccine_Batch_5"].Value.ToString() + "', '" + dataGridView2.Rows[e.RowIndex].Cells["Vaccine_Batch_6"].Value.ToString() + "', '" + dataGridView2.Rows[e.RowIndex].Cells["Vaccine_Batch_7"].Value.ToString() + "', '" + dataGridView2.Rows[e.RowIndex].Cells["Vaccine_Batch_8"].Value.ToString() + "', '" + dataGridView2.Rows[e.RowIndex].Cells["Vaccine_Batch_9"].Value.ToString() + "', '" + dataGridView2.Rows[e.RowIndex].Cells["Vaccine_Batch_10"].Value.ToString() + "', '" + dataGridView2.Rows[e.RowIndex].Cells["Vaccine_Batch_11"].Value.ToString() + "', '" + dataGridView2.Rows[e.RowIndex].Cells["Vaccine_Batch_12"].Value.ToString() + "', '" + dataGridView2.Rows[e.RowIndex].Cells["Notes"].Value.ToString() + "')";

                cmd2.ExecuteNonQuery();
                fill_grid2();
            }

            else
            {
                SqlCommand cmd2 = con.CreateCommand();
                cmd2.CommandType = CommandType.Text;
                cmd2.CommandText = "Update WFC set Owner ='" + dataGridView2.Rows[e.RowIndex].Cells["Owner"].Value.ToString() + "', Mobile ='" + dataGridView2.Rows[e.RowIndex].Cells["Mobile"].Value.ToString() + "', Pet ='" + dataGridView2.Rows[e.RowIndex].Cells["Pet"].Value.ToString() + "', Vaccine_Batch_1 ='" + dataGridView2.Rows[e.RowIndex].Cells["Vaccine_Batch_1"].Value.ToString() + "', Vaccine_Batch_2 ='" + dataGridView2.Rows[e.RowIndex].Cells["Vaccine_Batch_2"].Value.ToString() + "', Vaccine_Batch_3 ='" + dataGridView2.Rows[e.RowIndex].Cells["Vaccine_Batch_3"].Value.ToString() + "', Vaccine_Batch_4 ='" + dataGridView2.Rows[e.RowIndex].Cells["Vaccine_Batch_4"].Value.ToString() + "', Vaccine_Batch_5 ='" + dataGridView2.Rows[e.RowIndex].Cells["Vaccine_Batch_5"].Value.ToString() + "', Vaccine_Batch_6 ='" + dataGridView2.Rows[e.RowIndex].Cells["Vaccine_Batch_6"].Value.ToString() + "', Vaccine_Batch_7 ='" + dataGridView2.Rows[e.RowIndex].Cells["Vaccine_Batch_7"].Value.ToString() + "', Vaccine_Batch_8 ='" + dataGridView2.Rows[e.RowIndex].Cells["Vaccine_Batch_8"].Value.ToString() + "', Vaccine_Batch_9 ='" + dataGridView2.Rows[e.RowIndex].Cells["Vaccine_Batch_9"].Value.ToString() + "', Vaccine_Batch_10 ='" + dataGridView2.Rows[e.RowIndex].Cells["Vaccine_Batch_10"].Value.ToString() + "', Vaccine_Batch_11 ='" + dataGridView2.Rows[e.RowIndex].Cells["Vaccine_Batch_11"].Value.ToString() + "', Vaccine_Batch_12 ='" + dataGridView2.Rows[e.RowIndex].Cells["Vaccine_Batch_12"].Value.ToString() + "',  Notes ='" + dataGridView2.Rows[e.RowIndex].Cells["Notes"].Value.ToString() + "' Where No= " + Id1 + "";

                cmd2.ExecuteNonQuery();

                MessageBox.Show("The Data was Updated");
                fill_grid2();

            }
        }

        private void dataGridView3_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            Id = dataGridView3.Rows[e.RowIndex].Cells["No"].Value.ToString();
            if (Id == "")
            {
                Id1 = 0;
            }

            else
            {
                Id1 = Convert.ToInt32(dataGridView3.Rows[e.RowIndex].Cells["No"].Value.ToString());
            }

            if (Id1 == 0)
            {
                SqlCommand cmd3 = con.CreateCommand();
                cmd3.CommandType = CommandType.Text;
                cmd3.CommandText = "Insert into Other_Vaccine Vaues ('" + dataGridView3.Rows[e.RowIndex].Cells["Owner"].Value.ToString() + "', '" + dataGridView3.Rows[e.RowIndex].Cells["Mobile"].Value.ToString() + "', '" + dataGridView3.Rows[e.RowIndex].Cells["Pet"].Value.ToString() + "', '" + dataGridView3.Rows[e.RowIndex].Cells["Vaccine_Batch_1"].Value.ToString() + "', '" + dataGridView3.Rows[e.RowIndex].Cells["Vaccine_Batch_2"].Value.ToString() + "', '" + dataGridView3.Rows[e.RowIndex].Cells["Vaccine_Batch_3"].Value.ToString() + "', '" + dataGridView3.Rows[e.RowIndex].Cells["Vaccine_Batch_4"].Value.ToString() + "', '" + dataGridView3.Rows[e.RowIndex].Cells["Vaccine_Batch_5"].Value.ToString() + "', '" + dataGridView3.Rows[e.RowIndex].Cells["Vaccine_Batch_6"].Value.ToString() + "',  '" + dataGridView3.Rows[e.RowIndex].Cells["Notes"].Value.ToString() + "')";

                cmd3.ExecuteNonQuery();
                fill_grid3();
            }

            else
            {
                SqlCommand cmd3 = con.CreateCommand();
                cmd3.CommandType = CommandType.Text;
                cmd3.CommandText = "Update Other_Vaccine set Owner ='" + dataGridView3.Rows[e.RowIndex].Cells["Owner"].Value.ToString() + "', Mobile ='" + dataGridView3.Rows[e.RowIndex].Cells["Mobile"].Value.ToString() + "', Pet ='" + dataGridView3.Rows[e.RowIndex].Cells["Pet"].Value.ToString() + "', Vaccine_Batch_1 ='" + dataGridView3.Rows[e.RowIndex].Cells["Vaccine_Batch_1"].Value.ToString() + "', Vaccine_Batch_2 ='" + dataGridView3.Rows[e.RowIndex].Cells["Vaccine_Batch_2"].Value.ToString() + "', Vaccine_Batch_3 ='" + dataGridView3.Rows[e.RowIndex].Cells["Vaccine_Batch_3"].Value.ToString() + "', Vaccine_Batch_4 ='" + dataGridView3.Rows[e.RowIndex].Cells["Vaccine_Batch_4"].Value.ToString() + "', Vaccine_Batch_5 ='" + dataGridView3.Rows[e.RowIndex].Cells["Vaccine_Batch_5"].Value.ToString() + "', Vaccine_Batch_6 ='" + dataGridView3.Rows[e.RowIndex].Cells["Vaccine_Batch_6"].Value.ToString() + "', Notes ='" + dataGridView3.Rows[e.RowIndex].Cells["Notes"].Value.ToString() + "' Where No= " + Id1 + "";

                cmd3.ExecuteNonQuery();

                MessageBox.Show("The Data was Updated");
                fill_grid3();

            }
        }

        private void dataGridView4_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            Id = dataGridView4.Rows[e.RowIndex].Cells["No"].Value.ToString();
            if (Id == "")
            {
                Id1 = 0;
            }

            else
            {
                Id1 = Convert.ToInt32(dataGridView4.Rows[e.RowIndex].Cells["No"].Value.ToString());
            }

            if (Id1 == 0)
            {
                SqlCommand cmd4 = con.CreateCommand();
                cmd4.CommandType = CommandType.Text;
                cmd4.CommandText = "Insert into Annual_Vaccination Vaues ('" + dataGridView4.Rows[e.RowIndex].Cells["Owner"].Value.ToString() + "', '" + dataGridView4.Rows[e.RowIndex].Cells["Mobile"].Value.ToString() + "', '" + dataGridView4.Rows[e.RowIndex].Cells["Pet"].Value.ToString() + "', '" + dataGridView4.Rows[e.RowIndex].Cells["Vaccine_Batch_1"].Value.ToString() + "', '" + dataGridView4.Rows[e.RowIndex].Cells["Vaccine_Batch_2"].Value.ToString() + "', '" + dataGridView4.Rows[e.RowIndex].Cells["Vaccine_Batch_3"].Value.ToString() + "', '" + dataGridView4.Rows[e.RowIndex].Cells["Vaccine_Batch_4"].Value.ToString() + "', '" + dataGridView4.Rows[e.RowIndex].Cells["Vaccine_Batch_5"].Value.ToString() + "', '" + dataGridView4.Rows[e.RowIndex].Cells["Vaccine_Batch_6"].Value.ToString() + "', '" + dataGridView4.Rows[e.RowIndex].Cells["Vaccine_Batch_7"].Value.ToString() + "', '" + dataGridView4.Rows[e.RowIndex].Cells["Vaccine_Batch_8"].Value.ToString() + "', '" + dataGridView4.Rows[e.RowIndex].Cells["Vaccine_Batch_9"].Value.ToString() + "', '" + dataGridView4.Rows[e.RowIndex].Cells["Vaccine_Batch_10"].Value.ToString() + "', '" + dataGridView4.Rows[e.RowIndex].Cells["Vaccine_Batch_11"].Value.ToString() + "', '" + dataGridView4.Rows[e.RowIndex].Cells["Vaccine_Batch_12"].Value.ToString() + "', '" + dataGridView4.Rows[e.RowIndex].Cells["Notes"].Value.ToString() + "')";

                cmd4.ExecuteNonQuery();
                fill_grid4();
            }

            else
            {
                SqlCommand cmd4 = con.CreateCommand();
                cmd4.CommandType = CommandType.Text;
                cmd4.CommandText = "Update Annual_Vaccination set Owner ='" + dataGridView4.Rows[e.RowIndex].Cells["Owner"].Value.ToString() + "', Mobile ='" + dataGridView4.Rows[e.RowIndex].Cells["Mobile"].Value.ToString() + "', Pet ='" + dataGridView4.Rows[e.RowIndex].Cells["Pet"].Value.ToString() + "', Vaccine_Batch_1 ='" + dataGridView4.Rows[e.RowIndex].Cells["Vaccine_Batch_1"].Value.ToString() + "', Vaccine_Batch_2 ='" + dataGridView4.Rows[e.RowIndex].Cells["Vaccine_Batch_2"].Value.ToString() + "', Vaccine_Batch_3 ='" + dataGridView4.Rows[e.RowIndex].Cells["Vaccine_Batch_3"].Value.ToString() + "', Vaccine_Batch_4 ='" + dataGridView4.Rows[e.RowIndex].Cells["Vaccine_Batch_4"].Value.ToString() + "', Vaccine_Batch_5 ='" + dataGridView4.Rows[e.RowIndex].Cells["Vaccine_Batch_5"].Value.ToString() + "', Vaccine_Batch_6 ='" + dataGridView4.Rows[e.RowIndex].Cells["Vaccine_Batch_6"].Value.ToString() + "', Vaccine_Batch_7 ='" + dataGridView4.Rows[e.RowIndex].Cells["Vaccine_Batch_7"].Value.ToString() + "', Vaccine_Batch_8 ='" + dataGridView4.Rows[e.RowIndex].Cells["Vaccine_Batch_8"].Value.ToString() + "', Vaccine_Batch_9 ='" + dataGridView4.Rows[e.RowIndex].Cells["Vaccine_Batch_9"].Value.ToString() + "', Vaccine_Batch_10 ='" + dataGridView4.Rows[e.RowIndex].Cells["Vaccine_Batch_10"].Value.ToString() + "', Vaccine_Batch_11 ='" + dataGridView4.Rows[e.RowIndex].Cells["Vaccine_Batch_11"].Value.ToString() + "', Vaccine_Batch_12 ='" + dataGridView4.Rows[e.RowIndex].Cells["Vaccine_Batch_12"].Value.ToString() + "', Notes ='" + dataGridView4.Rows[e.RowIndex].Cells["Notes"].Value.ToString() + "' Where No= " + Id1 + "";

                cmd4.ExecuteNonQuery();

                MessageBox.Show("The Data was Updated");
                fill_grid4();

            }
        }

        private void deleteRecordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "Delete from Vaccination_Records Where No="+delete_Id+"";

            MessageBox.Show("Selected Row was Deleted");
            cmd.ExecuteNonQuery();
            fill_grid();
        }

        public void fill_grid()
        {
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from Vaccination_Records";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            dataGridView.DataSource = dt;

        }

        public void fill_grid1()
        {
            SqlCommand cmd1 = con.CreateCommand();
            cmd1.CommandType = CommandType.Text;
            cmd1.CommandText = "select * from Primary_VR";
            cmd1.ExecuteNonQuery();
            DataTable dt1 = new DataTable();
            SqlDataAdapter da1 = new SqlDataAdapter(cmd1);
            da1.Fill(dt1);
            dataGridView1.DataSource = dt1;
        }

        public void fill_grid2()
        {
            SqlCommand cmd2 = con.CreateCommand();
            cmd2.CommandType = CommandType.Text;
            cmd2.CommandText = "select * from WFC";
            cmd2.ExecuteNonQuery();
            DataTable dt2 = new DataTable();
            SqlDataAdapter da2 = new SqlDataAdapter(cmd2);
            da2.Fill(dt2);
            dataGridView2.DataSource = dt2;
        }

        public void fill_grid3()
        {

            SqlCommand cmd3 = con.CreateCommand();
            cmd3.CommandType = CommandType.Text;
            cmd3.CommandText = "select * from Other_Vaccine";
            cmd3.ExecuteNonQuery();
            DataTable dt3 = new DataTable();
            SqlDataAdapter da3 = new SqlDataAdapter(cmd3);
            da3.Fill(dt3);
            dataGridView3.DataSource = dt3;
        }

        private void deleteRecordToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            SqlCommand cmd1 = con.CreateCommand();
            cmd1.CommandType = CommandType.Text;
            cmd1.CommandText = "Delete from Primary_VR Where No="+delete_Id+"";

            MessageBox.Show("Selected Row was Deleted");
            cmd1.ExecuteNonQuery();
            fill_grid1();
        }

        private void deleteRecord2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SqlCommand cmd2 = con.CreateCommand();
            cmd2.CommandType = CommandType.Text;
            cmd2.CommandText = "Delete from WFC Where No="+delete_Id+"";

            MessageBox.Show("Selected Row was Deleted");
            cmd2.ExecuteNonQuery();
            fill_grid2();
        }

        private void deleteRecord3ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SqlCommand cmd3 = con.CreateCommand();
            cmd3.CommandType = CommandType.Text;
            cmd3.CommandText = "Delete from Other_Vaccine Where No="+delete_Id+"";

            MessageBox.Show("Selected Row was Deleted");
            cmd3.ExecuteNonQuery();
            fill_grid3();
        }

        private void deleteRecord4ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SqlCommand cmd4 = con.CreateCommand();
            cmd4.CommandType = CommandType.Text;
            cmd4.CommandText = "Delete from Annual_Vaccination Where No="+delete_Id+"";

            MessageBox.Show("Selected Row was Deleted");
            cmd4.ExecuteNonQuery();
            fill_grid4();
        }

        private void dataGridView_CellMouseUp(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                delete_Id = Convert.ToInt32(dataGridView.Rows[e.RowIndex].Cells["No"].Value.ToString());
                this.contextMenuStrip.Show(this.dataGridView, e.Location);
                contextMenuStrip.Show(Cursor.Position);
            }
        }

        private void dataGridView1_CellMouseUp(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                delete_Id = Convert.ToInt32(dataGridView1.Rows[e.RowIndex].Cells["No"].Value.ToString());
                this.contextMenuStrip1.Show(this.dataGridView1, e.Location);
                contextMenuStrip1.Show(Cursor.Position);
            }
        }

        private void dataGridView2_CellMouseUp(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                delete_Id = Convert.ToInt32(dataGridView2.Rows[e.RowIndex].Cells["No"].Value.ToString());
                this.contextMenuStrip2.Show(this.dataGridView2, e.Location);
                contextMenuStrip2.Show(Cursor.Position);
            }
        }

        private void dataGridView3_CellMouseUp(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                delete_Id = Convert.ToInt32(dataGridView3.Rows[e.RowIndex].Cells["No"].Value.ToString());
                this.contextMenuStrip3.Show(this.dataGridView3, e.Location);
                contextMenuStrip3.Show(Cursor.Position);
            }
        }

        private void dataGridView4_CellMouseUp(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                delete_Id = Convert.ToInt32(dataGridView4.Rows[e.RowIndex].Cells["No"].Value.ToString());
                this.contextMenuStrip4.Show(this.dataGridView4, e.Location);
                contextMenuStrip4.Show(Cursor.Position);
            }
        }

        public void fill_grid4()
        { 

            SqlCommand cmd4 = con.CreateCommand();
            cmd4.CommandType = CommandType.Text;
            cmd4.CommandText = "select * from Annual_Vaccination";
            cmd4.ExecuteNonQuery();
            DataTable dt4 = new DataTable();
            SqlDataAdapter da4 = new SqlDataAdapter(cmd4);
            da4.Fill(dt4);
            dataGridView4.DataSource = dt4;

        }


        private void circularButton1_Click(object sender, EventArgs e)
        {
            this.Hide();
            HomePage HP = new HomePage(vn);
            HP.ShowDialog();
        }

        private void txt_search_TextChanged(object sender, EventArgs e)
        {
            con = new SqlConnection(Properties.Settings.Default.Database1ConnectionString);
            con.Open();
            SqlDataAdapter dataAdp = new SqlDataAdapter("select * from Vaccination_Records where Owner like '" + txt_search.Text + "%'", con);
            SqlDataAdapter dataAdp0 = new SqlDataAdapter("select * from Primary_VR where Owner like '" + txt_search.Text + "%'", con);
            SqlDataAdapter dataAdp1 = new SqlDataAdapter("select * from WFC where Owner like '" + txt_search.Text + "%'", con);
            SqlDataAdapter dataAdp2 = new SqlDataAdapter("select * from Other_Vaccine where Owner like '" + txt_search.Text + "%'", con);
            SqlDataAdapter dataAdp3 = new SqlDataAdapter("select * from Annual_Vaccination where Owner like '" + txt_search.Text + "%'", con);

            DataTable dt = new DataTable("Vaccination_Records");
            DataTable dt0 = new DataTable("Primary_VR");
            DataTable dt1 = new DataTable("WFC");
            DataTable dt2 = new DataTable("Other_Vaccine");
            DataTable dt3 = new DataTable("Annual_Vaccination");

            dataAdp.Fill(dt);
            dataAdp0.Fill(dt0);
            dataAdp1.Fill(dt1);
            dataAdp2.Fill(dt2);
            dataAdp3.Fill(dt3);

            dataGridView.DataSource = dt;
            dataGridView1.DataSource = dt0;
            dataGridView2.DataSource = dt1;
            dataGridView3.DataSource = dt2;
            dataGridView4.DataSource = dt3;

        }

        private void Search_in_Vaccination_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.Hide();
            HomePage HP = new HomePage(vn);
            HP.ShowDialog();
        }

 
    }
    }
