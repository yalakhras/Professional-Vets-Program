﻿namespace Professional_Vets
{
    partial class Daily_Transactions
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Daily_Transactions));
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.richTextBox15_MI = new System.Windows.Forms.RichTextBox();
            this.richTextBox14_MI = new System.Windows.Forms.RichTextBox();
            this.richTextBox13_MI = new System.Windows.Forms.RichTextBox();
            this.richTextBox12_MI = new System.Windows.Forms.RichTextBox();
            this.richTextBox11_MI = new System.Windows.Forms.RichTextBox();
            this.richTextBox10_MI = new System.Windows.Forms.RichTextBox();
            this.richTextBox9_MI = new System.Windows.Forms.RichTextBox();
            this.richTextBox8_MI = new System.Windows.Forms.RichTextBox();
            this.richTextBox7_MI = new System.Windows.Forms.RichTextBox();
            this.richTextBox6_MI = new System.Windows.Forms.RichTextBox();
            this.richTextBox5_MI = new System.Windows.Forms.RichTextBox();
            this.richTextBox4_MI = new System.Windows.Forms.RichTextBox();
            this.richTextBox3_MI = new System.Windows.Forms.RichTextBox();
            this.richTextBox2_MI = new System.Windows.Forms.RichTextBox();
            this.richTextBox1_MI = new System.Windows.Forms.RichTextBox();
            this.textBox1_Paid = new System.Windows.Forms.TextBox();
            this.rtxt_Action1 = new System.Windows.Forms.RichTextBox();
            this.richTextBox2_Action = new System.Windows.Forms.RichTextBox();
            this.richTextBox3_Action = new System.Windows.Forms.RichTextBox();
            this.richTextBox4_Action = new System.Windows.Forms.RichTextBox();
            this.richTextBox5_Action = new System.Windows.Forms.RichTextBox();
            this.richTextBox6_Action = new System.Windows.Forms.RichTextBox();
            this.richTextBox7_Action = new System.Windows.Forms.RichTextBox();
            this.richTextBox8_Action = new System.Windows.Forms.RichTextBox();
            this.richTextBox9_Action = new System.Windows.Forms.RichTextBox();
            this.richTextBox10_Action = new System.Windows.Forms.RichTextBox();
            this.richTextBox11_Action = new System.Windows.Forms.RichTextBox();
            this.richTextBox12_Action = new System.Windows.Forms.RichTextBox();
            this.richTextBox13_Action = new System.Windows.Forms.RichTextBox();
            this.richTextBox14_Action = new System.Windows.Forms.RichTextBox();
            this.richTextBox15_Action = new System.Windows.Forms.RichTextBox();
            this.textBox1_Price = new System.Windows.Forms.TextBox();
            this.textBox2_Price = new System.Windows.Forms.TextBox();
            this.textBox3_Price = new System.Windows.Forms.TextBox();
            this.textBox4_Price = new System.Windows.Forms.TextBox();
            this.textBox5_Price = new System.Windows.Forms.TextBox();
            this.textBox6_Price = new System.Windows.Forms.TextBox();
            this.textBox7_Price = new System.Windows.Forms.TextBox();
            this.textBox8_Price = new System.Windows.Forms.TextBox();
            this.textBox9_Price = new System.Windows.Forms.TextBox();
            this.textBox10_Price = new System.Windows.Forms.TextBox();
            this.textBox11_Price = new System.Windows.Forms.TextBox();
            this.textBox12_Price = new System.Windows.Forms.TextBox();
            this.textBox13_Price = new System.Windows.Forms.TextBox();
            this.textBox14_Price = new System.Windows.Forms.TextBox();
            this.textBox15_Price = new System.Windows.Forms.TextBox();
            this.textBox2_Paid = new System.Windows.Forms.TextBox();
            this.textBox3_Paid = new System.Windows.Forms.TextBox();
            this.textBox4_Paid = new System.Windows.Forms.TextBox();
            this.textBox5_Paid = new System.Windows.Forms.TextBox();
            this.textBox6_Paid = new System.Windows.Forms.TextBox();
            this.textBox7_Paid = new System.Windows.Forms.TextBox();
            this.textBox8_Paid = new System.Windows.Forms.TextBox();
            this.textBox9_Paid = new System.Windows.Forms.TextBox();
            this.textBox10_Paid = new System.Windows.Forms.TextBox();
            this.textBox11_Paid = new System.Windows.Forms.TextBox();
            this.textBox12_Paid = new System.Windows.Forms.TextBox();
            this.textBox13_Paid = new System.Windows.Forms.TextBox();
            this.textBox14_Paid = new System.Windows.Forms.TextBox();
            this.textBox15_Paid = new System.Windows.Forms.TextBox();
            this.circularButton3 = new Professional_Vets.CircularButton();
            this.circularButton1 = new Professional_Vets.CircularButton();
            this.panel1.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.label2.Location = new System.Drawing.Point(3, 3);
            this.label2.Margin = new System.Windows.Forms.Padding(3);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(47, 14);
            this.label2.TabIndex = 4;
            this.label2.Text = "Action";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.label3.Location = new System.Drawing.Point(390, 3);
            this.label3.Margin = new System.Windows.Forms.Padding(3);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(36, 14);
            this.label3.TabIndex = 5;
            this.label3.Text = "Price";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.label4.Location = new System.Drawing.Point(460, 3);
            this.label4.Margin = new System.Windows.Forms.Padding(3);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(33, 14);
            this.label4.TabIndex = 6;
            this.label4.Text = "Paid";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.label5.Location = new System.Drawing.Point(530, 3);
            this.label5.Margin = new System.Windows.Forms.Padding(3);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(72, 14);
            this.label5.TabIndex = 7;
            this.label5.Text = "More Info.";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.SystemColors.Highlight;
            this.label6.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold);
            this.label6.Location = new System.Drawing.Point(20, 15);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(150, 19);
            this.label6.TabIndex = 0;
            this.label6.Text = "Professional Vets";
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.BackColor = System.Drawing.SystemColors.Highlight;
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.dateTimePicker1);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Location = new System.Drawing.Point(2, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(798, 51);
            this.panel1.TabIndex = 6;
            // 
            // label7
            // 
            this.label7.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(706, 29);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(58, 13);
            this.label7.TabIndex = 3;
            this.label7.Text = "User name";
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.label1.Location = new System.Drawing.Point(661, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(39, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "User :";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.dateTimePicker1.Location = new System.Drawing.Point(659, 3);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(136, 20);
            this.dateTimePicker1.TabIndex = 1;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel1.AutoSize = true;
            this.tableLayoutPanel1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.tableLayoutPanel1.ColumnCount = 4;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.Controls.Add(this.richTextBox15_MI, 3, 15);
            this.tableLayoutPanel1.Controls.Add(this.richTextBox14_MI, 3, 14);
            this.tableLayoutPanel1.Controls.Add(this.richTextBox13_MI, 3, 13);
            this.tableLayoutPanel1.Controls.Add(this.richTextBox12_MI, 3, 12);
            this.tableLayoutPanel1.Controls.Add(this.richTextBox11_MI, 3, 11);
            this.tableLayoutPanel1.Controls.Add(this.richTextBox10_MI, 3, 10);
            this.tableLayoutPanel1.Controls.Add(this.richTextBox9_MI, 3, 9);
            this.tableLayoutPanel1.Controls.Add(this.richTextBox8_MI, 3, 8);
            this.tableLayoutPanel1.Controls.Add(this.richTextBox7_MI, 3, 7);
            this.tableLayoutPanel1.Controls.Add(this.richTextBox6_MI, 3, 6);
            this.tableLayoutPanel1.Controls.Add(this.richTextBox5_MI, 3, 5);
            this.tableLayoutPanel1.Controls.Add(this.richTextBox4_MI, 3, 4);
            this.tableLayoutPanel1.Controls.Add(this.richTextBox3_MI, 3, 3);
            this.tableLayoutPanel1.Controls.Add(this.richTextBox2_MI, 3, 2);
            this.tableLayoutPanel1.Controls.Add(this.richTextBox1_MI, 3, 1);
            this.tableLayoutPanel1.Controls.Add(this.textBox1_Paid, 2, 1);
            this.tableLayoutPanel1.Controls.Add(this.label2, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.label5, 3, 0);
            this.tableLayoutPanel1.Controls.Add(this.label3, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.label4, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.rtxt_Action1, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.richTextBox2_Action, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.richTextBox3_Action, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.richTextBox4_Action, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.richTextBox5_Action, 0, 5);
            this.tableLayoutPanel1.Controls.Add(this.richTextBox6_Action, 0, 6);
            this.tableLayoutPanel1.Controls.Add(this.richTextBox7_Action, 0, 7);
            this.tableLayoutPanel1.Controls.Add(this.richTextBox8_Action, 0, 8);
            this.tableLayoutPanel1.Controls.Add(this.richTextBox9_Action, 0, 9);
            this.tableLayoutPanel1.Controls.Add(this.richTextBox10_Action, 0, 10);
            this.tableLayoutPanel1.Controls.Add(this.richTextBox11_Action, 0, 11);
            this.tableLayoutPanel1.Controls.Add(this.richTextBox12_Action, 0, 12);
            this.tableLayoutPanel1.Controls.Add(this.richTextBox13_Action, 0, 13);
            this.tableLayoutPanel1.Controls.Add(this.richTextBox14_Action, 0, 14);
            this.tableLayoutPanel1.Controls.Add(this.richTextBox15_Action, 0, 15);
            this.tableLayoutPanel1.Controls.Add(this.textBox1_Price, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.textBox2_Price, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.textBox3_Price, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.textBox4_Price, 1, 4);
            this.tableLayoutPanel1.Controls.Add(this.textBox5_Price, 1, 5);
            this.tableLayoutPanel1.Controls.Add(this.textBox6_Price, 1, 6);
            this.tableLayoutPanel1.Controls.Add(this.textBox7_Price, 1, 7);
            this.tableLayoutPanel1.Controls.Add(this.textBox8_Price, 1, 8);
            this.tableLayoutPanel1.Controls.Add(this.textBox9_Price, 1, 9);
            this.tableLayoutPanel1.Controls.Add(this.textBox10_Price, 1, 10);
            this.tableLayoutPanel1.Controls.Add(this.textBox11_Price, 1, 11);
            this.tableLayoutPanel1.Controls.Add(this.textBox12_Price, 1, 12);
            this.tableLayoutPanel1.Controls.Add(this.textBox13_Price, 1, 13);
            this.tableLayoutPanel1.Controls.Add(this.textBox14_Price, 1, 14);
            this.tableLayoutPanel1.Controls.Add(this.textBox15_Price, 1, 15);
            this.tableLayoutPanel1.Controls.Add(this.textBox2_Paid, 2, 2);
            this.tableLayoutPanel1.Controls.Add(this.textBox3_Paid, 2, 3);
            this.tableLayoutPanel1.Controls.Add(this.textBox4_Paid, 2, 4);
            this.tableLayoutPanel1.Controls.Add(this.textBox5_Paid, 2, 5);
            this.tableLayoutPanel1.Controls.Add(this.textBox6_Paid, 2, 6);
            this.tableLayoutPanel1.Controls.Add(this.textBox7_Paid, 2, 7);
            this.tableLayoutPanel1.Controls.Add(this.textBox8_Paid, 2, 8);
            this.tableLayoutPanel1.Controls.Add(this.textBox9_Paid, 2, 9);
            this.tableLayoutPanel1.Controls.Add(this.textBox10_Paid, 2, 10);
            this.tableLayoutPanel1.Controls.Add(this.textBox11_Paid, 2, 11);
            this.tableLayoutPanel1.Controls.Add(this.textBox12_Paid, 2, 12);
            this.tableLayoutPanel1.Controls.Add(this.textBox13_Paid, 2, 13);
            this.tableLayoutPanel1.Controls.Add(this.textBox14_Paid, 2, 14);
            this.tableLayoutPanel1.Controls.Add(this.textBox15_Paid, 2, 15);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(2, 49);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 16;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.Size = new System.Drawing.Size(798, 470);
            this.tableLayoutPanel1.TabIndex = 7;
            this.tableLayoutPanel1.Paint += new System.Windows.Forms.PaintEventHandler(this.tableLayoutPanel1_Paint);
            // 
            // richTextBox15_MI
            // 
            this.richTextBox15_MI.Location = new System.Drawing.Point(530, 443);
            this.richTextBox15_MI.Multiline = false;
            this.richTextBox15_MI.Name = "richTextBox15_MI";
            this.richTextBox15_MI.Size = new System.Drawing.Size(265, 24);
            this.richTextBox15_MI.TabIndex = 67;
            this.richTextBox15_MI.Text = "";
            // 
            // richTextBox14_MI
            // 
            this.richTextBox14_MI.Location = new System.Drawing.Point(530, 413);
            this.richTextBox14_MI.Multiline = false;
            this.richTextBox14_MI.Name = "richTextBox14_MI";
            this.richTextBox14_MI.Size = new System.Drawing.Size(265, 24);
            this.richTextBox14_MI.TabIndex = 63;
            this.richTextBox14_MI.Text = "";
            // 
            // richTextBox13_MI
            // 
            this.richTextBox13_MI.Location = new System.Drawing.Point(530, 383);
            this.richTextBox13_MI.Multiline = false;
            this.richTextBox13_MI.Name = "richTextBox13_MI";
            this.richTextBox13_MI.Size = new System.Drawing.Size(265, 24);
            this.richTextBox13_MI.TabIndex = 59;
            this.richTextBox13_MI.Text = "";
            // 
            // richTextBox12_MI
            // 
            this.richTextBox12_MI.Location = new System.Drawing.Point(530, 353);
            this.richTextBox12_MI.Multiline = false;
            this.richTextBox12_MI.Name = "richTextBox12_MI";
            this.richTextBox12_MI.Size = new System.Drawing.Size(265, 24);
            this.richTextBox12_MI.TabIndex = 55;
            this.richTextBox12_MI.Text = "";
            // 
            // richTextBox11_MI
            // 
            this.richTextBox11_MI.Location = new System.Drawing.Point(530, 323);
            this.richTextBox11_MI.Multiline = false;
            this.richTextBox11_MI.Name = "richTextBox11_MI";
            this.richTextBox11_MI.Size = new System.Drawing.Size(265, 24);
            this.richTextBox11_MI.TabIndex = 51;
            this.richTextBox11_MI.Text = "";
            // 
            // richTextBox10_MI
            // 
            this.richTextBox10_MI.Location = new System.Drawing.Point(530, 293);
            this.richTextBox10_MI.Multiline = false;
            this.richTextBox10_MI.Name = "richTextBox10_MI";
            this.richTextBox10_MI.Size = new System.Drawing.Size(265, 24);
            this.richTextBox10_MI.TabIndex = 47;
            this.richTextBox10_MI.Text = "";
            // 
            // richTextBox9_MI
            // 
            this.richTextBox9_MI.Location = new System.Drawing.Point(530, 263);
            this.richTextBox9_MI.Multiline = false;
            this.richTextBox9_MI.Name = "richTextBox9_MI";
            this.richTextBox9_MI.Size = new System.Drawing.Size(265, 24);
            this.richTextBox9_MI.TabIndex = 43;
            this.richTextBox9_MI.Text = "";
            // 
            // richTextBox8_MI
            // 
            this.richTextBox8_MI.Location = new System.Drawing.Point(530, 233);
            this.richTextBox8_MI.Multiline = false;
            this.richTextBox8_MI.Name = "richTextBox8_MI";
            this.richTextBox8_MI.Size = new System.Drawing.Size(265, 24);
            this.richTextBox8_MI.TabIndex = 39;
            this.richTextBox8_MI.Text = "";
            // 
            // richTextBox7_MI
            // 
            this.richTextBox7_MI.Location = new System.Drawing.Point(530, 203);
            this.richTextBox7_MI.Multiline = false;
            this.richTextBox7_MI.Name = "richTextBox7_MI";
            this.richTextBox7_MI.Size = new System.Drawing.Size(265, 24);
            this.richTextBox7_MI.TabIndex = 35;
            this.richTextBox7_MI.Text = "";
            // 
            // richTextBox6_MI
            // 
            this.richTextBox6_MI.Location = new System.Drawing.Point(530, 173);
            this.richTextBox6_MI.Multiline = false;
            this.richTextBox6_MI.Name = "richTextBox6_MI";
            this.richTextBox6_MI.Size = new System.Drawing.Size(265, 24);
            this.richTextBox6_MI.TabIndex = 31;
            this.richTextBox6_MI.Text = "";
            // 
            // richTextBox5_MI
            // 
            this.richTextBox5_MI.Location = new System.Drawing.Point(530, 143);
            this.richTextBox5_MI.Multiline = false;
            this.richTextBox5_MI.Name = "richTextBox5_MI";
            this.richTextBox5_MI.Size = new System.Drawing.Size(265, 24);
            this.richTextBox5_MI.TabIndex = 27;
            this.richTextBox5_MI.Text = "";
            // 
            // richTextBox4_MI
            // 
            this.richTextBox4_MI.Location = new System.Drawing.Point(530, 113);
            this.richTextBox4_MI.Multiline = false;
            this.richTextBox4_MI.Name = "richTextBox4_MI";
            this.richTextBox4_MI.Size = new System.Drawing.Size(265, 24);
            this.richTextBox4_MI.TabIndex = 23;
            this.richTextBox4_MI.Text = "";
            // 
            // richTextBox3_MI
            // 
            this.richTextBox3_MI.Location = new System.Drawing.Point(530, 83);
            this.richTextBox3_MI.Multiline = false;
            this.richTextBox3_MI.Name = "richTextBox3_MI";
            this.richTextBox3_MI.Size = new System.Drawing.Size(265, 24);
            this.richTextBox3_MI.TabIndex = 19;
            this.richTextBox3_MI.Text = "";
            // 
            // richTextBox2_MI
            // 
            this.richTextBox2_MI.Location = new System.Drawing.Point(530, 53);
            this.richTextBox2_MI.Multiline = false;
            this.richTextBox2_MI.Name = "richTextBox2_MI";
            this.richTextBox2_MI.Size = new System.Drawing.Size(265, 24);
            this.richTextBox2_MI.TabIndex = 15;
            this.richTextBox2_MI.Text = "";
            // 
            // richTextBox1_MI
            // 
            this.richTextBox1_MI.Location = new System.Drawing.Point(530, 23);
            this.richTextBox1_MI.Multiline = false;
            this.richTextBox1_MI.Name = "richTextBox1_MI";
            this.richTextBox1_MI.Size = new System.Drawing.Size(265, 24);
            this.richTextBox1_MI.TabIndex = 11;
            this.richTextBox1_MI.Text = "";
            // 
            // textBox1_Paid
            // 
            this.textBox1_Paid.Location = new System.Drawing.Point(460, 23);
            this.textBox1_Paid.Name = "textBox1_Paid";
            this.textBox1_Paid.Size = new System.Drawing.Size(64, 20);
            this.textBox1_Paid.TabIndex = 10;
            // 
            // rtxt_Action1
            // 
            this.rtxt_Action1.Location = new System.Drawing.Point(3, 23);
            this.rtxt_Action1.Multiline = false;
            this.rtxt_Action1.Name = "rtxt_Action1";
            this.rtxt_Action1.Size = new System.Drawing.Size(381, 24);
            this.rtxt_Action1.TabIndex = 8;
            this.rtxt_Action1.Text = "";
            // 
            // richTextBox2_Action
            // 
            this.richTextBox2_Action.Location = new System.Drawing.Point(3, 53);
            this.richTextBox2_Action.Multiline = false;
            this.richTextBox2_Action.Name = "richTextBox2_Action";
            this.richTextBox2_Action.Size = new System.Drawing.Size(381, 24);
            this.richTextBox2_Action.TabIndex = 12;
            this.richTextBox2_Action.Text = "";
            // 
            // richTextBox3_Action
            // 
            this.richTextBox3_Action.Location = new System.Drawing.Point(3, 83);
            this.richTextBox3_Action.Multiline = false;
            this.richTextBox3_Action.Name = "richTextBox3_Action";
            this.richTextBox3_Action.Size = new System.Drawing.Size(381, 24);
            this.richTextBox3_Action.TabIndex = 16;
            this.richTextBox3_Action.Text = "";
            // 
            // richTextBox4_Action
            // 
            this.richTextBox4_Action.Location = new System.Drawing.Point(3, 113);
            this.richTextBox4_Action.Multiline = false;
            this.richTextBox4_Action.Name = "richTextBox4_Action";
            this.richTextBox4_Action.Size = new System.Drawing.Size(381, 24);
            this.richTextBox4_Action.TabIndex = 20;
            this.richTextBox4_Action.Text = "";
            // 
            // richTextBox5_Action
            // 
            this.richTextBox5_Action.Location = new System.Drawing.Point(3, 143);
            this.richTextBox5_Action.Multiline = false;
            this.richTextBox5_Action.Name = "richTextBox5_Action";
            this.richTextBox5_Action.Size = new System.Drawing.Size(381, 24);
            this.richTextBox5_Action.TabIndex = 24;
            this.richTextBox5_Action.Text = "";
            // 
            // richTextBox6_Action
            // 
            this.richTextBox6_Action.Location = new System.Drawing.Point(3, 173);
            this.richTextBox6_Action.Multiline = false;
            this.richTextBox6_Action.Name = "richTextBox6_Action";
            this.richTextBox6_Action.Size = new System.Drawing.Size(381, 24);
            this.richTextBox6_Action.TabIndex = 28;
            this.richTextBox6_Action.Text = "";
            // 
            // richTextBox7_Action
            // 
            this.richTextBox7_Action.Location = new System.Drawing.Point(3, 203);
            this.richTextBox7_Action.Multiline = false;
            this.richTextBox7_Action.Name = "richTextBox7_Action";
            this.richTextBox7_Action.Size = new System.Drawing.Size(381, 24);
            this.richTextBox7_Action.TabIndex = 32;
            this.richTextBox7_Action.Text = "";
            // 
            // richTextBox8_Action
            // 
            this.richTextBox8_Action.Location = new System.Drawing.Point(3, 233);
            this.richTextBox8_Action.Multiline = false;
            this.richTextBox8_Action.Name = "richTextBox8_Action";
            this.richTextBox8_Action.Size = new System.Drawing.Size(381, 24);
            this.richTextBox8_Action.TabIndex = 36;
            this.richTextBox8_Action.Text = "";
            // 
            // richTextBox9_Action
            // 
            this.richTextBox9_Action.Location = new System.Drawing.Point(3, 263);
            this.richTextBox9_Action.Multiline = false;
            this.richTextBox9_Action.Name = "richTextBox9_Action";
            this.richTextBox9_Action.Size = new System.Drawing.Size(381, 24);
            this.richTextBox9_Action.TabIndex = 40;
            this.richTextBox9_Action.Text = "";
            this.richTextBox9_Action.TextChanged += new System.EventHandler(this.richTextBox9_Action_TextChanged);
            // 
            // richTextBox10_Action
            // 
            this.richTextBox10_Action.Location = new System.Drawing.Point(3, 293);
            this.richTextBox10_Action.Multiline = false;
            this.richTextBox10_Action.Name = "richTextBox10_Action";
            this.richTextBox10_Action.Size = new System.Drawing.Size(381, 24);
            this.richTextBox10_Action.TabIndex = 44;
            this.richTextBox10_Action.Text = "";
            // 
            // richTextBox11_Action
            // 
            this.richTextBox11_Action.Location = new System.Drawing.Point(3, 323);
            this.richTextBox11_Action.Multiline = false;
            this.richTextBox11_Action.Name = "richTextBox11_Action";
            this.richTextBox11_Action.Size = new System.Drawing.Size(381, 24);
            this.richTextBox11_Action.TabIndex = 48;
            this.richTextBox11_Action.Text = "";
            // 
            // richTextBox12_Action
            // 
            this.richTextBox12_Action.Location = new System.Drawing.Point(3, 353);
            this.richTextBox12_Action.Multiline = false;
            this.richTextBox12_Action.Name = "richTextBox12_Action";
            this.richTextBox12_Action.Size = new System.Drawing.Size(381, 24);
            this.richTextBox12_Action.TabIndex = 52;
            this.richTextBox12_Action.Text = "";
            // 
            // richTextBox13_Action
            // 
            this.richTextBox13_Action.Location = new System.Drawing.Point(3, 383);
            this.richTextBox13_Action.Multiline = false;
            this.richTextBox13_Action.Name = "richTextBox13_Action";
            this.richTextBox13_Action.Size = new System.Drawing.Size(381, 24);
            this.richTextBox13_Action.TabIndex = 56;
            this.richTextBox13_Action.Text = "";
            // 
            // richTextBox14_Action
            // 
            this.richTextBox14_Action.Location = new System.Drawing.Point(3, 413);
            this.richTextBox14_Action.Multiline = false;
            this.richTextBox14_Action.Name = "richTextBox14_Action";
            this.richTextBox14_Action.Size = new System.Drawing.Size(381, 24);
            this.richTextBox14_Action.TabIndex = 60;
            this.richTextBox14_Action.Text = "";
            // 
            // richTextBox15_Action
            // 
            this.richTextBox15_Action.Location = new System.Drawing.Point(3, 443);
            this.richTextBox15_Action.Multiline = false;
            this.richTextBox15_Action.Name = "richTextBox15_Action";
            this.richTextBox15_Action.Size = new System.Drawing.Size(381, 24);
            this.richTextBox15_Action.TabIndex = 64;
            this.richTextBox15_Action.Text = "";
            // 
            // textBox1_Price
            // 
            this.textBox1_Price.Location = new System.Drawing.Point(390, 23);
            this.textBox1_Price.Name = "textBox1_Price";
            this.textBox1_Price.Size = new System.Drawing.Size(64, 20);
            this.textBox1_Price.TabIndex = 9;
            // 
            // textBox2_Price
            // 
            this.textBox2_Price.Location = new System.Drawing.Point(390, 53);
            this.textBox2_Price.Name = "textBox2_Price";
            this.textBox2_Price.Size = new System.Drawing.Size(64, 20);
            this.textBox2_Price.TabIndex = 13;
            // 
            // textBox3_Price
            // 
            this.textBox3_Price.Location = new System.Drawing.Point(390, 83);
            this.textBox3_Price.Name = "textBox3_Price";
            this.textBox3_Price.Size = new System.Drawing.Size(64, 20);
            this.textBox3_Price.TabIndex = 17;
            // 
            // textBox4_Price
            // 
            this.textBox4_Price.Location = new System.Drawing.Point(390, 113);
            this.textBox4_Price.Name = "textBox4_Price";
            this.textBox4_Price.Size = new System.Drawing.Size(64, 20);
            this.textBox4_Price.TabIndex = 21;
            // 
            // textBox5_Price
            // 
            this.textBox5_Price.Location = new System.Drawing.Point(390, 143);
            this.textBox5_Price.Name = "textBox5_Price";
            this.textBox5_Price.Size = new System.Drawing.Size(64, 20);
            this.textBox5_Price.TabIndex = 25;
            // 
            // textBox6_Price
            // 
            this.textBox6_Price.Location = new System.Drawing.Point(390, 173);
            this.textBox6_Price.Name = "textBox6_Price";
            this.textBox6_Price.Size = new System.Drawing.Size(64, 20);
            this.textBox6_Price.TabIndex = 29;
            // 
            // textBox7_Price
            // 
            this.textBox7_Price.Location = new System.Drawing.Point(390, 203);
            this.textBox7_Price.Name = "textBox7_Price";
            this.textBox7_Price.Size = new System.Drawing.Size(64, 20);
            this.textBox7_Price.TabIndex = 33;
            // 
            // textBox8_Price
            // 
            this.textBox8_Price.Location = new System.Drawing.Point(390, 233);
            this.textBox8_Price.Name = "textBox8_Price";
            this.textBox8_Price.Size = new System.Drawing.Size(64, 20);
            this.textBox8_Price.TabIndex = 37;
            // 
            // textBox9_Price
            // 
            this.textBox9_Price.Location = new System.Drawing.Point(390, 263);
            this.textBox9_Price.Name = "textBox9_Price";
            this.textBox9_Price.Size = new System.Drawing.Size(64, 20);
            this.textBox9_Price.TabIndex = 41;
            // 
            // textBox10_Price
            // 
            this.textBox10_Price.Location = new System.Drawing.Point(390, 293);
            this.textBox10_Price.Name = "textBox10_Price";
            this.textBox10_Price.Size = new System.Drawing.Size(64, 20);
            this.textBox10_Price.TabIndex = 45;
            // 
            // textBox11_Price
            // 
            this.textBox11_Price.Location = new System.Drawing.Point(390, 323);
            this.textBox11_Price.Name = "textBox11_Price";
            this.textBox11_Price.Size = new System.Drawing.Size(64, 20);
            this.textBox11_Price.TabIndex = 49;
            // 
            // textBox12_Price
            // 
            this.textBox12_Price.Location = new System.Drawing.Point(390, 353);
            this.textBox12_Price.Name = "textBox12_Price";
            this.textBox12_Price.Size = new System.Drawing.Size(64, 20);
            this.textBox12_Price.TabIndex = 53;
            // 
            // textBox13_Price
            // 
            this.textBox13_Price.Location = new System.Drawing.Point(390, 383);
            this.textBox13_Price.Name = "textBox13_Price";
            this.textBox13_Price.Size = new System.Drawing.Size(64, 20);
            this.textBox13_Price.TabIndex = 57;
            // 
            // textBox14_Price
            // 
            this.textBox14_Price.Location = new System.Drawing.Point(390, 413);
            this.textBox14_Price.Name = "textBox14_Price";
            this.textBox14_Price.Size = new System.Drawing.Size(64, 20);
            this.textBox14_Price.TabIndex = 61;
            // 
            // textBox15_Price
            // 
            this.textBox15_Price.Location = new System.Drawing.Point(390, 443);
            this.textBox15_Price.Name = "textBox15_Price";
            this.textBox15_Price.Size = new System.Drawing.Size(64, 20);
            this.textBox15_Price.TabIndex = 65;
            // 
            // textBox2_Paid
            // 
            this.textBox2_Paid.Location = new System.Drawing.Point(460, 53);
            this.textBox2_Paid.Name = "textBox2_Paid";
            this.textBox2_Paid.Size = new System.Drawing.Size(64, 20);
            this.textBox2_Paid.TabIndex = 14;
            // 
            // textBox3_Paid
            // 
            this.textBox3_Paid.Location = new System.Drawing.Point(460, 83);
            this.textBox3_Paid.Name = "textBox3_Paid";
            this.textBox3_Paid.Size = new System.Drawing.Size(64, 20);
            this.textBox3_Paid.TabIndex = 18;
            // 
            // textBox4_Paid
            // 
            this.textBox4_Paid.Location = new System.Drawing.Point(460, 113);
            this.textBox4_Paid.Name = "textBox4_Paid";
            this.textBox4_Paid.Size = new System.Drawing.Size(64, 20);
            this.textBox4_Paid.TabIndex = 22;
            // 
            // textBox5_Paid
            // 
            this.textBox5_Paid.Location = new System.Drawing.Point(460, 143);
            this.textBox5_Paid.Name = "textBox5_Paid";
            this.textBox5_Paid.Size = new System.Drawing.Size(64, 20);
            this.textBox5_Paid.TabIndex = 26;
            // 
            // textBox6_Paid
            // 
            this.textBox6_Paid.Location = new System.Drawing.Point(460, 173);
            this.textBox6_Paid.Name = "textBox6_Paid";
            this.textBox6_Paid.Size = new System.Drawing.Size(64, 20);
            this.textBox6_Paid.TabIndex = 30;
            // 
            // textBox7_Paid
            // 
            this.textBox7_Paid.Location = new System.Drawing.Point(460, 203);
            this.textBox7_Paid.Name = "textBox7_Paid";
            this.textBox7_Paid.Size = new System.Drawing.Size(64, 20);
            this.textBox7_Paid.TabIndex = 34;
            // 
            // textBox8_Paid
            // 
            this.textBox8_Paid.Location = new System.Drawing.Point(460, 233);
            this.textBox8_Paid.Name = "textBox8_Paid";
            this.textBox8_Paid.Size = new System.Drawing.Size(64, 20);
            this.textBox8_Paid.TabIndex = 38;
            // 
            // textBox9_Paid
            // 
            this.textBox9_Paid.Location = new System.Drawing.Point(460, 263);
            this.textBox9_Paid.Name = "textBox9_Paid";
            this.textBox9_Paid.Size = new System.Drawing.Size(64, 20);
            this.textBox9_Paid.TabIndex = 42;
            // 
            // textBox10_Paid
            // 
            this.textBox10_Paid.Location = new System.Drawing.Point(460, 293);
            this.textBox10_Paid.Name = "textBox10_Paid";
            this.textBox10_Paid.Size = new System.Drawing.Size(64, 20);
            this.textBox10_Paid.TabIndex = 46;
            // 
            // textBox11_Paid
            // 
            this.textBox11_Paid.Location = new System.Drawing.Point(460, 323);
            this.textBox11_Paid.Name = "textBox11_Paid";
            this.textBox11_Paid.Size = new System.Drawing.Size(64, 20);
            this.textBox11_Paid.TabIndex = 50;
            // 
            // textBox12_Paid
            // 
            this.textBox12_Paid.Location = new System.Drawing.Point(460, 353);
            this.textBox12_Paid.Name = "textBox12_Paid";
            this.textBox12_Paid.Size = new System.Drawing.Size(64, 20);
            this.textBox12_Paid.TabIndex = 54;
            // 
            // textBox13_Paid
            // 
            this.textBox13_Paid.Location = new System.Drawing.Point(460, 383);
            this.textBox13_Paid.Name = "textBox13_Paid";
            this.textBox13_Paid.Size = new System.Drawing.Size(64, 20);
            this.textBox13_Paid.TabIndex = 58;
            // 
            // textBox14_Paid
            // 
            this.textBox14_Paid.Location = new System.Drawing.Point(460, 413);
            this.textBox14_Paid.Name = "textBox14_Paid";
            this.textBox14_Paid.Size = new System.Drawing.Size(64, 20);
            this.textBox14_Paid.TabIndex = 62;
            // 
            // textBox15_Paid
            // 
            this.textBox15_Paid.Location = new System.Drawing.Point(460, 443);
            this.textBox15_Paid.Name = "textBox15_Paid";
            this.textBox15_Paid.Size = new System.Drawing.Size(64, 20);
            this.textBox15_Paid.TabIndex = 66;
            // 
            // circularButton3
            // 
            this.circularButton3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.circularButton3.AutoSize = true;
            this.circularButton3.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.circularButton3.FlatAppearance.BorderSize = 0;
            this.circularButton3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.circularButton3.Image = ((System.Drawing.Image)(resources.GetObject("circularButton3.Image")));
            this.circularButton3.Location = new System.Drawing.Point(728, 532);
            this.circularButton3.Name = "circularButton3";
            this.circularButton3.Size = new System.Drawing.Size(61, 61);
            this.circularButton3.TabIndex = 69;
            this.circularButton3.UseVisualStyleBackColor = true;
            this.circularButton3.Click += new System.EventHandler(this.circularButton3_Click);
            // 
            // circularButton1
            // 
            this.circularButton1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.circularButton1.AutoSize = true;
            this.circularButton1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.circularButton1.FlatAppearance.BorderSize = 0;
            this.circularButton1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.circularButton1.Image = ((System.Drawing.Image)(resources.GetObject("circularButton1.Image")));
            this.circularButton1.Location = new System.Drawing.Point(677, 537);
            this.circularButton1.Name = "circularButton1";
            this.circularButton1.Size = new System.Drawing.Size(56, 56);
            this.circularButton1.TabIndex = 68;
            this.circularButton1.UseVisualStyleBackColor = true;
            this.circularButton1.Click += new System.EventHandler(this.circularButton1_Click);
            // 
            // Daily_Transactions
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.ClientSize = new System.Drawing.Size(800, 602);
            this.Controls.Add(this.circularButton3);
            this.Controls.Add(this.circularButton1);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Controls.Add(this.panel1);
            this.Name = "Daily_Transactions";
            this.Text = "Daily_Transactions";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Daily_Transactions_FormClosing);
            this.Load += new System.EventHandler(this.Daily_Transactions_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.RichTextBox rtxt_Action1;
        private System.Windows.Forms.RichTextBox richTextBox2_Action;
        private System.Windows.Forms.RichTextBox richTextBox3_Action;
        private System.Windows.Forms.RichTextBox richTextBox4_Action;
        private System.Windows.Forms.RichTextBox richTextBox5_Action;
        private System.Windows.Forms.RichTextBox richTextBox6_Action;
        private System.Windows.Forms.RichTextBox richTextBox7_Action;
        private System.Windows.Forms.RichTextBox richTextBox8_Action;
        private System.Windows.Forms.RichTextBox richTextBox9_Action;
        private System.Windows.Forms.RichTextBox richTextBox10_Action;
        private System.Windows.Forms.RichTextBox richTextBox11_Action;
        private System.Windows.Forms.RichTextBox richTextBox12_Action;
        private System.Windows.Forms.RichTextBox richTextBox13_Action;
        private System.Windows.Forms.RichTextBox richTextBox14_Action;
        private System.Windows.Forms.RichTextBox richTextBox15_Action;
        private System.Windows.Forms.RichTextBox richTextBox15_MI;
        private System.Windows.Forms.RichTextBox richTextBox14_MI;
        private System.Windows.Forms.RichTextBox richTextBox13_MI;
        private System.Windows.Forms.RichTextBox richTextBox12_MI;
        private System.Windows.Forms.RichTextBox richTextBox11_MI;
        private System.Windows.Forms.RichTextBox richTextBox10_MI;
        private System.Windows.Forms.RichTextBox richTextBox9_MI;
        private System.Windows.Forms.RichTextBox richTextBox8_MI;
        private System.Windows.Forms.RichTextBox richTextBox7_MI;
        private System.Windows.Forms.RichTextBox richTextBox6_MI;
        private System.Windows.Forms.RichTextBox richTextBox5_MI;
        private System.Windows.Forms.RichTextBox richTextBox4_MI;
        private System.Windows.Forms.RichTextBox richTextBox3_MI;
        private System.Windows.Forms.RichTextBox richTextBox2_MI;
        private System.Windows.Forms.RichTextBox richTextBox1_MI;
        private System.Windows.Forms.TextBox textBox1_Paid;
        private System.Windows.Forms.TextBox textBox1_Price;
        private System.Windows.Forms.TextBox textBox2_Price;
        private System.Windows.Forms.TextBox textBox3_Price;
        private System.Windows.Forms.TextBox textBox4_Price;
        private System.Windows.Forms.TextBox textBox5_Price;
        private System.Windows.Forms.TextBox textBox6_Price;
        private System.Windows.Forms.TextBox textBox7_Price;
        private System.Windows.Forms.TextBox textBox8_Price;
        private System.Windows.Forms.TextBox textBox9_Price;
        private System.Windows.Forms.TextBox textBox10_Price;
        private System.Windows.Forms.TextBox textBox11_Price;
        private System.Windows.Forms.TextBox textBox12_Price;
        private System.Windows.Forms.TextBox textBox13_Price;
        private System.Windows.Forms.TextBox textBox14_Price;
        private System.Windows.Forms.TextBox textBox15_Price;
        private System.Windows.Forms.TextBox textBox2_Paid;
        private System.Windows.Forms.TextBox textBox3_Paid;
        private System.Windows.Forms.TextBox textBox4_Paid;
        private System.Windows.Forms.TextBox textBox5_Paid;
        private System.Windows.Forms.TextBox textBox6_Paid;
        private System.Windows.Forms.TextBox textBox7_Paid;
        private System.Windows.Forms.TextBox textBox8_Paid;
        private System.Windows.Forms.TextBox textBox9_Paid;
        private System.Windows.Forms.TextBox textBox10_Paid;
        private System.Windows.Forms.TextBox textBox11_Paid;
        private System.Windows.Forms.TextBox textBox12_Paid;
        private System.Windows.Forms.TextBox textBox13_Paid;
        private System.Windows.Forms.TextBox textBox14_Paid;
        private System.Windows.Forms.TextBox textBox15_Paid;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label7;
        private CircularButton circularButton3;
        private CircularButton circularButton1;
    }
}