﻿namespace Professional_Vets
{
    partial class Physical_Examination2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Physical_Examination2));
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.ch_Excellent_D = new System.Windows.Forms.CheckBox();
            this.ch_Good_D = new System.Windows.Forms.CheckBox();
            this.ch_Change_Diet_D = new System.Windows.Forms.CheckBox();
            this.ch_Vitamins_needed_D = new System.Windows.Forms.CheckBox();
            this.ch_Recommendations_D = new System.Windows.Forms.CheckBox();
            this.rtxt_Recommendations_D = new System.Windows.Forms.RichTextBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.ch_Normal_US = new System.Windows.Forms.CheckBox();
            this.ch_Abnormal_Urination_US = new System.Windows.Forms.CheckBox();
            this.ch_Anal_Sacs_US = new System.Windows.Forms.CheckBox();
            this.ch_Genital_Discharge_C_US = new System.Windows.Forms.CheckBox();
            this.ch_Mammary_Abn_US = new System.Windows.Forms.CheckBox();
            this.ch_Other_US = new System.Windows.Forms.CheckBox();
            this.ch_Abn_Testicles_US = new System.Windows.Forms.CheckBox();
            this.txt_Other_US = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.ch_Abn_Feces_GIT = new System.Windows.Forms.CheckBox();
            this.ch_Excessive_Gas_GIT = new System.Windows.Forms.CheckBox();
            this.ch_Parasites_GIT = new System.Windows.Forms.CheckBox();
            this.ch_Vomiting_GIT = new System.Windows.Forms.CheckBox();
            this.ch_Anorexia_GIT = new System.Windows.Forms.CheckBox();
            this.ch_Other_GIT = new System.Windows.Forms.CheckBox();
            this.txt_Other_GIT = new System.Windows.Forms.TextBox();
            this.ch_Diarrhea_GIT = new System.Windows.Forms.CheckBox();
            this.ch_Normal_GIT = new System.Windows.Forms.CheckBox();
            this.rtxt_Diagnosis_Explanations = new System.Windows.Forms.RichTextBox();
            this.rtxt_Recommendations = new System.Windows.Forms.RichTextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txt_Price = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txt_Pay = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.circularButton3 = new Professional_Vets.CircularButton();
            this.circularButton1 = new Professional_Vets.CircularButton();
            this.groupBox4.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox4
            // 
            this.groupBox4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox4.AutoSize = true;
            this.groupBox4.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.groupBox4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.groupBox4.Controls.Add(this.tableLayoutPanel3);
            this.groupBox4.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.groupBox4.Location = new System.Drawing.Point(546, 21);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(239, 234);
            this.groupBox4.TabIndex = 16;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Diet";
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 2;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel3.Controls.Add(this.ch_Excellent_D, 0, 0);
            this.tableLayoutPanel3.Controls.Add(this.ch_Good_D, 0, 1);
            this.tableLayoutPanel3.Controls.Add(this.ch_Change_Diet_D, 0, 2);
            this.tableLayoutPanel3.Controls.Add(this.ch_Vitamins_needed_D, 0, 3);
            this.tableLayoutPanel3.Controls.Add(this.ch_Recommendations_D, 0, 7);
            this.tableLayoutPanel3.Controls.Add(this.rtxt_Recommendations_D, 1, 7);
            this.tableLayoutPanel3.Location = new System.Drawing.Point(6, 24);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 8;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel3.Size = new System.Drawing.Size(227, 191);
            this.tableLayoutPanel3.TabIndex = 1;
            // 
            // ch_Excellent_D
            // 
            this.ch_Excellent_D.AutoSize = true;
            this.ch_Excellent_D.Location = new System.Drawing.Point(3, 3);
            this.ch_Excellent_D.Name = "ch_Excellent_D";
            this.ch_Excellent_D.Size = new System.Drawing.Size(77, 17);
            this.ch_Excellent_D.TabIndex = 0;
            this.ch_Excellent_D.Text = "Excellent";
            this.ch_Excellent_D.UseVisualStyleBackColor = true;
            // 
            // ch_Good_D
            // 
            this.ch_Good_D.AutoSize = true;
            this.ch_Good_D.Location = new System.Drawing.Point(3, 26);
            this.ch_Good_D.Name = "ch_Good_D";
            this.ch_Good_D.Size = new System.Drawing.Size(55, 17);
            this.ch_Good_D.TabIndex = 1;
            this.ch_Good_D.Text = "Good";
            this.ch_Good_D.UseVisualStyleBackColor = true;
            // 
            // ch_Change_Diet_D
            // 
            this.ch_Change_Diet_D.AutoSize = true;
            this.ch_Change_Diet_D.Location = new System.Drawing.Point(3, 49);
            this.ch_Change_Diet_D.Name = "ch_Change_Diet_D";
            this.ch_Change_Diet_D.Size = new System.Drawing.Size(94, 17);
            this.ch_Change_Diet_D.TabIndex = 2;
            this.ch_Change_Diet_D.Text = "Change Diet";
            this.ch_Change_Diet_D.UseVisualStyleBackColor = true;
            // 
            // ch_Vitamins_needed_D
            // 
            this.ch_Vitamins_needed_D.AutoSize = true;
            this.ch_Vitamins_needed_D.Location = new System.Drawing.Point(3, 72);
            this.ch_Vitamins_needed_D.Name = "ch_Vitamins_needed_D";
            this.ch_Vitamins_needed_D.Size = new System.Drawing.Size(120, 17);
            this.ch_Vitamins_needed_D.TabIndex = 3;
            this.ch_Vitamins_needed_D.Text = "Vitamins needed";
            this.ch_Vitamins_needed_D.UseVisualStyleBackColor = true;
            // 
            // ch_Recommendations_D
            // 
            this.ch_Recommendations_D.AutoSize = true;
            this.ch_Recommendations_D.Location = new System.Drawing.Point(3, 95);
            this.ch_Recommendations_D.Name = "ch_Recommendations_D";
            this.ch_Recommendations_D.Size = new System.Drawing.Size(132, 17);
            this.ch_Recommendations_D.TabIndex = 15;
            this.ch_Recommendations_D.Text = "Recommendations";
            this.ch_Recommendations_D.UseVisualStyleBackColor = true;
            this.ch_Recommendations_D.CheckedChanged += new System.EventHandler(this.checkBox25_CheckedChanged);
            // 
            // rtxt_Recommendations_D
            // 
            this.rtxt_Recommendations_D.Location = new System.Drawing.Point(141, 95);
            this.rtxt_Recommendations_D.Name = "rtxt_Recommendations_D";
            this.rtxt_Recommendations_D.Size = new System.Drawing.Size(81, 89);
            this.rtxt_Recommendations_D.TabIndex = 16;
            this.rtxt_Recommendations_D.Text = "";
            // 
            // groupBox3
            // 
            this.groupBox3.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.groupBox3.AutoSize = true;
            this.groupBox3.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.groupBox3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.groupBox3.Controls.Add(this.tableLayoutPanel2);
            this.groupBox3.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.groupBox3.Location = new System.Drawing.Point(270, 21);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(229, 234);
            this.groupBox3.TabIndex = 15;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Urogenital System";
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 2;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel2.Controls.Add(this.ch_Normal_US, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.ch_Abnormal_Urination_US, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.ch_Anal_Sacs_US, 0, 2);
            this.tableLayoutPanel2.Controls.Add(this.ch_Genital_Discharge_C_US, 0, 3);
            this.tableLayoutPanel2.Controls.Add(this.ch_Mammary_Abn_US, 0, 5);
            this.tableLayoutPanel2.Controls.Add(this.ch_Other_US, 0, 6);
            this.tableLayoutPanel2.Controls.Add(this.ch_Abn_Testicles_US, 0, 4);
            this.tableLayoutPanel2.Controls.Add(this.txt_Other_US, 1, 6);
            this.tableLayoutPanel2.Location = new System.Drawing.Point(6, 24);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 7;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(217, 191);
            this.tableLayoutPanel2.TabIndex = 1;
            // 
            // ch_Normal_US
            // 
            this.ch_Normal_US.AutoSize = true;
            this.ch_Normal_US.Location = new System.Drawing.Point(3, 3);
            this.ch_Normal_US.Name = "ch_Normal_US";
            this.ch_Normal_US.Size = new System.Drawing.Size(66, 17);
            this.ch_Normal_US.TabIndex = 0;
            this.ch_Normal_US.Text = "Normal";
            this.ch_Normal_US.UseVisualStyleBackColor = true;
            // 
            // ch_Abnormal_Urination_US
            // 
            this.ch_Abnormal_Urination_US.AutoSize = true;
            this.ch_Abnormal_Urination_US.Location = new System.Drawing.Point(3, 26);
            this.ch_Abnormal_Urination_US.Name = "ch_Abnormal_Urination_US";
            this.ch_Abnormal_Urination_US.Size = new System.Drawing.Size(136, 17);
            this.ch_Abnormal_Urination_US.TabIndex = 1;
            this.ch_Abnormal_Urination_US.Text = "Abnormal Urination";
            this.ch_Abnormal_Urination_US.UseVisualStyleBackColor = true;
            // 
            // ch_Anal_Sacs_US
            // 
            this.ch_Anal_Sacs_US.AutoSize = true;
            this.ch_Anal_Sacs_US.Location = new System.Drawing.Point(3, 49);
            this.ch_Anal_Sacs_US.Name = "ch_Anal_Sacs_US";
            this.ch_Anal_Sacs_US.Size = new System.Drawing.Size(80, 17);
            this.ch_Anal_Sacs_US.TabIndex = 2;
            this.ch_Anal_Sacs_US.Text = "Anal Sacs";
            this.ch_Anal_Sacs_US.UseVisualStyleBackColor = true;
            // 
            // ch_Genital_Discharge_C_US
            // 
            this.ch_Genital_Discharge_C_US.AutoSize = true;
            this.ch_Genital_Discharge_C_US.Location = new System.Drawing.Point(3, 72);
            this.ch_Genital_Discharge_C_US.Name = "ch_Genital_Discharge_C_US";
            this.ch_Genital_Discharge_C_US.Size = new System.Drawing.Size(125, 17);
            this.ch_Genital_Discharge_C_US.TabIndex = 4;
            this.ch_Genital_Discharge_C_US.Text = "Genital Discharge";
            this.ch_Genital_Discharge_C_US.UseVisualStyleBackColor = true;
            // 
            // ch_Mammary_Abn_US
            // 
            this.ch_Mammary_Abn_US.AutoSize = true;
            this.ch_Mammary_Abn_US.Location = new System.Drawing.Point(3, 118);
            this.ch_Mammary_Abn_US.Name = "ch_Mammary_Abn_US";
            this.ch_Mammary_Abn_US.Size = new System.Drawing.Size(112, 17);
            this.ch_Mammary_Abn_US.TabIndex = 6;
            this.ch_Mammary_Abn_US.Text = "Mammary Abn.";
            this.ch_Mammary_Abn_US.UseVisualStyleBackColor = true;
            // 
            // ch_Other_US
            // 
            this.ch_Other_US.AutoSize = true;
            this.ch_Other_US.Location = new System.Drawing.Point(3, 141);
            this.ch_Other_US.Name = "ch_Other_US";
            this.ch_Other_US.Size = new System.Drawing.Size(58, 17);
            this.ch_Other_US.TabIndex = 10;
            this.ch_Other_US.Text = "Other";
            this.ch_Other_US.UseVisualStyleBackColor = true;
            this.ch_Other_US.CheckedChanged += new System.EventHandler(this.ch_Other_US_CheckedChanged);
            // 
            // ch_Abn_Testicles_US
            // 
            this.ch_Abn_Testicles_US.AutoSize = true;
            this.ch_Abn_Testicles_US.Location = new System.Drawing.Point(3, 95);
            this.ch_Abn_Testicles_US.Name = "ch_Abn_Testicles_US";
            this.ch_Abn_Testicles_US.Size = new System.Drawing.Size(104, 17);
            this.ch_Abn_Testicles_US.TabIndex = 5;
            this.ch_Abn_Testicles_US.Text = "Abn. Testicles";
            this.ch_Abn_Testicles_US.UseVisualStyleBackColor = true;
            // 
            // txt_Other_US
            // 
            this.txt_Other_US.Location = new System.Drawing.Point(145, 141);
            this.txt_Other_US.Name = "txt_Other_US";
            this.txt_Other_US.Size = new System.Drawing.Size(71, 20);
            this.txt_Other_US.TabIndex = 11;
            // 
            // groupBox2
            // 
            this.groupBox2.AutoSize = true;
            this.groupBox2.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.groupBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.groupBox2.Controls.Add(this.tableLayoutPanel1);
            this.groupBox2.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.groupBox2.Location = new System.Drawing.Point(15, 21);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(200, 234);
            this.groupBox2.TabIndex = 14;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "GIT";
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.Controls.Add(this.ch_Abn_Feces_GIT, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.ch_Excessive_Gas_GIT, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.ch_Parasites_GIT, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.ch_Vomiting_GIT, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.ch_Anorexia_GIT, 0, 6);
            this.tableLayoutPanel1.Controls.Add(this.ch_Other_GIT, 0, 11);
            this.tableLayoutPanel1.Controls.Add(this.txt_Other_GIT, 1, 11);
            this.tableLayoutPanel1.Controls.Add(this.ch_Diarrhea_GIT, 0, 5);
            this.tableLayoutPanel1.Controls.Add(this.ch_Normal_GIT, 0, 0);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(6, 24);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 12;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.Size = new System.Drawing.Size(188, 191);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // ch_Abn_Feces_GIT
            // 
            this.ch_Abn_Feces_GIT.AutoSize = true;
            this.ch_Abn_Feces_GIT.Location = new System.Drawing.Point(3, 26);
            this.ch_Abn_Feces_GIT.Name = "ch_Abn_Feces_GIT";
            this.ch_Abn_Feces_GIT.Size = new System.Drawing.Size(86, 17);
            this.ch_Abn_Feces_GIT.TabIndex = 1;
            this.ch_Abn_Feces_GIT.Text = "Abn. Feces";
            this.ch_Abn_Feces_GIT.UseVisualStyleBackColor = true;
            // 
            // ch_Excessive_Gas_GIT
            // 
            this.ch_Excessive_Gas_GIT.AutoSize = true;
            this.ch_Excessive_Gas_GIT.Location = new System.Drawing.Point(3, 49);
            this.ch_Excessive_Gas_GIT.Name = "ch_Excessive_Gas_GIT";
            this.ch_Excessive_Gas_GIT.Size = new System.Drawing.Size(105, 17);
            this.ch_Excessive_Gas_GIT.TabIndex = 2;
            this.ch_Excessive_Gas_GIT.Text = "Excessive Gas";
            this.ch_Excessive_Gas_GIT.UseVisualStyleBackColor = true;
            // 
            // ch_Parasites_GIT
            // 
            this.ch_Parasites_GIT.AutoSize = true;
            this.ch_Parasites_GIT.Location = new System.Drawing.Point(3, 72);
            this.ch_Parasites_GIT.Name = "ch_Parasites_GIT";
            this.ch_Parasites_GIT.Size = new System.Drawing.Size(79, 17);
            this.ch_Parasites_GIT.TabIndex = 3;
            this.ch_Parasites_GIT.Text = "Parasites";
            this.ch_Parasites_GIT.UseVisualStyleBackColor = true;
            // 
            // ch_Vomiting_GIT
            // 
            this.ch_Vomiting_GIT.AutoSize = true;
            this.ch_Vomiting_GIT.Location = new System.Drawing.Point(3, 95);
            this.ch_Vomiting_GIT.Name = "ch_Vomiting_GIT";
            this.ch_Vomiting_GIT.Size = new System.Drawing.Size(76, 17);
            this.ch_Vomiting_GIT.TabIndex = 4;
            this.ch_Vomiting_GIT.Text = "Vomiting";
            this.ch_Vomiting_GIT.UseVisualStyleBackColor = true;
            // 
            // ch_Anorexia_GIT
            // 
            this.ch_Anorexia_GIT.AutoSize = true;
            this.ch_Anorexia_GIT.Location = new System.Drawing.Point(3, 141);
            this.ch_Anorexia_GIT.Name = "ch_Anorexia_GIT";
            this.ch_Anorexia_GIT.Size = new System.Drawing.Size(77, 17);
            this.ch_Anorexia_GIT.TabIndex = 6;
            this.ch_Anorexia_GIT.Text = "Anorexia";
            this.ch_Anorexia_GIT.UseVisualStyleBackColor = true;
            // 
            // ch_Other_GIT
            // 
            this.ch_Other_GIT.AutoSize = true;
            this.ch_Other_GIT.Location = new System.Drawing.Point(3, 164);
            this.ch_Other_GIT.Name = "ch_Other_GIT";
            this.ch_Other_GIT.Size = new System.Drawing.Size(58, 17);
            this.ch_Other_GIT.TabIndex = 10;
            this.ch_Other_GIT.Text = "Other";
            this.ch_Other_GIT.UseVisualStyleBackColor = true;
            this.ch_Other_GIT.CheckedChanged += new System.EventHandler(this.ch_Other_GIT_CheckedChanged);
            // 
            // txt_Other_GIT
            // 
            this.txt_Other_GIT.Location = new System.Drawing.Point(114, 164);
            this.txt_Other_GIT.Name = "txt_Other_GIT";
            this.txt_Other_GIT.Size = new System.Drawing.Size(71, 20);
            this.txt_Other_GIT.TabIndex = 11;
            // 
            // ch_Diarrhea_GIT
            // 
            this.ch_Diarrhea_GIT.AutoSize = true;
            this.ch_Diarrhea_GIT.Location = new System.Drawing.Point(3, 118);
            this.ch_Diarrhea_GIT.Name = "ch_Diarrhea_GIT";
            this.ch_Diarrhea_GIT.Size = new System.Drawing.Size(75, 17);
            this.ch_Diarrhea_GIT.TabIndex = 5;
            this.ch_Diarrhea_GIT.Text = "Diarrhea";
            this.ch_Diarrhea_GIT.UseVisualStyleBackColor = true;
            // 
            // ch_Normal_GIT
            // 
            this.ch_Normal_GIT.AutoSize = true;
            this.ch_Normal_GIT.Location = new System.Drawing.Point(3, 3);
            this.ch_Normal_GIT.Name = "ch_Normal_GIT";
            this.ch_Normal_GIT.Size = new System.Drawing.Size(66, 17);
            this.ch_Normal_GIT.TabIndex = 0;
            this.ch_Normal_GIT.Text = "Normal";
            this.ch_Normal_GIT.UseVisualStyleBackColor = true;
            // 
            // rtxt_Diagnosis_Explanations
            // 
            this.rtxt_Diagnosis_Explanations.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.rtxt_Diagnosis_Explanations.Location = new System.Drawing.Point(15, 293);
            this.rtxt_Diagnosis_Explanations.Name = "rtxt_Diagnosis_Explanations";
            this.rtxt_Diagnosis_Explanations.Size = new System.Drawing.Size(770, 103);
            this.rtxt_Diagnosis_Explanations.TabIndex = 17;
            this.rtxt_Diagnosis_Explanations.Text = "";
            this.rtxt_Diagnosis_Explanations.TextChanged += new System.EventHandler(this.richTextBox2_TextChanged);
            // 
            // rtxt_Recommendations
            // 
            this.rtxt_Recommendations.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.rtxt_Recommendations.Location = new System.Drawing.Point(15, 446);
            this.rtxt_Recommendations.Name = "rtxt_Recommendations";
            this.rtxt_Recommendations.Size = new System.Drawing.Size(770, 103);
            this.rtxt_Recommendations.TabIndex = 18;
            this.rtxt_Recommendations.Text = "";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold);
            this.label1.Location = new System.Drawing.Point(12, 268);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(178, 17);
            this.label1.TabIndex = 19;
            this.label1.Text = "Diagnosis/ Explanations:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold);
            this.label2.Location = new System.Drawing.Point(12, 422);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(141, 17);
            this.label2.TabIndex = 20;
            this.label2.Text = "Recommendations:";
            // 
            // label3
            // 
            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.label3.Location = new System.Drawing.Point(12, 567);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(36, 14);
            this.label3.TabIndex = 22;
            this.label3.Text = "Price";
            // 
            // txt_Price
            // 
            this.txt_Price.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.txt_Price.Location = new System.Drawing.Point(53, 565);
            this.txt_Price.Name = "txt_Price";
            this.txt_Price.Size = new System.Drawing.Size(57, 20);
            this.txt_Price.TabIndex = 23;
            this.txt_Price.Tag = "";
            this.txt_Price.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_Price_KeyPress);
            // 
            // label4
            // 
            this.label4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.label4.Location = new System.Drawing.Point(12, 601);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(29, 14);
            this.label4.TabIndex = 24;
            this.label4.Text = "Pay";
            // 
            // txt_Pay
            // 
            this.txt_Pay.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.txt_Pay.Location = new System.Drawing.Point(53, 599);
            this.txt_Pay.Name = "txt_Pay";
            this.txt_Pay.Size = new System.Drawing.Size(57, 20);
            this.txt_Pay.TabIndex = 25;
            this.txt_Pay.Tag = "";
            this.txt_Pay.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_Pay_KeyPress);
            // 
            // label5
            // 
            this.label5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.label5.Location = new System.Drawing.Point(110, 567);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(22, 14);
            this.label5.TabIndex = 26;
            this.label5.Text = "JD";
            // 
            // label6
            // 
            this.label6.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.label6.Location = new System.Drawing.Point(110, 601);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(22, 14);
            this.label6.TabIndex = 27;
            this.label6.Text = "JD";
            // 
            // circularButton3
            // 
            this.circularButton3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.circularButton3.AutoSize = true;
            this.circularButton3.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.circularButton3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.circularButton3.FlatAppearance.BorderSize = 0;
            this.circularButton3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.circularButton3.Image = ((System.Drawing.Image)(resources.GetObject("circularButton3.Image")));
            this.circularButton3.Location = new System.Drawing.Point(720, 565);
            this.circularButton3.Name = "circularButton3";
            this.circularButton3.Size = new System.Drawing.Size(61, 61);
            this.circularButton3.TabIndex = 36;
            this.circularButton3.UseVisualStyleBackColor = true;
            this.circularButton3.Click += new System.EventHandler(this.CircularButton3_Click);
            // 
            // circularButton1
            // 
            this.circularButton1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.circularButton1.AutoSize = true;
            this.circularButton1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.circularButton1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.circularButton1.FlatAppearance.BorderSize = 0;
            this.circularButton1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.circularButton1.Image = ((System.Drawing.Image)(resources.GetObject("circularButton1.Image")));
            this.circularButton1.Location = new System.Drawing.Point(669, 570);
            this.circularButton1.Name = "circularButton1";
            this.circularButton1.Size = new System.Drawing.Size(56, 56);
            this.circularButton1.TabIndex = 34;
            this.circularButton1.UseVisualStyleBackColor = true;
            this.circularButton1.Click += new System.EventHandler(this.circularButton1_Click);
            // 
            // Physical_Examination2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.ClientSize = new System.Drawing.Size(800, 638);
            this.Controls.Add(this.circularButton3);
            this.Controls.Add(this.circularButton1);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txt_Pay);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txt_Price);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.rtxt_Recommendations);
            this.Controls.Add(this.rtxt_Diagnosis_Explanations);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Name = "Physical_Examination2";
            this.Text = "Physical_Examination";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Physical_Examination2_FormClosing);
            this.Load += new System.EventHandler(this.Physical_Examination2_Load);
            this.groupBox4.ResumeLayout(false);
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel3.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.CheckBox ch_Excellent_D;
        private System.Windows.Forms.CheckBox ch_Good_D;
        private System.Windows.Forms.CheckBox ch_Change_Diet_D;
        private System.Windows.Forms.CheckBox ch_Vitamins_needed_D;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.CheckBox ch_Normal_US;
        private System.Windows.Forms.CheckBox ch_Abnormal_Urination_US;
        private System.Windows.Forms.CheckBox ch_Anal_Sacs_US;
        private System.Windows.Forms.CheckBox ch_Genital_Discharge_C_US;
        private System.Windows.Forms.CheckBox ch_Mammary_Abn_US;
        private System.Windows.Forms.CheckBox ch_Other_US;
        private System.Windows.Forms.CheckBox ch_Abn_Testicles_US;
        private System.Windows.Forms.TextBox txt_Other_US;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.CheckBox ch_Normal_GIT;
        private System.Windows.Forms.CheckBox ch_Abn_Feces_GIT;
        private System.Windows.Forms.CheckBox ch_Excessive_Gas_GIT;
        private System.Windows.Forms.CheckBox ch_Parasites_GIT;
        private System.Windows.Forms.CheckBox ch_Vomiting_GIT;
        private System.Windows.Forms.CheckBox ch_Anorexia_GIT;
        private System.Windows.Forms.CheckBox ch_Other_GIT;
        private System.Windows.Forms.CheckBox ch_Diarrhea_GIT;
        private System.Windows.Forms.TextBox txt_Other_GIT;
        private System.Windows.Forms.CheckBox ch_Recommendations_D;
        private System.Windows.Forms.RichTextBox rtxt_Recommendations_D;
        private System.Windows.Forms.RichTextBox rtxt_Diagnosis_Explanations;
        private System.Windows.Forms.RichTextBox rtxt_Recommendations;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txt_Price;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txt_Pay;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private CircularButton circularButton3;
        private CircularButton circularButton1;
    }
}