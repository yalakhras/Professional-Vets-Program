﻿namespace Professional_Vets
{
    partial class Primary_Vaccination
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Primary_Vaccination));
            this.btn_NPV = new System.Windows.Forms.Button();
            this.rtxt_Notes_PVR = new System.Windows.Forms.RichTextBox();
            this.but_pvr = new System.Windows.Forms.Button();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.btn_THC = new System.Windows.Forms.Button();
            this.btn_BS = new System.Windows.Forms.Button();
            this.txt_Weight_PVR = new System.Windows.Forms.TextBox();
            this.btn_We = new System.Windows.Forms.Button();
            this.btn_NeD = new System.Windows.Forms.Button();
            this.txt_FT_PVR = new System.Windows.Forms.TextBox();
            this.btn_FT = new System.Windows.Forms.Button();
            this.btn_DHA = new System.Windows.Forms.Button();
            this.txt_BS_PVR = new System.Windows.Forms.TextBox();
            this.txt_THC_PVR = new System.Windows.Forms.TextBox();
            this.txt_DHS_PVR = new System.Windows.Forms.DateTimePicker();
            this.txt_ND_PVR = new System.Windows.Forms.DateTimePicker();
            this.btn_FY = new System.Windows.Forms.Button();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.NDate1_PVR = new System.Windows.Forms.DateTimePicker();
            this.Date1_PVR = new System.Windows.Forms.DateTimePicker();
            this.Dr_Name4_PVR = new System.Windows.Forms.TextBox();
            this.Dr_Name3_PVR = new System.Windows.Forms.TextBox();
            this.Dr_Name2_PVR = new System.Windows.Forms.TextBox();
            this.VB2_PVR = new System.Windows.Forms.TextBox();
            this.btn_Date = new System.Windows.Forms.Button();
            this.btn_VBn = new System.Windows.Forms.Button();
            this.btn_DrN = new System.Windows.Forms.Button();
            this.btn_ND = new System.Windows.Forms.Button();
            this.VB1_PVR = new System.Windows.Forms.TextBox();
            this.VB3_PVR = new System.Windows.Forms.TextBox();
            this.VB4_PVR = new System.Windows.Forms.TextBox();
            this.Dr_Name1_PVR = new System.Windows.Forms.TextBox();
            this.Date2_PVR = new System.Windows.Forms.DateTimePicker();
            this.Date3_PVR = new System.Windows.Forms.DateTimePicker();
            this.Date4_PVR = new System.Windows.Forms.DateTimePicker();
            this.NDate2_PVR = new System.Windows.Forms.DateTimePicker();
            this.NDate3_PVR = new System.Windows.Forms.DateTimePicker();
            this.NDate4_PVR = new System.Windows.Forms.DateTimePicker();
            this.circularButton3 = new Professional_Vets.CircularButton();
            this.circularButton1 = new Professional_Vets.CircularButton();
            this.tableLayoutPanel2.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btn_NPV
            // 
            this.btn_NPV.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btn_NPV.BackColor = System.Drawing.Color.Blue;
            this.btn_NPV.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btn_NPV.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.btn_NPV.ForeColor = System.Drawing.Color.White;
            this.btn_NPV.Location = new System.Drawing.Point(527, 22);
            this.btn_NPV.Name = "btn_NPV";
            this.btn_NPV.Size = new System.Drawing.Size(260, 23);
            this.btn_NPV.TabIndex = 40;
            this.btn_NPV.Text = "Notes for Primary Vaccination";
            this.btn_NPV.UseCompatibleTextRendering = true;
            this.btn_NPV.UseVisualStyleBackColor = false;
            // 
            // rtxt_Notes_PVR
            // 
            this.rtxt_Notes_PVR.Location = new System.Drawing.Point(527, 51);
            this.rtxt_Notes_PVR.Name = "rtxt_Notes_PVR";
            this.rtxt_Notes_PVR.Size = new System.Drawing.Size(261, 353);
            this.rtxt_Notes_PVR.TabIndex = 41;
            this.rtxt_Notes_PVR.Text = "Notes";
            // 
            // but_pvr
            // 
            this.but_pvr.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.but_pvr.BackColor = System.Drawing.Color.Blue;
            this.but_pvr.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.but_pvr.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.but_pvr.ForeColor = System.Drawing.Color.White;
            this.but_pvr.Location = new System.Drawing.Point(12, 22);
            this.but_pvr.Name = "but_pvr";
            this.but_pvr.Size = new System.Drawing.Size(336, 23);
            this.but_pvr.TabIndex = 36;
            this.but_pvr.Text = "Primary Vaccination record";
            this.but_pvr.UseCompatibleTextRendering = true;
            this.but_pvr.UseVisualStyleBackColor = false;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.AutoSize = true;
            this.tableLayoutPanel2.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.tableLayoutPanel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.tableLayoutPanel2.ColumnCount = 2;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 70F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.tableLayoutPanel2.Controls.Add(this.btn_THC, 0, 5);
            this.tableLayoutPanel2.Controls.Add(this.btn_BS, 0, 4);
            this.tableLayoutPanel2.Controls.Add(this.txt_Weight_PVR, 1, 3);
            this.tableLayoutPanel2.Controls.Add(this.btn_We, 0, 3);
            this.tableLayoutPanel2.Controls.Add(this.btn_NeD, 0, 2);
            this.tableLayoutPanel2.Controls.Add(this.txt_FT_PVR, 1, 1);
            this.tableLayoutPanel2.Controls.Add(this.btn_FT, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.btn_DHA, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.txt_BS_PVR, 1, 4);
            this.tableLayoutPanel2.Controls.Add(this.txt_THC_PVR, 1, 5);
            this.tableLayoutPanel2.Controls.Add(this.txt_DHS_PVR, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.txt_ND_PVR, 1, 2);
            this.tableLayoutPanel2.Location = new System.Drawing.Point(12, 241);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 6;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel2.Size = new System.Drawing.Size(470, 163);
            this.tableLayoutPanel2.TabIndex = 38;
            // 
            // btn_THC
            // 
            this.btn_THC.BackColor = System.Drawing.SystemColors.Control;
            this.btn_THC.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn_THC.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.btn_THC.ForeColor = System.Drawing.Color.DarkBlue;
            this.btn_THC.Location = new System.Drawing.Point(2, 137);
            this.btn_THC.Margin = new System.Windows.Forms.Padding(2);
            this.btn_THC.Name = "btn_THC";
            this.btn_THC.Size = new System.Drawing.Size(325, 24);
            this.btn_THC.TabIndex = 32;
            this.btn_THC.Text = "Teeth health check";
            this.btn_THC.UseCompatibleTextRendering = true;
            this.btn_THC.UseVisualStyleBackColor = false;
            // 
            // btn_BS
            // 
            this.btn_BS.BackColor = System.Drawing.SystemColors.Control;
            this.btn_BS.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn_BS.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.btn_BS.ForeColor = System.Drawing.Color.DarkBlue;
            this.btn_BS.Location = new System.Drawing.Point(2, 110);
            this.btn_BS.Margin = new System.Windows.Forms.Padding(2);
            this.btn_BS.Name = "btn_BS";
            this.btn_BS.Size = new System.Drawing.Size(325, 23);
            this.btn_BS.TabIndex = 30;
            this.btn_BS.Text = "Body score";
            this.btn_BS.UseCompatibleTextRendering = true;
            this.btn_BS.UseVisualStyleBackColor = false;
            // 
            // txt_Weight_PVR
            // 
            this.txt_Weight_PVR.Location = new System.Drawing.Point(332, 84);
            this.txt_Weight_PVR.Name = "txt_Weight_PVR";
            this.txt_Weight_PVR.Size = new System.Drawing.Size(135, 20);
            this.txt_Weight_PVR.TabIndex = 29;
            // 
            // btn_We
            // 
            this.btn_We.BackColor = System.Drawing.SystemColors.Control;
            this.btn_We.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn_We.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.btn_We.ForeColor = System.Drawing.Color.DarkBlue;
            this.btn_We.Location = new System.Drawing.Point(2, 83);
            this.btn_We.Margin = new System.Windows.Forms.Padding(2);
            this.btn_We.Name = "btn_We";
            this.btn_We.Size = new System.Drawing.Size(325, 23);
            this.btn_We.TabIndex = 28;
            this.btn_We.Text = "Weight (at date of assessment)";
            this.btn_We.UseCompatibleTextRendering = true;
            this.btn_We.UseVisualStyleBackColor = false;
            // 
            // btn_NeD
            // 
            this.btn_NeD.BackColor = System.Drawing.SystemColors.Control;
            this.btn_NeD.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn_NeD.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.btn_NeD.ForeColor = System.Drawing.Color.DarkBlue;
            this.btn_NeD.Location = new System.Drawing.Point(2, 56);
            this.btn_NeD.Margin = new System.Windows.Forms.Padding(2);
            this.btn_NeD.Name = "btn_NeD";
            this.btn_NeD.Size = new System.Drawing.Size(325, 23);
            this.btn_NeD.TabIndex = 26;
            this.btn_NeD.Text = "Neutering date";
            this.btn_NeD.UseCompatibleTextRendering = true;
            this.btn_NeD.UseVisualStyleBackColor = false;
            // 
            // txt_FT_PVR
            // 
            this.txt_FT_PVR.Location = new System.Drawing.Point(332, 30);
            this.txt_FT_PVR.Name = "txt_FT_PVR";
            this.txt_FT_PVR.Size = new System.Drawing.Size(135, 20);
            this.txt_FT_PVR.TabIndex = 25;
            // 
            // btn_FT
            // 
            this.btn_FT.BackColor = System.Drawing.SystemColors.Control;
            this.btn_FT.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn_FT.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.btn_FT.ForeColor = System.Drawing.Color.DarkBlue;
            this.btn_FT.Location = new System.Drawing.Point(2, 29);
            this.btn_FT.Margin = new System.Windows.Forms.Padding(2);
            this.btn_FT.Name = "btn_FT";
            this.btn_FT.Size = new System.Drawing.Size(325, 23);
            this.btn_FT.TabIndex = 24;
            this.btn_FT.Text = "Food type";
            this.btn_FT.UseCompatibleTextRendering = true;
            this.btn_FT.UseVisualStyleBackColor = false;
            // 
            // btn_DHA
            // 
            this.btn_DHA.BackColor = System.Drawing.SystemColors.Control;
            this.btn_DHA.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn_DHA.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.btn_DHA.ForeColor = System.Drawing.Color.DarkBlue;
            this.btn_DHA.Location = new System.Drawing.Point(2, 2);
            this.btn_DHA.Margin = new System.Windows.Forms.Padding(2);
            this.btn_DHA.Name = "btn_DHA";
            this.btn_DHA.Size = new System.Drawing.Size(325, 23);
            this.btn_DHA.TabIndex = 22;
            this.btn_DHA.Text = "Date of health assessment";
            this.btn_DHA.UseCompatibleTextRendering = true;
            this.btn_DHA.UseVisualStyleBackColor = false;
            // 
            // txt_BS_PVR
            // 
            this.txt_BS_PVR.Location = new System.Drawing.Point(332, 111);
            this.txt_BS_PVR.Name = "txt_BS_PVR";
            this.txt_BS_PVR.Size = new System.Drawing.Size(135, 20);
            this.txt_BS_PVR.TabIndex = 31;
            // 
            // txt_THC_PVR
            // 
            this.txt_THC_PVR.Location = new System.Drawing.Point(332, 138);
            this.txt_THC_PVR.Name = "txt_THC_PVR";
            this.txt_THC_PVR.Size = new System.Drawing.Size(135, 20);
            this.txt_THC_PVR.TabIndex = 33;
            // 
            // txt_DHS_PVR
            // 
            this.txt_DHS_PVR.CustomFormat = " ";
            this.txt_DHS_PVR.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.txt_DHS_PVR.Location = new System.Drawing.Point(332, 3);
            this.txt_DHS_PVR.Name = "txt_DHS_PVR";
            this.txt_DHS_PVR.Size = new System.Drawing.Size(135, 20);
            this.txt_DHS_PVR.TabIndex = 23;
            this.txt_DHS_PVR.Value = new System.DateTime(2000, 1, 1, 0, 0, 0, 0);
            this.txt_DHS_PVR.ValueChanged += new System.EventHandler(this.txt_DHS_PVR_ValueChanged);
            // 
            // txt_ND_PVR
            // 
            this.txt_ND_PVR.CustomFormat = " ";
            this.txt_ND_PVR.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.txt_ND_PVR.Location = new System.Drawing.Point(332, 57);
            this.txt_ND_PVR.Name = "txt_ND_PVR";
            this.txt_ND_PVR.Size = new System.Drawing.Size(135, 20);
            this.txt_ND_PVR.TabIndex = 27;
            this.txt_ND_PVR.Value = new System.DateTime(2000, 1, 1, 0, 0, 0, 0);
            this.txt_ND_PVR.ValueChanged += new System.EventHandler(this.txt_ND_PVR_ValueChanged);
            // 
            // btn_FY
            // 
            this.btn_FY.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btn_FY.BackColor = System.Drawing.Color.Blue;
            this.btn_FY.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btn_FY.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.btn_FY.ForeColor = System.Drawing.Color.White;
            this.btn_FY.Location = new System.Drawing.Point(12, 212);
            this.btn_FY.Name = "btn_FY";
            this.btn_FY.Size = new System.Drawing.Size(336, 23);
            this.btn_FY.TabIndex = 39;
            this.btn_FY.Text = "First year check list";
            this.btn_FY.UseCompatibleTextRendering = true;
            this.btn_FY.UseVisualStyleBackColor = false;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.AutoSize = true;
            this.tableLayoutPanel1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.tableLayoutPanel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.tableLayoutPanel1.ColumnCount = 4;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.Controls.Add(this.NDate1_PVR, 3, 1);
            this.tableLayoutPanel1.Controls.Add(this.Date1_PVR, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.Dr_Name4_PVR, 2, 4);
            this.tableLayoutPanel1.Controls.Add(this.Dr_Name3_PVR, 2, 3);
            this.tableLayoutPanel1.Controls.Add(this.Dr_Name2_PVR, 2, 2);
            this.tableLayoutPanel1.Controls.Add(this.VB2_PVR, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.btn_Date, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.btn_VBn, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.btn_DrN, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.btn_ND, 3, 0);
            this.tableLayoutPanel1.Controls.Add(this.VB1_PVR, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.VB3_PVR, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.VB4_PVR, 1, 4);
            this.tableLayoutPanel1.Controls.Add(this.Dr_Name1_PVR, 2, 1);
            this.tableLayoutPanel1.Controls.Add(this.Date2_PVR, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.Date3_PVR, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.Date4_PVR, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.NDate2_PVR, 3, 2);
            this.tableLayoutPanel1.Controls.Add(this.NDate3_PVR, 3, 3);
            this.tableLayoutPanel1.Controls.Add(this.NDate4_PVR, 3, 4);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(12, 51);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 5;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.Size = new System.Drawing.Size(503, 131);
            this.tableLayoutPanel1.TabIndex = 37;
            // 
            // NDate1_PVR
            // 
            this.NDate1_PVR.CustomFormat = " ";
            this.NDate1_PVR.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.NDate1_PVR.Location = new System.Drawing.Point(370, 30);
            this.NDate1_PVR.Name = "NDate1_PVR";
            this.NDate1_PVR.Size = new System.Drawing.Size(129, 20);
            this.NDate1_PVR.TabIndex = 8;
            this.NDate1_PVR.Value = new System.DateTime(2000, 1, 1, 0, 0, 0, 0);
            this.NDate1_PVR.ValueChanged += new System.EventHandler(this.NDate1_PVR_ValueChanged);
            // 
            // Date1_PVR
            // 
            this.Date1_PVR.CustomFormat = " ";
            this.Date1_PVR.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.Date1_PVR.Location = new System.Drawing.Point(3, 30);
            this.Date1_PVR.Name = "Date1_PVR";
            this.Date1_PVR.Size = new System.Drawing.Size(129, 20);
            this.Date1_PVR.TabIndex = 5;
            this.Date1_PVR.Value = new System.DateTime(2000, 1, 1, 0, 0, 0, 0);
            this.Date1_PVR.ValueChanged += new System.EventHandler(this.Date1_PVR_ValueChanged);
            // 
            // Dr_Name4_PVR
            // 
            this.Dr_Name4_PVR.Location = new System.Drawing.Point(290, 108);
            this.Dr_Name4_PVR.Name = "Dr_Name4_PVR";
            this.Dr_Name4_PVR.Size = new System.Drawing.Size(74, 20);
            this.Dr_Name4_PVR.TabIndex = 19;
            // 
            // Dr_Name3_PVR
            // 
            this.Dr_Name3_PVR.Location = new System.Drawing.Point(290, 82);
            this.Dr_Name3_PVR.Name = "Dr_Name3_PVR";
            this.Dr_Name3_PVR.Size = new System.Drawing.Size(74, 20);
            this.Dr_Name3_PVR.TabIndex = 15;
            // 
            // Dr_Name2_PVR
            // 
            this.Dr_Name2_PVR.Location = new System.Drawing.Point(290, 56);
            this.Dr_Name2_PVR.Name = "Dr_Name2_PVR";
            this.Dr_Name2_PVR.Size = new System.Drawing.Size(74, 20);
            this.Dr_Name2_PVR.TabIndex = 11;
            // 
            // VB2_PVR
            // 
            this.VB2_PVR.Dock = System.Windows.Forms.DockStyle.Fill;
            this.VB2_PVR.Location = new System.Drawing.Point(138, 56);
            this.VB2_PVR.Name = "VB2_PVR";
            this.VB2_PVR.Size = new System.Drawing.Size(146, 20);
            this.VB2_PVR.TabIndex = 10;
            this.VB2_PVR.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // btn_Date
            // 
            this.btn_Date.BackColor = System.Drawing.Color.Blue;
            this.btn_Date.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn_Date.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.btn_Date.ForeColor = System.Drawing.Color.White;
            this.btn_Date.Location = new System.Drawing.Point(2, 2);
            this.btn_Date.Margin = new System.Windows.Forms.Padding(2);
            this.btn_Date.Name = "btn_Date";
            this.btn_Date.Size = new System.Drawing.Size(131, 23);
            this.btn_Date.TabIndex = 1;
            this.btn_Date.Text = "Date";
            this.btn_Date.UseVisualStyleBackColor = false;
            // 
            // btn_VBn
            // 
            this.btn_VBn.BackColor = System.Drawing.Color.Blue;
            this.btn_VBn.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn_VBn.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.btn_VBn.ForeColor = System.Drawing.Color.White;
            this.btn_VBn.Location = new System.Drawing.Point(137, 2);
            this.btn_VBn.Margin = new System.Windows.Forms.Padding(2);
            this.btn_VBn.Name = "btn_VBn";
            this.btn_VBn.Size = new System.Drawing.Size(148, 23);
            this.btn_VBn.TabIndex = 2;
            this.btn_VBn.Text = "Vaccine/ Batch No.";
            this.btn_VBn.UseVisualStyleBackColor = false;
            // 
            // btn_DrN
            // 
            this.btn_DrN.BackColor = System.Drawing.Color.Blue;
            this.btn_DrN.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn_DrN.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.btn_DrN.ForeColor = System.Drawing.Color.White;
            this.btn_DrN.Location = new System.Drawing.Point(289, 2);
            this.btn_DrN.Margin = new System.Windows.Forms.Padding(2);
            this.btn_DrN.Name = "btn_DrN";
            this.btn_DrN.Size = new System.Drawing.Size(76, 23);
            this.btn_DrN.TabIndex = 3;
            this.btn_DrN.Text = "Dr. Name";
            this.btn_DrN.UseCompatibleTextRendering = true;
            this.btn_DrN.UseVisualStyleBackColor = false;
            // 
            // btn_ND
            // 
            this.btn_ND.BackColor = System.Drawing.Color.Blue;
            this.btn_ND.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn_ND.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.btn_ND.ForeColor = System.Drawing.Color.White;
            this.btn_ND.Location = new System.Drawing.Point(369, 2);
            this.btn_ND.Margin = new System.Windows.Forms.Padding(2);
            this.btn_ND.Name = "btn_ND";
            this.btn_ND.Size = new System.Drawing.Size(132, 23);
            this.btn_ND.TabIndex = 4;
            this.btn_ND.Text = "Next Date";
            this.btn_ND.UseVisualStyleBackColor = false;
            // 
            // VB1_PVR
            // 
            this.VB1_PVR.Dock = System.Windows.Forms.DockStyle.Fill;
            this.VB1_PVR.Location = new System.Drawing.Point(138, 30);
            this.VB1_PVR.Name = "VB1_PVR";
            this.VB1_PVR.Size = new System.Drawing.Size(146, 20);
            this.VB1_PVR.TabIndex = 6;
            this.VB1_PVR.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // VB3_PVR
            // 
            this.VB3_PVR.Dock = System.Windows.Forms.DockStyle.Fill;
            this.VB3_PVR.Location = new System.Drawing.Point(138, 82);
            this.VB3_PVR.Name = "VB3_PVR";
            this.VB3_PVR.Size = new System.Drawing.Size(146, 20);
            this.VB3_PVR.TabIndex = 14;
            this.VB3_PVR.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // VB4_PVR
            // 
            this.VB4_PVR.Dock = System.Windows.Forms.DockStyle.Fill;
            this.VB4_PVR.Location = new System.Drawing.Point(138, 108);
            this.VB4_PVR.Name = "VB4_PVR";
            this.VB4_PVR.Size = new System.Drawing.Size(146, 20);
            this.VB4_PVR.TabIndex = 18;
            this.VB4_PVR.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Dr_Name1_PVR
            // 
            this.Dr_Name1_PVR.Location = new System.Drawing.Point(290, 30);
            this.Dr_Name1_PVR.Name = "Dr_Name1_PVR";
            this.Dr_Name1_PVR.Size = new System.Drawing.Size(74, 20);
            this.Dr_Name1_PVR.TabIndex = 7;
            // 
            // Date2_PVR
            // 
            this.Date2_PVR.CustomFormat = " ";
            this.Date2_PVR.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.Date2_PVR.Location = new System.Drawing.Point(3, 56);
            this.Date2_PVR.Name = "Date2_PVR";
            this.Date2_PVR.Size = new System.Drawing.Size(129, 20);
            this.Date2_PVR.TabIndex = 9;
            this.Date2_PVR.Value = new System.DateTime(2000, 1, 1, 0, 0, 0, 0);
            this.Date2_PVR.ValueChanged += new System.EventHandler(this.Date2_PVR_ValueChanged);
            // 
            // Date3_PVR
            // 
            this.Date3_PVR.CustomFormat = " ";
            this.Date3_PVR.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.Date3_PVR.Location = new System.Drawing.Point(3, 82);
            this.Date3_PVR.Name = "Date3_PVR";
            this.Date3_PVR.Size = new System.Drawing.Size(129, 20);
            this.Date3_PVR.TabIndex = 13;
            this.Date3_PVR.Value = new System.DateTime(2000, 1, 1, 0, 0, 0, 0);
            this.Date3_PVR.ValueChanged += new System.EventHandler(this.Date3_PVR_ValueChanged);
            // 
            // Date4_PVR
            // 
            this.Date4_PVR.CustomFormat = " ";
            this.Date4_PVR.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.Date4_PVR.Location = new System.Drawing.Point(3, 108);
            this.Date4_PVR.Name = "Date4_PVR";
            this.Date4_PVR.Size = new System.Drawing.Size(129, 20);
            this.Date4_PVR.TabIndex = 17;
            this.Date4_PVR.Value = new System.DateTime(2000, 1, 1, 0, 0, 0, 0);
            this.Date4_PVR.ValueChanged += new System.EventHandler(this.Date4_PVR_ValueChanged);
            // 
            // NDate2_PVR
            // 
            this.NDate2_PVR.CustomFormat = " ";
            this.NDate2_PVR.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.NDate2_PVR.Location = new System.Drawing.Point(370, 56);
            this.NDate2_PVR.Name = "NDate2_PVR";
            this.NDate2_PVR.Size = new System.Drawing.Size(129, 20);
            this.NDate2_PVR.TabIndex = 12;
            this.NDate2_PVR.Value = new System.DateTime(2000, 1, 1, 0, 0, 0, 0);
            this.NDate2_PVR.ValueChanged += new System.EventHandler(this.NDate2_PVR_ValueChanged);
            // 
            // NDate3_PVR
            // 
            this.NDate3_PVR.CustomFormat = " ";
            this.NDate3_PVR.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.NDate3_PVR.Location = new System.Drawing.Point(370, 82);
            this.NDate3_PVR.Name = "NDate3_PVR";
            this.NDate3_PVR.Size = new System.Drawing.Size(129, 20);
            this.NDate3_PVR.TabIndex = 16;
            this.NDate3_PVR.Value = new System.DateTime(2000, 1, 1, 0, 0, 0, 0);
            this.NDate3_PVR.ValueChanged += new System.EventHandler(this.NDate3_PVR_ValueChanged);
            // 
            // NDate4_PVR
            // 
            this.NDate4_PVR.CustomFormat = " ";
            this.NDate4_PVR.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.NDate4_PVR.Location = new System.Drawing.Point(370, 108);
            this.NDate4_PVR.Name = "NDate4_PVR";
            this.NDate4_PVR.Size = new System.Drawing.Size(129, 20);
            this.NDate4_PVR.TabIndex = 20;
            this.NDate4_PVR.Value = new System.DateTime(2000, 1, 1, 0, 0, 0, 0);
            this.NDate4_PVR.ValueChanged += new System.EventHandler(this.NDate4_PVR_ValueChanged);
            // 
            // circularButton3
            // 
            this.circularButton3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.circularButton3.AutoSize = true;
            this.circularButton3.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.circularButton3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.circularButton3.FlatAppearance.BorderSize = 0;
            this.circularButton3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.circularButton3.Image = ((System.Drawing.Image)(resources.GetObject("circularButton3.Image")));
            this.circularButton3.Location = new System.Drawing.Point(732, 424);
            this.circularButton3.Name = "circularButton3";
            this.circularButton3.Size = new System.Drawing.Size(56, 56);
            this.circularButton3.TabIndex = 44;
            this.circularButton3.UseVisualStyleBackColor = true;
            this.circularButton3.Click += new System.EventHandler(this.circularButton3_Click);
            // 
            // circularButton1
            // 
            this.circularButton1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.circularButton1.AutoSize = true;
            this.circularButton1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.circularButton1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.circularButton1.FlatAppearance.BorderSize = 0;
            this.circularButton1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.circularButton1.Image = ((System.Drawing.Image)(resources.GetObject("circularButton1.Image")));
            this.circularButton1.Location = new System.Drawing.Point(676, 424);
            this.circularButton1.Name = "circularButton1";
            this.circularButton1.Size = new System.Drawing.Size(56, 56);
            this.circularButton1.TabIndex = 42;
            this.circularButton1.UseVisualStyleBackColor = true;
            this.circularButton1.Click += new System.EventHandler(this.circularButton1_Click);
            // 
            // Primary_Vaccination
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.ClientSize = new System.Drawing.Size(800, 492);
            this.Controls.Add(this.circularButton3);
            this.Controls.Add(this.circularButton1);
            this.Controls.Add(this.btn_NPV);
            this.Controls.Add(this.rtxt_Notes_PVR);
            this.Controls.Add(this.but_pvr);
            this.Controls.Add(this.tableLayoutPanel2);
            this.Controls.Add(this.btn_FY);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "Primary_Vaccination";
            this.Text = "Primary_Vaccination";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Primary_Vaccination_FormClosing);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_NPV;
        private System.Windows.Forms.RichTextBox rtxt_Notes_PVR;
        private System.Windows.Forms.Button but_pvr;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Button btn_THC;
        private System.Windows.Forms.Button btn_BS;
        private System.Windows.Forms.TextBox txt_Weight_PVR;
        private System.Windows.Forms.Button btn_We;
        private System.Windows.Forms.Button btn_NeD;
        private System.Windows.Forms.TextBox txt_FT_PVR;
        private System.Windows.Forms.Button btn_FT;
        private System.Windows.Forms.Button btn_DHA;
        private System.Windows.Forms.TextBox txt_BS_PVR;
        private System.Windows.Forms.TextBox txt_THC_PVR;
        private System.Windows.Forms.DateTimePicker txt_DHS_PVR;
        private System.Windows.Forms.DateTimePicker txt_ND_PVR;
        private System.Windows.Forms.Button btn_FY;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.DateTimePicker NDate1_PVR;
        private System.Windows.Forms.DateTimePicker Date1_PVR;
        private System.Windows.Forms.TextBox Dr_Name4_PVR;
        private System.Windows.Forms.TextBox Dr_Name3_PVR;
        private System.Windows.Forms.TextBox Dr_Name2_PVR;
        private System.Windows.Forms.TextBox VB2_PVR;
        private System.Windows.Forms.Button btn_Date;
        private System.Windows.Forms.Button btn_VBn;
        private System.Windows.Forms.Button btn_DrN;
        private System.Windows.Forms.Button btn_ND;
        private System.Windows.Forms.TextBox VB1_PVR;
        private System.Windows.Forms.TextBox VB3_PVR;
        private System.Windows.Forms.TextBox VB4_PVR;
        private System.Windows.Forms.TextBox Dr_Name1_PVR;
        private System.Windows.Forms.DateTimePicker Date2_PVR;
        private System.Windows.Forms.DateTimePicker Date3_PVR;
        private System.Windows.Forms.DateTimePicker Date4_PVR;
        private System.Windows.Forms.DateTimePicker NDate2_PVR;
        private System.Windows.Forms.DateTimePicker NDate3_PVR;
        private System.Windows.Forms.DateTimePicker NDate4_PVR;
        private CircularButton circularButton3;
        private CircularButton circularButton1;
    }
}