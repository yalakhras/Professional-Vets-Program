﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Professional_Vets
{
    public partial class Worn_and_Flea_Control : Form
    {
        String vn, ow, mb, pt;

        SqlConnection con;
        SqlCommand cmd;

        public Worn_and_Flea_Control(String role, String owner, String mobile, String pet)
        {
            InitializeComponent();
            vn = role;
            ow = owner;
            mb = mobile;
            pt = pet;

        }


        private void Date1_WFC_ValueChanged(object sender, EventArgs e)
        {
            Date1_WFC.CustomFormat = "dd/MM/yyyy";

        }

        private void Date2_WFC_ValueChanged(object sender, EventArgs e)
        {
            if (!Date2_WFC.Checked)
            {
                // hide date value since it's not set
                Date2_WFC.CustomFormat = " ";
                Date2_WFC.Format = DateTimePickerFormat.Custom;
            }
            else
            {
                Date2_WFC.CustomFormat = "dd/MM/yyyy";
                Date2_WFC.Format = DateTimePickerFormat.Long; // set the date format you want.
            }
//            Date2_WFC.CustomFormat = "dd/MM/yyyy";
        }

        private void Date3_WFC_ValueChanged(object sender, EventArgs e)
        {
            Date3_WFC.CustomFormat = "dd/MM/yyyy";
        }

        private void Date4_WFC_ValueChanged(object sender, EventArgs e)
        {
            Date4_WFC.CustomFormat = "dd/MM/yyyy";
        }

        private void Date5_WFC_ValueChanged(object sender, EventArgs e)
        {
            Date5_WFC.CustomFormat = "dd/MM/yyyy";
        }

        private void Date6_WFC_ValueChanged(object sender, EventArgs e)
        {
            Date6_WFC.CustomFormat = "dd/MM/yyyy";
        }

        private void Date7_WFC_ValueChanged(object sender, EventArgs e)
        {
            Date7_WFC.CustomFormat = "dd/MM/yyyy";
        }

        private void Date8_WFC_ValueChanged(object sender, EventArgs e)
        {
            Date8_WFC.CustomFormat = "dd/MM/yyyy";
        }

        private void Date9_WFC_ValueChanged(object sender, EventArgs e)
        {
            Date9_WFC.CustomFormat = "dd/MM/yyyy";
        }

        private void Date10_WFC_ValueChanged(object sender, EventArgs e)
        {
            Date10_WFC.CustomFormat = "dd/MM/yyyy";
        }

        private void Date11_WFC_ValueChanged(object sender, EventArgs e)
        {
            Date11_WFC.CustomFormat = "dd/MM/yyyy";
        }

        private void Date12_WFC_ValueChanged(object sender, EventArgs e)
        {
            Date12_WFC.CustomFormat = "dd/MM/yyyy";
        }

        private void NDate1_WFC_ValueChanged(object sender, EventArgs e)
        {
            NDate1_WFC.CustomFormat = "dd/MM/yyyy";
        }

        private void NDate2_WFC_ValueChanged(object sender, EventArgs e)
        {
            NDate2_WFC.CustomFormat = "dd/MM/yyyy";
        }

        private void NDate3_WFC_ValueChanged(object sender, EventArgs e)
        {
            NDate3_WFC.CustomFormat = "dd/MM/yyyy";
        }

        private void NDate4_WFC_ValueChanged(object sender, EventArgs e)
        {
            NDate4_WFC.CustomFormat = "dd/MM/yyyy";
        }

        private void NDate5_WFC_ValueChanged(object sender, EventArgs e)
        {
            NDate5_WFC.CustomFormat = "dd/MM/yyyy";
        }

        private void NDate6_WFC_ValueChanged(object sender, EventArgs e)
        {
            NDate6_WFC.CustomFormat = "dd/MM/yyyy";
        }

        private void NDate7_WFC_ValueChanged(object sender, EventArgs e)
        {
            NDate7_WFC.CustomFormat = "dd/MM/yyyy";
        }

        private void NDate8_WFC_ValueChanged(object sender, EventArgs e)
        {
            NDate8_WFC.CustomFormat = "dd/MM/yyyy";
        }

        private void NDate9_WFC_ValueChanged(object sender, EventArgs e)
        {
            NDate9_WFC.CustomFormat = "dd/MM/yyyy";
        }

        private void NDate10_WFC_ValueChanged(object sender, EventArgs e)
        {
            NDate10_WFC.CustomFormat = "dd/MM/yyyy";
        }

        private void NDate11_WFC_ValueChanged(object sender, EventArgs e)
        {
            NDate11_WFC.CustomFormat = "dd/MM/yyyy";
        }

        private void NDate12_WFC_ValueChanged(object sender, EventArgs e)
        {
            NDate12_WFC.CustomFormat = "dd/MM/yyyy";
        }





        private void circularButton2_Click(object sender, EventArgs e)
        {
            con = new SqlConnection(Properties.Settings.Default.Database1ConnectionString);
            con.Open();

            cmd = new SqlCommand("Insert INTO WFC (Vet_Name, Owner, Mobile, Pet, Date_1, Vaccine_Batch_1, Dr_Name_1, Next_Date_1, Date_2, Vaccine_Batch_2, Dr_Name_2, Next_Date_2, Date_3, Vaccine_Batch_3, Dr_Name_3, Next_Date_3, Date_4, Vaccine_Batch_4, Dr_Name_4, Next_Date_4, Date_5, Vaccine_Batch_5, Dr_Name_5, Next_Date_5, Date_6, Vaccine_Batch_6, Dr_Name_6, Next_Date_6, Date_7, Vaccine_Batch_7, Dr_Name_7, Next_Date_7, Date_8, Vaccine_Batch_8, Dr_Name_8, Next_Date_8, Date_9, Vaccine_Batch_9, Dr_Name_9, Next_Date_9, Date_10, Vaccine_Batch_10, Dr_Name_10, Next_Date_10, Date_11, Vaccine_Batch_11, Dr_Name_11, Next_Date_11, Date_12, Vaccine_Batch_12, Dr_Name_12, Next_Date_12, Notes) VALUES (@Vet_Name, @Owner, @Mobile, @Pet, @Date_1, @Vaccine_Batch_1, @Dr_Name_1, @Next_Date_1, @Date_2, @Vaccine_Batch_2, @Dr_Name_2, @Next_Date_2, @Date_3, @Vaccine_Batch_3, @Dr_Name_3, @Next_Date_3, @Date_4, @Vaccine_Batch_4, @Dr_Name_4, @Next_Date_4, @Date_5, @Vaccine_Batch_5, @Dr_Name_5, @Next_Date_5, @Date_6, @Vaccine_Batch_6, @Dr_Name_6, @Next_Date_6, @Date_7, @Vaccine_Batch_7, @Dr_Name_7, @Next_Date_7, @Date_8, @Vaccine_Batch_8, @Dr_Name_8, @Next_Date_8, @Date_9, @Vaccine_Batch_9, @Dr_Name_9, @Next_Date_9, @Date_10, @Vaccine_Batch_10, @Dr_Name_10, @Next_Date_10, @Date_11, @Vaccine_Batch_11, @Dr_Name_11, @Next_Date_11, @Date_12, @Vaccine_Batch_12, @Dr_Name_12, @Next_Date_12, @Notes)", con);

            // Primary Vaccination record
            cmd.Parameters.AddWithValue("@Vet_Name", vn);
            cmd.Parameters.AddWithValue("@Owner", ow);
            cmd.Parameters.AddWithValue("@Mobile", mb);
            cmd.Parameters.AddWithValue("@Pet", pt);

            cmd.Parameters.AddWithValue("@Date_1", Date1_WFC.Value.ToShortDateString());
            cmd.Parameters.AddWithValue("@Vaccine_Batch_1", VB1_WFC.Text);
            cmd.Parameters.AddWithValue("@Dr_Name_1", Dr_Name1_WFC.Text);
            cmd.Parameters.AddWithValue("@Next_Date_1", NDate1_WFC.Value.ToShortDateString());

            cmd.Parameters.AddWithValue("@Date_2", Date2_WFC.Value.ToShortDateString());
            cmd.Parameters.AddWithValue("@Vaccine_Batch_2", VB2_WFC.Text);
            cmd.Parameters.AddWithValue("@Dr_Name_2", Dr_Name2_WFC.Text);
            cmd.Parameters.AddWithValue("@Next_Date_2", NDate2_WFC.Value.ToShortDateString());

            cmd.Parameters.AddWithValue("@Date_3", Date3_WFC.Value.ToShortDateString());
            cmd.Parameters.AddWithValue("@Vaccine_Batch_3", VB3_WFC.Text);
            cmd.Parameters.AddWithValue("@Dr_Name_3", Dr_Name3_WFC.Text);
            cmd.Parameters.AddWithValue("@Next_Date_3", NDate3_WFC.Value.ToShortDateString());

            cmd.Parameters.AddWithValue("@Date_4", Date4_WFC.Value.ToShortDateString());
            cmd.Parameters.AddWithValue("@Vaccine_Batch_4", VB4_WFC.Text);
            cmd.Parameters.AddWithValue("@Dr_Name_4", Dr_Name4_WFC.Text);
            cmd.Parameters.AddWithValue("@Next_Date_4", NDate4_WFC.Value.ToShortDateString());

            cmd.Parameters.AddWithValue("@Date_5", Date5_WFC.Value.ToShortDateString());
            cmd.Parameters.AddWithValue("@Vaccine_Batch_5", VB5_WFC.Text);
            cmd.Parameters.AddWithValue("@Dr_Name_5", Dr_Name5_WFC.Text);
            cmd.Parameters.AddWithValue("@Next_Date_5", NDate5_WFC.Value.ToShortDateString());

            cmd.Parameters.AddWithValue("@Date_6", Date6_WFC.Value.ToShortDateString());
            cmd.Parameters.AddWithValue("@Vaccine_Batch_6", VB6_WFC.Text);
            cmd.Parameters.AddWithValue("@Dr_Name_6", Dr_Name6_WFC.Text);
            cmd.Parameters.AddWithValue("@Next_Date_6", NDate6_WFC.Value.ToShortDateString());

            cmd.Parameters.AddWithValue("@Date_7", Date7_WFC.Value.ToShortDateString());
            cmd.Parameters.AddWithValue("@Vaccine_Batch_7", VB7_WFC.Text);
            cmd.Parameters.AddWithValue("@Dr_Name_7", Dr_Name7_WFC.Text);
            cmd.Parameters.AddWithValue("@Next_Date_7", NDate7_WFC.Value.ToShortDateString());

            cmd.Parameters.AddWithValue("@Date_8", Date8_WFC.Value.ToShortDateString());
            cmd.Parameters.AddWithValue("@Vaccine_Batch_8", VB8_WFC.Text);
            cmd.Parameters.AddWithValue("@Dr_Name_8", Dr_Name8_WFC.Text);
            cmd.Parameters.AddWithValue("@Next_Date_8", NDate8_WFC.Value.ToShortDateString());

            cmd.Parameters.AddWithValue("@Date_9", Date9_WFC.Value.ToShortDateString());
            cmd.Parameters.AddWithValue("@Vaccine_Batch_9", VB9_WFC.Text);
            cmd.Parameters.AddWithValue("@Dr_Name_9", Dr_Name9_WFC.Text);
            cmd.Parameters.AddWithValue("@Next_Date_9", NDate9_WFC.Value.ToShortDateString());

            cmd.Parameters.AddWithValue("@Date_10", Date10_WFC.Value.ToShortDateString());
            cmd.Parameters.AddWithValue("@Vaccine_Batch_10", VB10_WFC.Text);
            cmd.Parameters.AddWithValue("@Dr_Name_10", Dr_Name10_WFC.Text);
            cmd.Parameters.AddWithValue("@Next_Date_10", NDate10_WFC.Value.ToShortDateString());

            cmd.Parameters.AddWithValue("@Date_11", Date11_WFC.Value.ToShortDateString());
            cmd.Parameters.AddWithValue("@Vaccine_Batch_11", VB11_WFC.Text);
            cmd.Parameters.AddWithValue("@Dr_Name_11", Dr_Name11_WFC.Text);
            cmd.Parameters.AddWithValue("@Next_Date_11", NDate11_WFC.Value.ToShortDateString());

            cmd.Parameters.AddWithValue("@Date_12", Date12_WFC.Value.ToShortDateString());
            cmd.Parameters.AddWithValue("@Vaccine_Batch_12", VB12_WFC.Text);
            cmd.Parameters.AddWithValue("@Dr_Name_12", Dr_Name12_WFC.Text);
            cmd.Parameters.AddWithValue("@Next_Date_12", NDate12_WFC.Value.ToShortDateString());

            cmd.Parameters.AddWithValue("@Notes", rtxt_Notes_WFC.Text);

            cmd.ExecuteNonQuery();
            con.Close();

            this.Hide();
            Other_Vaccine OV = new Other_Vaccine(vn, ow, mb, pt);
            OV.ShowDialog();

        }


        private void circularButton5_Click(object sender, EventArgs e)
        {
            this.Hide();
            HomePage HP = new HomePage(vn);
            HP.ShowDialog();

        }
        



    }
}
