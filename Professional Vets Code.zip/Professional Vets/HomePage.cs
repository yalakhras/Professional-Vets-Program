﻿using System;
using System.Windows.Forms;

namespace Professional_Vets

{
    public partial class HomePage : Form
    {
        String vn;

        public HomePage(String role)
        {
            InitializeComponent();
            vn = role;
            label2.Text = vn;
            }


        private void HomePage_Load(object sender, EventArgs e)
        {
          
           if (label2.Text != "Atahat")
            {
                Admin_Button.Enabled = false;

            }

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
        
        private void circularButton6_Click(object sender, EventArgs e)
        {
            this.Hide();
            Boarding BD = new Boarding(vn);
            BD.ShowDialog();
        }

        private void circularButton4_Click(object sender, EventArgs e)
        {
            this.Hide();
            Daily_Transactions DaTr = new Daily_Transactions(vn);
            DaTr.ShowDialog();
        }

        private void circularButton2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Add_new_veterinary_status AdNew = new Add_new_veterinary_status(vn);
            AdNew.ShowDialog();
        }

        private void circularButton3_Click(object sender, EventArgs e)
        {
            this.Hide();
            Vaccination_Records VaR = new Vaccination_Records(vn);
            VaR.ShowDialog();

        }

        private void toolTip2_Popup(object sender, PopupEventArgs e)
        {

        }

        private void circularButton5_Click(object sender, EventArgs e)
        {
            this.Hide();
            Search_Options SO = new Search_Options(vn);
            SO.ShowDialog();
        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void HomePage_FormClosing(object sender, FormClosingEventArgs e)
        {
//            string message = "Are you sure that you want to Logout?";
//            string title = "Logout";
//            MessageBoxButtons buttons = MessageBoxButtons.YesNo;
//            DialogResult result = MessageBox.Show(message, title, buttons);

//            if (result == DialogResult.Yes)
//            {
                this.Hide();
                Login Lo = new Login();
                Lo.ShowDialog();

 //           }
 //           else if (result == DialogResult.No)
 //           {
 //               e.Cancel = true;
 //           }
        
                
            
        }

        private void Admin_Button_Click(object sender, EventArgs e)
        {
            this.Hide();
            Admin_Control AC = new Admin_Control();
            AC.ShowDialog();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            MessageBox.Show("This program Developed by: Yaser Al-Akhras. " +
                "Email: yaser.alakhras@gmail.com", "About", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}