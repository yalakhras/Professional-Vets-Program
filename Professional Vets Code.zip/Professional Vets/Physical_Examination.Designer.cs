﻿namespace Professional_Vets
{
    partial class Physical_Examination
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Physical_Examination));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtWight = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txtCRT = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtRR = new System.Windows.Forms.TextBox();
            this.txtRT = new System.Windows.Forms.TextBox();
            this.txtHR = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.ch_Appear_Normal_CAS = new System.Windows.Forms.CheckBox();
            this.ch_Pigment_CAS = new System.Windows.Forms.CheckBox();
            this.ch_Itchy_CAS = new System.Windows.Forms.CheckBox();
            this.ch_Lesion_CAS = new System.Windows.Forms.CheckBox();
            this.ch_Parasites_CAS = new System.Windows.Forms.CheckBox();
            this.ch_Scaly_CAS = new System.Windows.Forms.CheckBox();
            this.ch_Other_CAS = new System.Windows.Forms.CheckBox();
            this.txt_Other_CAS = new System.Windows.Forms.TextBox();
            this.ch_Dry_Dull_CAS = new System.Windows.Forms.CheckBox();
            this.ch_Hair_Loss_CAS = new System.Windows.Forms.CheckBox();
            this.ch_Lumps_CAS = new System.Windows.Forms.CheckBox();
            this.ch_Shedding_CAS = new System.Windows.Forms.CheckBox();
            this.ch_Greasy_CAS = new System.Windows.Forms.CheckBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.ch_Normal_Eyes = new System.Windows.Forms.CheckBox();
            this.ch_Cataract_Eyes = new System.Windows.Forms.CheckBox();
            this.ch_Discharges_Eyes = new System.Windows.Forms.CheckBox();
            this.ch_Inflamed_Eyes = new System.Windows.Forms.CheckBox();
            this.ch_Dry_Eye_Eyes = new System.Windows.Forms.CheckBox();
            this.ch_Infected_Eyes = new System.Windows.Forms.CheckBox();
            this.ch_Other_Eyes = new System.Windows.Forms.CheckBox();
            this.ch_Ulcers_Lesions_Eyes = new System.Windows.Forms.CheckBox();
            this.txt_Other_Eyes = new System.Windows.Forms.TextBox();
            this.cobo_Cataract_Eyes = new System.Windows.Forms.ComboBox();
            this.cobo_Discharges_Eyes = new System.Windows.Forms.ComboBox();
            this.cobo_Inflamed_Eyes = new System.Windows.Forms.ComboBox();
            this.cobo_Dry_Eye_Eyes = new System.Windows.Forms.ComboBox();
            this.cobo_Ulcers_Lesions_Eyes = new System.Windows.Forms.ComboBox();
            this.cobo_Infected_Eyes = new System.Windows.Forms.ComboBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.ch_Normal_Ears = new System.Windows.Forms.CheckBox();
            this.ch_Inflamed_Ears = new System.Windows.Forms.CheckBox();
            this.ch_Yeast_Inf_Ears = new System.Windows.Forms.CheckBox();
            this.ch_Bacterial_Ears = new System.Windows.Forms.CheckBox();
            this.ch_Itchy_Ears = new System.Windows.Forms.CheckBox();
            this.ch_Excessive_Debris_Hair_Ears = new System.Windows.Forms.CheckBox();
            this.ch_Other_Ears = new System.Windows.Forms.CheckBox();
            this.ch_Mites_Ears = new System.Windows.Forms.CheckBox();
            this.txt_Other_Ears = new System.Windows.Forms.TextBox();
            this.cobo_Inflamed_Ears = new System.Windows.Forms.ComboBox();
            this.cobo_Yeast_Inf_Ears = new System.Windows.Forms.ComboBox();
            this.cobo_Bacterial_Ears = new System.Windows.Forms.ComboBox();
            this.cobo_Itchy_Ears = new System.Windows.Forms.ComboBox();
            this.cobo_Mites_Ears = new System.Windows.Forms.ComboBox();
            this.cobo_Excessive_Debris_Hair_Ears = new System.Windows.Forms.ComboBox();
            this.circularButton3 = new Professional_Vets.CircularButton();
            this.circularButton1 = new Professional_Vets.CircularButton();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox1.AutoSize = true;
            this.groupBox1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.groupBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.groupBox1.Controls.Add(this.txtWight);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.txtCRT);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.txtRR);
            this.groupBox1.Controls.Add(this.txtRT);
            this.groupBox1.Controls.Add(this.txtHR);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(779, 72);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Vital Signs (at rest)";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // txtWight
            // 
            this.txtWight.Location = new System.Drawing.Point(679, 33);
            this.txtWight.Name = "txtWight";
            this.txtWight.Size = new System.Drawing.Size(70, 20);
            this.txtWight.TabIndex = 10;
            this.txtWight.TextChanged += new System.EventHandler(this.textBox5_TextChanged);
            this.txtWight.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtWight_KeyPress);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(752, 36);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(21, 13);
            this.label7.TabIndex = 6;
            this.label7.Text = "Kg";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(633, 36);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(40, 13);
            this.label6.TabIndex = 5;
            this.label6.Text = "Wight";
            // 
            // txtCRT
            // 
            this.txtCRT.Location = new System.Drawing.Point(515, 33);
            this.txtCRT.Name = "txtCRT";
            this.txtCRT.Size = new System.Drawing.Size(70, 20);
            this.txtCRT.TabIndex = 9;
            this.txtCRT.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCRT_KeyPress);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(480, 36);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(29, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "CRT";
            // 
            // txtRR
            // 
            this.txtRR.Location = new System.Drawing.Point(365, 33);
            this.txtRR.Name = "txtRR";
            this.txtRR.Size = new System.Drawing.Size(70, 20);
            this.txtRR.TabIndex = 8;
            this.txtRR.TextChanged += new System.EventHandler(this.textBox3_TextChanged);
            this.txtRR.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtRR_KeyPress);
            // 
            // txtRT
            // 
            this.txtRT.Location = new System.Drawing.Point(34, 33);
            this.txtRT.Name = "txtRT";
            this.txtRT.Size = new System.Drawing.Size(70, 20);
            this.txtRT.TabIndex = 2;
            this.txtRT.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtRT_KeyPress);
            // 
            // txtHR
            // 
            this.txtHR.Location = new System.Drawing.Point(201, 33);
            this.txtHR.Name = "txtHR";
            this.txtHR.Size = new System.Drawing.Size(70, 20);
            this.txtHR.TabIndex = 7;
            this.txtHR.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtHR_KeyPress);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(336, 36);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(23, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "RR";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(172, 36);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(23, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "HR";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(110, 36);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(17, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "̊ C";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 36);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(22, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "RT";
            // 
            // groupBox2
            // 
            this.groupBox2.AutoSize = true;
            this.groupBox2.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.groupBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.groupBox2.Controls.Add(this.tableLayoutPanel1);
            this.groupBox2.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.groupBox2.Location = new System.Drawing.Point(21, 124);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(206, 333);
            this.groupBox2.TabIndex = 2;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Coat And Skin";
            this.groupBox2.Enter += new System.EventHandler(this.groupBox2_Enter);
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.Controls.Add(this.ch_Appear_Normal_CAS, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.ch_Pigment_CAS, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.ch_Itchy_CAS, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.ch_Lesion_CAS, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.ch_Parasites_CAS, 0, 9);
            this.tableLayoutPanel1.Controls.Add(this.ch_Scaly_CAS, 0, 10);
            this.tableLayoutPanel1.Controls.Add(this.ch_Other_CAS, 0, 11);
            this.tableLayoutPanel1.Controls.Add(this.txt_Other_CAS, 1, 11);
            this.tableLayoutPanel1.Controls.Add(this.ch_Dry_Dull_CAS, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.ch_Hair_Loss_CAS, 0, 5);
            this.tableLayoutPanel1.Controls.Add(this.ch_Lumps_CAS, 0, 6);
            this.tableLayoutPanel1.Controls.Add(this.ch_Shedding_CAS, 0, 8);
            this.tableLayoutPanel1.Controls.Add(this.ch_Greasy_CAS, 0, 7);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(6, 24);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 12;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.Size = new System.Drawing.Size(194, 290);
            this.tableLayoutPanel1.TabIndex = 0;
            this.tableLayoutPanel1.Paint += new System.Windows.Forms.PaintEventHandler(this.tableLayoutPanel1_Paint_1);
            // 
            // ch_Appear_Normal_CAS
            // 
            this.ch_Appear_Normal_CAS.AutoSize = true;
            this.ch_Appear_Normal_CAS.Location = new System.Drawing.Point(3, 3);
            this.ch_Appear_Normal_CAS.Name = "ch_Appear_Normal_CAS";
            this.ch_Appear_Normal_CAS.Size = new System.Drawing.Size(110, 17);
            this.ch_Appear_Normal_CAS.TabIndex = 0;
            this.ch_Appear_Normal_CAS.Text = "Appear Normal";
            this.ch_Appear_Normal_CAS.UseVisualStyleBackColor = true;
            // 
            // ch_Pigment_CAS
            // 
            this.ch_Pigment_CAS.AutoSize = true;
            this.ch_Pigment_CAS.Location = new System.Drawing.Point(3, 26);
            this.ch_Pigment_CAS.Name = "ch_Pigment_CAS";
            this.ch_Pigment_CAS.Size = new System.Drawing.Size(73, 17);
            this.ch_Pigment_CAS.TabIndex = 1;
            this.ch_Pigment_CAS.Text = "Pigment";
            this.ch_Pigment_CAS.UseVisualStyleBackColor = true;
            // 
            // ch_Itchy_CAS
            // 
            this.ch_Itchy_CAS.AutoSize = true;
            this.ch_Itchy_CAS.Location = new System.Drawing.Point(3, 49);
            this.ch_Itchy_CAS.Name = "ch_Itchy_CAS";
            this.ch_Itchy_CAS.Size = new System.Drawing.Size(56, 17);
            this.ch_Itchy_CAS.TabIndex = 2;
            this.ch_Itchy_CAS.Text = "Itchy";
            this.ch_Itchy_CAS.UseVisualStyleBackColor = true;
            // 
            // ch_Lesion_CAS
            // 
            this.ch_Lesion_CAS.AutoSize = true;
            this.ch_Lesion_CAS.Location = new System.Drawing.Point(3, 72);
            this.ch_Lesion_CAS.Name = "ch_Lesion_CAS";
            this.ch_Lesion_CAS.Size = new System.Drawing.Size(62, 17);
            this.ch_Lesion_CAS.TabIndex = 3;
            this.ch_Lesion_CAS.Text = "Lesion";
            this.ch_Lesion_CAS.UseVisualStyleBackColor = true;
            // 
            // ch_Parasites_CAS
            // 
            this.ch_Parasites_CAS.AutoSize = true;
            this.ch_Parasites_CAS.Location = new System.Drawing.Point(3, 210);
            this.ch_Parasites_CAS.Name = "ch_Parasites_CAS";
            this.ch_Parasites_CAS.Size = new System.Drawing.Size(79, 17);
            this.ch_Parasites_CAS.TabIndex = 8;
            this.ch_Parasites_CAS.Text = "Parasites";
            this.ch_Parasites_CAS.UseVisualStyleBackColor = true;
            // 
            // ch_Scaly_CAS
            // 
            this.ch_Scaly_CAS.AutoSize = true;
            this.ch_Scaly_CAS.Location = new System.Drawing.Point(3, 233);
            this.ch_Scaly_CAS.Name = "ch_Scaly_CAS";
            this.ch_Scaly_CAS.Size = new System.Drawing.Size(56, 17);
            this.ch_Scaly_CAS.TabIndex = 9;
            this.ch_Scaly_CAS.Text = "Scaly";
            this.ch_Scaly_CAS.UseVisualStyleBackColor = true;
            // 
            // ch_Other_CAS
            // 
            this.ch_Other_CAS.AutoSize = true;
            this.ch_Other_CAS.Location = new System.Drawing.Point(3, 256);
            this.ch_Other_CAS.Name = "ch_Other_CAS";
            this.ch_Other_CAS.Size = new System.Drawing.Size(58, 17);
            this.ch_Other_CAS.TabIndex = 10;
            this.ch_Other_CAS.Text = "Other";
            this.ch_Other_CAS.UseVisualStyleBackColor = true;
            this.ch_Other_CAS.CheckedChanged += new System.EventHandler(this.checkBox12_CheckedChanged);
            // 
            // txt_Other_CAS
            // 
            this.txt_Other_CAS.Location = new System.Drawing.Point(119, 256);
            this.txt_Other_CAS.Name = "txt_Other_CAS";
            this.txt_Other_CAS.Size = new System.Drawing.Size(71, 20);
            this.txt_Other_CAS.TabIndex = 11;
            // 
            // ch_Dry_Dull_CAS
            // 
            this.ch_Dry_Dull_CAS.AutoSize = true;
            this.ch_Dry_Dull_CAS.Location = new System.Drawing.Point(3, 95);
            this.ch_Dry_Dull_CAS.Name = "ch_Dry_Dull_CAS";
            this.ch_Dry_Dull_CAS.Size = new System.Drawing.Size(76, 17);
            this.ch_Dry_Dull_CAS.TabIndex = 4;
            this.ch_Dry_Dull_CAS.Text = "Dry/ Dull";
            this.ch_Dry_Dull_CAS.UseVisualStyleBackColor = true;
            // 
            // ch_Hair_Loss_CAS
            // 
            this.ch_Hair_Loss_CAS.AutoSize = true;
            this.ch_Hair_Loss_CAS.Location = new System.Drawing.Point(3, 118);
            this.ch_Hair_Loss_CAS.Name = "ch_Hair_Loss_CAS";
            this.ch_Hair_Loss_CAS.Size = new System.Drawing.Size(77, 17);
            this.ch_Hair_Loss_CAS.TabIndex = 4;
            this.ch_Hair_Loss_CAS.Text = "Hair Loss";
            this.ch_Hair_Loss_CAS.UseVisualStyleBackColor = true;
            // 
            // ch_Lumps_CAS
            // 
            this.ch_Lumps_CAS.AutoSize = true;
            this.ch_Lumps_CAS.Location = new System.Drawing.Point(3, 141);
            this.ch_Lumps_CAS.Name = "ch_Lumps_CAS";
            this.ch_Lumps_CAS.Size = new System.Drawing.Size(63, 17);
            this.ch_Lumps_CAS.TabIndex = 5;
            this.ch_Lumps_CAS.Text = "Lumps";
            this.ch_Lumps_CAS.UseVisualStyleBackColor = true;
            // 
            // ch_Shedding_CAS
            // 
            this.ch_Shedding_CAS.AutoSize = true;
            this.ch_Shedding_CAS.Location = new System.Drawing.Point(3, 187);
            this.ch_Shedding_CAS.Name = "ch_Shedding_CAS";
            this.ch_Shedding_CAS.Size = new System.Drawing.Size(78, 17);
            this.ch_Shedding_CAS.TabIndex = 7;
            this.ch_Shedding_CAS.Text = "Shedding";
            this.ch_Shedding_CAS.UseVisualStyleBackColor = true;
            // 
            // ch_Greasy_CAS
            // 
            this.ch_Greasy_CAS.AutoSize = true;
            this.ch_Greasy_CAS.Location = new System.Drawing.Point(3, 164);
            this.ch_Greasy_CAS.Name = "ch_Greasy_CAS";
            this.ch_Greasy_CAS.Size = new System.Drawing.Size(66, 17);
            this.ch_Greasy_CAS.TabIndex = 6;
            this.ch_Greasy_CAS.Text = "Greasy";
            this.ch_Greasy_CAS.UseVisualStyleBackColor = true;
            this.ch_Greasy_CAS.CheckedChanged += new System.EventHandler(this.checkBox7_CheckedChanged);
            // 
            // groupBox3
            // 
            this.groupBox3.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.groupBox3.AutoSize = true;
            this.groupBox3.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.groupBox3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.groupBox3.Controls.Add(this.tableLayoutPanel2);
            this.groupBox3.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.groupBox3.Location = new System.Drawing.Point(291, 124);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(206, 333);
            this.groupBox3.TabIndex = 3;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Eyes";
            this.groupBox3.Enter += new System.EventHandler(this.groupBox3_Enter);
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 2;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel2.Controls.Add(this.ch_Normal_Eyes, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.ch_Cataract_Eyes, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.ch_Discharges_Eyes, 0, 2);
            this.tableLayoutPanel2.Controls.Add(this.ch_Inflamed_Eyes, 0, 3);
            this.tableLayoutPanel2.Controls.Add(this.ch_Dry_Eye_Eyes, 0, 4);
            this.tableLayoutPanel2.Controls.Add(this.ch_Infected_Eyes, 0, 6);
            this.tableLayoutPanel2.Controls.Add(this.ch_Other_Eyes, 0, 7);
            this.tableLayoutPanel2.Controls.Add(this.ch_Ulcers_Lesions_Eyes, 0, 5);
            this.tableLayoutPanel2.Controls.Add(this.txt_Other_Eyes, 1, 7);
            this.tableLayoutPanel2.Controls.Add(this.cobo_Cataract_Eyes, 1, 1);
            this.tableLayoutPanel2.Controls.Add(this.cobo_Discharges_Eyes, 1, 2);
            this.tableLayoutPanel2.Controls.Add(this.cobo_Inflamed_Eyes, 1, 3);
            this.tableLayoutPanel2.Controls.Add(this.cobo_Dry_Eye_Eyes, 1, 4);
            this.tableLayoutPanel2.Controls.Add(this.cobo_Ulcers_Lesions_Eyes, 1, 5);
            this.tableLayoutPanel2.Controls.Add(this.cobo_Infected_Eyes, 1, 6);
            this.tableLayoutPanel2.Location = new System.Drawing.Point(6, 24);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 8;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel2.Size = new System.Drawing.Size(194, 290);
            this.tableLayoutPanel2.TabIndex = 1;
            // 
            // ch_Normal_Eyes
            // 
            this.ch_Normal_Eyes.AutoSize = true;
            this.ch_Normal_Eyes.Location = new System.Drawing.Point(3, 3);
            this.ch_Normal_Eyes.Name = "ch_Normal_Eyes";
            this.ch_Normal_Eyes.Size = new System.Drawing.Size(66, 17);
            this.ch_Normal_Eyes.TabIndex = 0;
            this.ch_Normal_Eyes.Text = "Normal";
            this.ch_Normal_Eyes.UseVisualStyleBackColor = true;
            // 
            // ch_Cataract_Eyes
            // 
            this.ch_Cataract_Eyes.AutoSize = true;
            this.ch_Cataract_Eyes.Location = new System.Drawing.Point(3, 26);
            this.ch_Cataract_Eyes.Name = "ch_Cataract_Eyes";
            this.ch_Cataract_Eyes.Size = new System.Drawing.Size(75, 17);
            this.ch_Cataract_Eyes.TabIndex = 1;
            this.ch_Cataract_Eyes.Text = "Cataract";
            this.ch_Cataract_Eyes.UseVisualStyleBackColor = true;
            this.ch_Cataract_Eyes.CheckedChanged += new System.EventHandler(this.checkBox15_CheckedChanged);
            // 
            // ch_Discharges_Eyes
            // 
            this.ch_Discharges_Eyes.AutoSize = true;
            this.ch_Discharges_Eyes.Location = new System.Drawing.Point(3, 53);
            this.ch_Discharges_Eyes.Name = "ch_Discharges_Eyes";
            this.ch_Discharges_Eyes.Size = new System.Drawing.Size(88, 17);
            this.ch_Discharges_Eyes.TabIndex = 2;
            this.ch_Discharges_Eyes.Text = "Discharges";
            this.ch_Discharges_Eyes.UseVisualStyleBackColor = true;
            this.ch_Discharges_Eyes.CheckedChanged += new System.EventHandler(this.checkBox16_CheckedChanged);
            // 
            // ch_Inflamed_Eyes
            // 
            this.ch_Inflamed_Eyes.AutoSize = true;
            this.ch_Inflamed_Eyes.Location = new System.Drawing.Point(3, 80);
            this.ch_Inflamed_Eyes.Name = "ch_Inflamed_Eyes";
            this.ch_Inflamed_Eyes.Size = new System.Drawing.Size(77, 17);
            this.ch_Inflamed_Eyes.TabIndex = 3;
            this.ch_Inflamed_Eyes.Text = "Inflamed";
            this.ch_Inflamed_Eyes.UseVisualStyleBackColor = true;
            this.ch_Inflamed_Eyes.CheckedChanged += new System.EventHandler(this.checkBox17_CheckedChanged);
            // 
            // ch_Dry_Eye_Eyes
            // 
            this.ch_Dry_Eye_Eyes.AutoSize = true;
            this.ch_Dry_Eye_Eyes.Location = new System.Drawing.Point(3, 107);
            this.ch_Dry_Eye_Eyes.Name = "ch_Dry_Eye_Eyes";
            this.ch_Dry_Eye_Eyes.Size = new System.Drawing.Size(69, 17);
            this.ch_Dry_Eye_Eyes.TabIndex = 4;
            this.ch_Dry_Eye_Eyes.Text = "Dry Eye";
            this.ch_Dry_Eye_Eyes.UseVisualStyleBackColor = true;
            this.ch_Dry_Eye_Eyes.CheckedChanged += new System.EventHandler(this.checkBox18_CheckedChanged);
            // 
            // ch_Infected_Eyes
            // 
            this.ch_Infected_Eyes.AutoSize = true;
            this.ch_Infected_Eyes.Location = new System.Drawing.Point(3, 161);
            this.ch_Infected_Eyes.Name = "ch_Infected_Eyes";
            this.ch_Infected_Eyes.Size = new System.Drawing.Size(74, 17);
            this.ch_Infected_Eyes.TabIndex = 6;
            this.ch_Infected_Eyes.Text = "Infected";
            this.ch_Infected_Eyes.UseVisualStyleBackColor = true;
            this.ch_Infected_Eyes.CheckedChanged += new System.EventHandler(this.checkBox19_CheckedChanged);
            // 
            // ch_Other_Eyes
            // 
            this.ch_Other_Eyes.AutoSize = true;
            this.ch_Other_Eyes.Location = new System.Drawing.Point(3, 188);
            this.ch_Other_Eyes.Name = "ch_Other_Eyes";
            this.ch_Other_Eyes.Size = new System.Drawing.Size(58, 17);
            this.ch_Other_Eyes.TabIndex = 10;
            this.ch_Other_Eyes.Text = "Other";
            this.ch_Other_Eyes.UseVisualStyleBackColor = true;
            this.ch_Other_Eyes.CheckedChanged += new System.EventHandler(this.checkBox23_CheckedChanged);
            // 
            // ch_Ulcers_Lesions_Eyes
            // 
            this.ch_Ulcers_Lesions_Eyes.AutoSize = true;
            this.ch_Ulcers_Lesions_Eyes.Location = new System.Drawing.Point(3, 134);
            this.ch_Ulcers_Lesions_Eyes.Name = "ch_Ulcers_Lesions_Eyes";
            this.ch_Ulcers_Lesions_Eyes.Size = new System.Drawing.Size(109, 17);
            this.ch_Ulcers_Lesions_Eyes.TabIndex = 5;
            this.ch_Ulcers_Lesions_Eyes.Text = "Ulcers/Lesions";
            this.ch_Ulcers_Lesions_Eyes.UseVisualStyleBackColor = true;
            this.ch_Ulcers_Lesions_Eyes.CheckedChanged += new System.EventHandler(this.checkBox24_CheckedChanged);
            // 
            // txt_Other_Eyes
            // 
            this.txt_Other_Eyes.Location = new System.Drawing.Point(118, 188);
            this.txt_Other_Eyes.Name = "txt_Other_Eyes";
            this.txt_Other_Eyes.Size = new System.Drawing.Size(71, 20);
            this.txt_Other_Eyes.TabIndex = 11;
            // 
            // cobo_Cataract_Eyes
            // 
            this.cobo_Cataract_Eyes.FormattingEnabled = true;
            this.cobo_Cataract_Eyes.Items.AddRange(new object[] {
            "L",
            "R",
            "Both"});
            this.cobo_Cataract_Eyes.Location = new System.Drawing.Point(118, 26);
            this.cobo_Cataract_Eyes.Name = "cobo_Cataract_Eyes";
            this.cobo_Cataract_Eyes.Size = new System.Drawing.Size(71, 21);
            this.cobo_Cataract_Eyes.TabIndex = 12;
            // 
            // cobo_Discharges_Eyes
            // 
            this.cobo_Discharges_Eyes.FormattingEnabled = true;
            this.cobo_Discharges_Eyes.Items.AddRange(new object[] {
            "L",
            "R",
            "Both"});
            this.cobo_Discharges_Eyes.Location = new System.Drawing.Point(118, 53);
            this.cobo_Discharges_Eyes.Name = "cobo_Discharges_Eyes";
            this.cobo_Discharges_Eyes.Size = new System.Drawing.Size(71, 21);
            this.cobo_Discharges_Eyes.TabIndex = 13;
            // 
            // cobo_Inflamed_Eyes
            // 
            this.cobo_Inflamed_Eyes.FormattingEnabled = true;
            this.cobo_Inflamed_Eyes.Items.AddRange(new object[] {
            "L",
            "R",
            "Both"});
            this.cobo_Inflamed_Eyes.Location = new System.Drawing.Point(118, 80);
            this.cobo_Inflamed_Eyes.Name = "cobo_Inflamed_Eyes";
            this.cobo_Inflamed_Eyes.Size = new System.Drawing.Size(71, 21);
            this.cobo_Inflamed_Eyes.TabIndex = 14;
            // 
            // cobo_Dry_Eye_Eyes
            // 
            this.cobo_Dry_Eye_Eyes.FormattingEnabled = true;
            this.cobo_Dry_Eye_Eyes.Items.AddRange(new object[] {
            "L",
            "R",
            "Both"});
            this.cobo_Dry_Eye_Eyes.Location = new System.Drawing.Point(118, 107);
            this.cobo_Dry_Eye_Eyes.Name = "cobo_Dry_Eye_Eyes";
            this.cobo_Dry_Eye_Eyes.Size = new System.Drawing.Size(71, 21);
            this.cobo_Dry_Eye_Eyes.TabIndex = 15;
            // 
            // cobo_Ulcers_Lesions_Eyes
            // 
            this.cobo_Ulcers_Lesions_Eyes.FormattingEnabled = true;
            this.cobo_Ulcers_Lesions_Eyes.Items.AddRange(new object[] {
            "L",
            "R",
            "Both"});
            this.cobo_Ulcers_Lesions_Eyes.Location = new System.Drawing.Point(118, 134);
            this.cobo_Ulcers_Lesions_Eyes.Name = "cobo_Ulcers_Lesions_Eyes";
            this.cobo_Ulcers_Lesions_Eyes.Size = new System.Drawing.Size(71, 21);
            this.cobo_Ulcers_Lesions_Eyes.TabIndex = 16;
            // 
            // cobo_Infected_Eyes
            // 
            this.cobo_Infected_Eyes.FormattingEnabled = true;
            this.cobo_Infected_Eyes.Items.AddRange(new object[] {
            "L",
            "R",
            "Both"});
            this.cobo_Infected_Eyes.Location = new System.Drawing.Point(118, 161);
            this.cobo_Infected_Eyes.Name = "cobo_Infected_Eyes";
            this.cobo_Infected_Eyes.Size = new System.Drawing.Size(71, 21);
            this.cobo_Infected_Eyes.TabIndex = 17;
            // 
            // groupBox4
            // 
            this.groupBox4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox4.AutoSize = true;
            this.groupBox4.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.groupBox4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.groupBox4.Controls.Add(this.tableLayoutPanel3);
            this.groupBox4.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.groupBox4.Location = new System.Drawing.Point(552, 124);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(239, 333);
            this.groupBox4.TabIndex = 4;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Ears";
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 2;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel3.Controls.Add(this.ch_Normal_Ears, 0, 0);
            this.tableLayoutPanel3.Controls.Add(this.ch_Inflamed_Ears, 0, 1);
            this.tableLayoutPanel3.Controls.Add(this.ch_Yeast_Inf_Ears, 0, 2);
            this.tableLayoutPanel3.Controls.Add(this.ch_Bacterial_Ears, 0, 3);
            this.tableLayoutPanel3.Controls.Add(this.ch_Itchy_Ears, 0, 4);
            this.tableLayoutPanel3.Controls.Add(this.ch_Excessive_Debris_Hair_Ears, 0, 6);
            this.tableLayoutPanel3.Controls.Add(this.ch_Other_Ears, 0, 7);
            this.tableLayoutPanel3.Controls.Add(this.ch_Mites_Ears, 0, 5);
            this.tableLayoutPanel3.Controls.Add(this.txt_Other_Ears, 1, 7);
            this.tableLayoutPanel3.Controls.Add(this.cobo_Inflamed_Ears, 1, 1);
            this.tableLayoutPanel3.Controls.Add(this.cobo_Yeast_Inf_Ears, 1, 2);
            this.tableLayoutPanel3.Controls.Add(this.cobo_Bacterial_Ears, 1, 3);
            this.tableLayoutPanel3.Controls.Add(this.cobo_Itchy_Ears, 1, 4);
            this.tableLayoutPanel3.Controls.Add(this.cobo_Mites_Ears, 1, 5);
            this.tableLayoutPanel3.Controls.Add(this.cobo_Excessive_Debris_Hair_Ears, 1, 6);
            this.tableLayoutPanel3.Location = new System.Drawing.Point(6, 24);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 8;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel3.Size = new System.Drawing.Size(227, 290);
            this.tableLayoutPanel3.TabIndex = 1;
            // 
            // ch_Normal_Ears
            // 
            this.ch_Normal_Ears.AutoSize = true;
            this.ch_Normal_Ears.Location = new System.Drawing.Point(3, 3);
            this.ch_Normal_Ears.Name = "ch_Normal_Ears";
            this.ch_Normal_Ears.Size = new System.Drawing.Size(66, 17);
            this.ch_Normal_Ears.TabIndex = 0;
            this.ch_Normal_Ears.Text = "Normal";
            this.ch_Normal_Ears.UseVisualStyleBackColor = true;
            // 
            // ch_Inflamed_Ears
            // 
            this.ch_Inflamed_Ears.AutoSize = true;
            this.ch_Inflamed_Ears.Location = new System.Drawing.Point(3, 26);
            this.ch_Inflamed_Ears.Name = "ch_Inflamed_Ears";
            this.ch_Inflamed_Ears.Size = new System.Drawing.Size(77, 17);
            this.ch_Inflamed_Ears.TabIndex = 1;
            this.ch_Inflamed_Ears.Text = "Inflamed";
            this.ch_Inflamed_Ears.UseVisualStyleBackColor = true;
            this.ch_Inflamed_Ears.CheckedChanged += new System.EventHandler(this.checkBox20_CheckedChanged);
            // 
            // ch_Yeast_Inf_Ears
            // 
            this.ch_Yeast_Inf_Ears.AutoSize = true;
            this.ch_Yeast_Inf_Ears.Location = new System.Drawing.Point(3, 53);
            this.ch_Yeast_Inf_Ears.Name = "ch_Yeast_Inf_Ears";
            this.ch_Yeast_Inf_Ears.Size = new System.Drawing.Size(80, 17);
            this.ch_Yeast_Inf_Ears.TabIndex = 2;
            this.ch_Yeast_Inf_Ears.Text = "Yeast Inf.";
            this.ch_Yeast_Inf_Ears.UseVisualStyleBackColor = true;
            this.ch_Yeast_Inf_Ears.CheckedChanged += new System.EventHandler(this.checkBox21_CheckedChanged);
            // 
            // ch_Bacterial_Ears
            // 
            this.ch_Bacterial_Ears.AutoSize = true;
            this.ch_Bacterial_Ears.Location = new System.Drawing.Point(3, 80);
            this.ch_Bacterial_Ears.Name = "ch_Bacterial_Ears";
            this.ch_Bacterial_Ears.Size = new System.Drawing.Size(76, 17);
            this.ch_Bacterial_Ears.TabIndex = 3;
            this.ch_Bacterial_Ears.Text = "Bacterial";
            this.ch_Bacterial_Ears.UseVisualStyleBackColor = true;
            this.ch_Bacterial_Ears.CheckedChanged += new System.EventHandler(this.checkBox22_CheckedChanged);
            // 
            // ch_Itchy_Ears
            // 
            this.ch_Itchy_Ears.AutoSize = true;
            this.ch_Itchy_Ears.Location = new System.Drawing.Point(3, 107);
            this.ch_Itchy_Ears.Name = "ch_Itchy_Ears";
            this.ch_Itchy_Ears.Size = new System.Drawing.Size(56, 17);
            this.ch_Itchy_Ears.TabIndex = 4;
            this.ch_Itchy_Ears.Text = "Itchy";
            this.ch_Itchy_Ears.UseVisualStyleBackColor = true;
            this.ch_Itchy_Ears.CheckedChanged += new System.EventHandler(this.checkBox25_CheckedChanged);
            // 
            // ch_Excessive_Debris_Hair_Ears
            // 
            this.ch_Excessive_Debris_Hair_Ears.AutoSize = true;
            this.ch_Excessive_Debris_Hair_Ears.Dock = System.Windows.Forms.DockStyle.Top;
            this.ch_Excessive_Debris_Hair_Ears.Location = new System.Drawing.Point(3, 161);
            this.ch_Excessive_Debris_Hair_Ears.Name = "ch_Excessive_Debris_Hair_Ears";
            this.ch_Excessive_Debris_Hair_Ears.Size = new System.Drawing.Size(145, 19);
            this.ch_Excessive_Debris_Hair_Ears.TabIndex = 6;
            this.ch_Excessive_Debris_Hair_Ears.Text = "Excessive Debris, Hair";
            this.ch_Excessive_Debris_Hair_Ears.ThreeState = true;
            this.ch_Excessive_Debris_Hair_Ears.UseCompatibleTextRendering = true;
            this.ch_Excessive_Debris_Hair_Ears.UseVisualStyleBackColor = true;
            this.ch_Excessive_Debris_Hair_Ears.CheckedChanged += new System.EventHandler(this.checkBox26_CheckedChanged);
            // 
            // ch_Other_Ears
            // 
            this.ch_Other_Ears.AutoSize = true;
            this.ch_Other_Ears.Location = new System.Drawing.Point(3, 188);
            this.ch_Other_Ears.Name = "ch_Other_Ears";
            this.ch_Other_Ears.Size = new System.Drawing.Size(58, 17);
            this.ch_Other_Ears.TabIndex = 10;
            this.ch_Other_Ears.Text = "Other";
            this.ch_Other_Ears.UseVisualStyleBackColor = true;
            this.ch_Other_Ears.CheckedChanged += new System.EventHandler(this.checkBox27_CheckedChanged);
            // 
            // ch_Mites_Ears
            // 
            this.ch_Mites_Ears.AutoSize = true;
            this.ch_Mites_Ears.Location = new System.Drawing.Point(3, 134);
            this.ch_Mites_Ears.Name = "ch_Mites_Ears";
            this.ch_Mites_Ears.Size = new System.Drawing.Size(57, 17);
            this.ch_Mites_Ears.TabIndex = 5;
            this.ch_Mites_Ears.Text = "Mites";
            this.ch_Mites_Ears.UseVisualStyleBackColor = true;
            this.ch_Mites_Ears.CheckedChanged += new System.EventHandler(this.checkBox28_CheckedChanged);
            // 
            // txt_Other_Ears
            // 
            this.txt_Other_Ears.Location = new System.Drawing.Point(154, 188);
            this.txt_Other_Ears.Name = "txt_Other_Ears";
            this.txt_Other_Ears.Size = new System.Drawing.Size(71, 20);
            this.txt_Other_Ears.TabIndex = 11;
            // 
            // cobo_Inflamed_Ears
            // 
            this.cobo_Inflamed_Ears.FormattingEnabled = true;
            this.cobo_Inflamed_Ears.Items.AddRange(new object[] {
            "L",
            "R",
            "Both"});
            this.cobo_Inflamed_Ears.Location = new System.Drawing.Point(154, 26);
            this.cobo_Inflamed_Ears.Name = "cobo_Inflamed_Ears";
            this.cobo_Inflamed_Ears.Size = new System.Drawing.Size(71, 21);
            this.cobo_Inflamed_Ears.TabIndex = 12;
            // 
            // cobo_Yeast_Inf_Ears
            // 
            this.cobo_Yeast_Inf_Ears.FormattingEnabled = true;
            this.cobo_Yeast_Inf_Ears.Items.AddRange(new object[] {
            "L",
            "R",
            "Both"});
            this.cobo_Yeast_Inf_Ears.Location = new System.Drawing.Point(154, 53);
            this.cobo_Yeast_Inf_Ears.Name = "cobo_Yeast_Inf_Ears";
            this.cobo_Yeast_Inf_Ears.Size = new System.Drawing.Size(71, 21);
            this.cobo_Yeast_Inf_Ears.TabIndex = 13;
            // 
            // cobo_Bacterial_Ears
            // 
            this.cobo_Bacterial_Ears.FormattingEnabled = true;
            this.cobo_Bacterial_Ears.Items.AddRange(new object[] {
            "L",
            "R",
            "Both"});
            this.cobo_Bacterial_Ears.Location = new System.Drawing.Point(154, 80);
            this.cobo_Bacterial_Ears.Name = "cobo_Bacterial_Ears";
            this.cobo_Bacterial_Ears.Size = new System.Drawing.Size(71, 21);
            this.cobo_Bacterial_Ears.TabIndex = 14;
            // 
            // cobo_Itchy_Ears
            // 
            this.cobo_Itchy_Ears.FormattingEnabled = true;
            this.cobo_Itchy_Ears.Items.AddRange(new object[] {
            "L",
            "R",
            "Both"});
            this.cobo_Itchy_Ears.Location = new System.Drawing.Point(154, 107);
            this.cobo_Itchy_Ears.Name = "cobo_Itchy_Ears";
            this.cobo_Itchy_Ears.Size = new System.Drawing.Size(71, 21);
            this.cobo_Itchy_Ears.TabIndex = 15;
            // 
            // cobo_Mites_Ears
            // 
            this.cobo_Mites_Ears.FormattingEnabled = true;
            this.cobo_Mites_Ears.Items.AddRange(new object[] {
            "L",
            "R",
            "Both"});
            this.cobo_Mites_Ears.Location = new System.Drawing.Point(154, 134);
            this.cobo_Mites_Ears.Name = "cobo_Mites_Ears";
            this.cobo_Mites_Ears.Size = new System.Drawing.Size(71, 21);
            this.cobo_Mites_Ears.TabIndex = 16;
            // 
            // cobo_Excessive_Debris_Hair_Ears
            // 
            this.cobo_Excessive_Debris_Hair_Ears.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cobo_Excessive_Debris_Hair_Ears.FormattingEnabled = true;
            this.cobo_Excessive_Debris_Hair_Ears.Items.AddRange(new object[] {
            "L",
            "R",
            "Both"});
            this.cobo_Excessive_Debris_Hair_Ears.Location = new System.Drawing.Point(154, 161);
            this.cobo_Excessive_Debris_Hair_Ears.Name = "cobo_Excessive_Debris_Hair_Ears";
            this.cobo_Excessive_Debris_Hair_Ears.Size = new System.Drawing.Size(71, 21);
            this.cobo_Excessive_Debris_Hair_Ears.TabIndex = 17;
            this.cobo_Excessive_Debris_Hair_Ears.SelectedIndexChanged += new System.EventHandler(this.comboBox12_SelectedIndexChanged);
            // 
            // circularButton3
            // 
            this.circularButton3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.circularButton3.AutoSize = true;
            this.circularButton3.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.circularButton3.FlatAppearance.BorderSize = 0;
            this.circularButton3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.circularButton3.Image = ((System.Drawing.Image)(resources.GetObject("circularButton3.Image")));
            this.circularButton3.Location = new System.Drawing.Point(735, 448);
            this.circularButton3.Name = "circularButton3";
            this.circularButton3.Size = new System.Drawing.Size(56, 56);
            this.circularButton3.TabIndex = 33;
            this.circularButton3.UseVisualStyleBackColor = true;
            this.circularButton3.Click += new System.EventHandler(this.circularButton3_Click);
            // 
            // circularButton1
            // 
            this.circularButton1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.circularButton1.AutoSize = true;
            this.circularButton1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.circularButton1.FlatAppearance.BorderSize = 0;
            this.circularButton1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.circularButton1.Image = ((System.Drawing.Image)(resources.GetObject("circularButton1.Image")));
            this.circularButton1.Location = new System.Drawing.Point(679, 448);
            this.circularButton1.Name = "circularButton1";
            this.circularButton1.Size = new System.Drawing.Size(56, 56);
            this.circularButton1.TabIndex = 31;
            this.circularButton1.UseVisualStyleBackColor = true;
            this.circularButton1.Click += new System.EventHandler(this.circularButton1_Click);
            // 
            // Physical_Examination
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.ClientSize = new System.Drawing.Size(814, 516);
            this.Controls.Add(this.circularButton3);
            this.Controls.Add(this.circularButton1);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.DoubleBuffered = true;
            this.Name = "Physical_Examination";
            this.Text = "Physical_Examination";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Physical_Examination_FormClosing);
            this.Load += new System.EventHandler(this.Physical_Examination_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtWight;
        private System.Windows.Forms.TextBox txtCRT;
        private System.Windows.Forms.TextBox txtRR;
        private System.Windows.Forms.TextBox txtRT;
        private System.Windows.Forms.TextBox txtHR;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.CheckBox ch_Appear_Normal_CAS;
        private System.Windows.Forms.CheckBox ch_Pigment_CAS;
        private System.Windows.Forms.CheckBox ch_Itchy_CAS;
        private System.Windows.Forms.CheckBox ch_Lesion_CAS;
        private System.Windows.Forms.CheckBox ch_Hair_Loss_CAS;
        private System.Windows.Forms.CheckBox ch_Greasy_CAS;
        private System.Windows.Forms.CheckBox ch_Shedding_CAS;
        private System.Windows.Forms.CheckBox ch_Lumps_CAS;
        private System.Windows.Forms.CheckBox ch_Dry_Dull_CAS;
        private System.Windows.Forms.CheckBox ch_Parasites_CAS;
        private System.Windows.Forms.CheckBox ch_Scaly_CAS;
        private System.Windows.Forms.CheckBox ch_Other_CAS;
        private System.Windows.Forms.TextBox txt_Other_CAS;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.CheckBox ch_Cataract_Eyes;
        private System.Windows.Forms.CheckBox ch_Discharges_Eyes;
        private System.Windows.Forms.CheckBox ch_Inflamed_Eyes;
        private System.Windows.Forms.CheckBox ch_Dry_Eye_Eyes;
        private System.Windows.Forms.CheckBox ch_Infected_Eyes;
        private System.Windows.Forms.CheckBox ch_Other_Eyes;
        private System.Windows.Forms.CheckBox ch_Ulcers_Lesions_Eyes;
        private System.Windows.Forms.TextBox txt_Other_Eyes;
        private System.Windows.Forms.CheckBox ch_Normal_Eyes;
        private System.Windows.Forms.ComboBox cobo_Cataract_Eyes;
        private System.Windows.Forms.ComboBox cobo_Discharges_Eyes;
        private System.Windows.Forms.ComboBox cobo_Inflamed_Eyes;
        private System.Windows.Forms.ComboBox cobo_Dry_Eye_Eyes;
        private System.Windows.Forms.ComboBox cobo_Ulcers_Lesions_Eyes;
        private System.Windows.Forms.ComboBox cobo_Infected_Eyes;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.CheckBox ch_Normal_Ears;
        private System.Windows.Forms.CheckBox ch_Inflamed_Ears;
        private System.Windows.Forms.CheckBox ch_Yeast_Inf_Ears;
        private System.Windows.Forms.CheckBox ch_Bacterial_Ears;
        private System.Windows.Forms.CheckBox ch_Itchy_Ears;
        private System.Windows.Forms.CheckBox ch_Excessive_Debris_Hair_Ears;
        private System.Windows.Forms.CheckBox ch_Other_Ears;
        private System.Windows.Forms.CheckBox ch_Mites_Ears;
        private System.Windows.Forms.TextBox txt_Other_Ears;
        private System.Windows.Forms.ComboBox cobo_Inflamed_Ears;
        private System.Windows.Forms.ComboBox cobo_Yeast_Inf_Ears;
        private System.Windows.Forms.ComboBox cobo_Bacterial_Ears;
        private System.Windows.Forms.ComboBox cobo_Itchy_Ears;
        private System.Windows.Forms.ComboBox cobo_Mites_Ears;
        private System.Windows.Forms.ComboBox cobo_Excessive_Debris_Hair_Ears;
        private CircularButton circularButton3;
        private CircularButton circularButton1;
    }
}