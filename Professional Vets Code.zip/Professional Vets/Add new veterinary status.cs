﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Professional_Vets
{
    public partial class Add_new_veterinary_status : Form
    {
        String vn, ow, mb, pt;
        
        SqlCommand cmd;
        SqlConnection con;

        public Add_new_veterinary_status(String role)
        {
            InitializeComponent();
            vn = role;
            LB_Username.Text = vn;

        }

        private void Add_new_veterinary_status_Load(object sender, EventArgs e)
        {

        }

        private void monthCalendar1_DateChanged(object sender, DateRangeEventArgs e)
        {

        }

        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void label11_Click_1(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void numericUpDown2_ValueChanged(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void circularButton1_Click(object sender, EventArgs e)
        {
            this.Hide();
            HomePage HP = new HomePage(vn);
            HP.ShowDialog();
        }

        private void circularButton3_Click(object sender, EventArgs e)
        {
            //Add to DB
            con = new SqlConnection(Properties.Settings.Default.Database1ConnectionString);
            con.Open();
            cmd = new SqlCommand("Insert INTO Add_Veterinary (Owner, Mobile, Pet, Species, Sex, Age_Years, Age_Months, Breed, Color, Date, Vet_Name) VALUES (@Owner,@Mobile, @Pet, @Species, @Sex, @Age_Years, @Age_Months, @Breed, @Color, @Date, @Vet_Name )", con);

            cmd.Parameters.AddWithValue("@Owner", txtOwner.Text);
            cmd.Parameters.AddWithValue("@Mobile", txtMobile.Text);
            cmd.Parameters.AddWithValue("@Pet", txtPet.Text);
            
            // Species
            if (coboSpecies.SelectedItem != null)
            {
                cmd.Parameters.AddWithValue("@Species", coboSpecies.SelectedItem.ToString());
            } 
            else
            { cmd.Parameters.AddWithValue("@Species", "null"); }

            // Sex
            if (coboSex.SelectedItem != null)
            {
                cmd.Parameters.AddWithValue("@Sex", coboSex.SelectedItem.ToString());
            }
            else
            { cmd.Parameters.AddWithValue("@Sex", "null");}

            cmd.Parameters.AddWithValue("@Age_Years", nudAgeYear.Value);
            cmd.Parameters.AddWithValue("@Age_Months", nudAgeMonth.Value);
            cmd.Parameters.AddWithValue("@Breed", txtColor.Text);
            cmd.Parameters.AddWithValue("@Color", txtBreed.Text);
            cmd.Parameters.AddWithValue("@Date", ANVdatePicker.Value.ToShortDateString());
            cmd.Parameters.AddWithValue("@Vet_Name", LB_Username.Text);

            cmd.ExecuteNonQuery();
            con.Close();

            // Open the Next Form

            DateTime dat = ANVdatePicker.Value;

            ow = txtOwner.Text;
            mb = txtMobile.Text;
            pt = txtPet.Text;

            this.Hide();
            Physical_Examination PhE = new Physical_Examination(vn, ow, mb, pt, dat);
            PhE.ShowDialog();
            
        }
        
        private void circularButton2_Click(object sender, EventArgs e)
        {
            this.Hide();
            HomePage HP = new HomePage(vn);
            HP.ShowDialog();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Add_new_veterinary_status_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.Hide();
            HomePage HP = new HomePage(vn);
            HP.ShowDialog();
        }

        private void txtTel_KeyPress(object sender, KeyPressEventArgs e)
        {
            //For enter number only

            if ((e.KeyChar >= 48 && e.KeyChar <= 57) || e.KeyChar == 8)
            {


                e.Handled = false;

            }
            else
            {
                MessageBox.Show("Please Enter only Number.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                e.Handled = true;

            }
        }

        private void nudAgeYear_KeyPress(object sender, KeyPressEventArgs e)
        {
            //For enter number only

            if ((e.KeyChar >= 48 && e.KeyChar <= 57) || e.KeyChar == 8)
            {


                e.Handled = false;

            }
            else
            {
                MessageBox.Show("Please Enter only Number.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                e.Handled = true;

            }
        }

        private void nudAgeMonth_KeyPress(object sender, KeyPressEventArgs e)
        {
            //For enter number only

            if ((e.KeyChar >= 48 && e.KeyChar <= 57) || e.KeyChar == 8)
            {


                e.Handled = false;

            }
            else
            {
                MessageBox.Show("Please Enter only Number.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                e.Handled = true;

            }
        }
    }
}
