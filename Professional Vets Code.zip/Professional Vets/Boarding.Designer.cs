﻿namespace Professional_Vets
{
    partial class Boarding
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Boarding));
            this.But_Boarding_info = new System.Windows.Forms.Button();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.Email = new System.Windows.Forms.Button();
            this.txt_Mobile = new System.Windows.Forms.TextBox();
            this.label_Mobile = new System.Windows.Forms.Button();
            this.Address = new System.Windows.Forms.Button();
            this.Owner_Button = new System.Windows.Forms.Button();
            this.txt_Owner = new System.Windows.Forms.TextBox();
            this.rtxt_Address = new System.Windows.Forms.TextBox();
            this.txt_Email = new System.Windows.Forms.RichTextBox();
            this.But_Owner_info = new System.Windows.Forms.Button();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.Breed = new System.Windows.Forms.Button();
            this.txt_Breed = new System.Windows.Forms.TextBox();
            this.Sex = new System.Windows.Forms.Button();
            this.Species = new System.Windows.Forms.Button();
            this.Age = new System.Windows.Forms.Button();
            this.Pet_Name = new System.Windows.Forms.Button();
            this.txt_PetName = new System.Windows.Forms.TextBox();
            this.cobo_Species = new System.Windows.Forms.ComboBox();
            this.txt_Color_Hair = new System.Windows.Forms.TextBox();
            this.Color_Hair = new System.Windows.Forms.Button();
            this.cobo_Sex = new System.Windows.Forms.ComboBox();
            this.txt_Age = new System.Windows.Forms.TextBox();
            this.But_Pet_info = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.ch_NoD_BD = new System.Windows.Forms.CheckBox();
            this.ch_Food_BD = new System.Windows.Forms.CheckBox();
            this.ch_Medications_BD = new System.Windows.Forms.CheckBox();
            this.ch_Other_BD = new System.Windows.Forms.CheckBox();
            this.rtxt_Other_BD = new System.Windows.Forms.RichTextBox();
            this.txt_NoD_BD = new System.Windows.Forms.TextBox();
            this.circularButton3 = new Professional_Vets.CircularButton();
            this.circularButton1 = new Professional_Vets.CircularButton();
            this.tableLayoutPanel1.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // But_Boarding_info
            // 
            this.But_Boarding_info.BackColor = System.Drawing.Color.Blue;
            this.But_Boarding_info.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.But_Boarding_info.ForeColor = System.Drawing.Color.White;
            this.But_Boarding_info.Location = new System.Drawing.Point(535, 12);
            this.But_Boarding_info.Name = "But_Boarding_info";
            this.But_Boarding_info.Size = new System.Drawing.Size(316, 23);
            this.But_Boarding_info.TabIndex = 22;
            this.But_Boarding_info.Text = "Boarding Details";
            this.But_Boarding_info.UseCompatibleTextRendering = true;
            this.But_Boarding_info.UseVisualStyleBackColor = false;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.AutoSize = true;
            this.tableLayoutPanel1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Controls.Add(this.Email, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.txt_Mobile, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.label_Mobile, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.Address, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.Owner_Button, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.txt_Owner, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.rtxt_Address, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.txt_Email, 1, 3);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(14, 301);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 4;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(484, 113);
            this.tableLayoutPanel1.TabIndex = 1;
            // 
            // Email
            // 
            this.Email.BackColor = System.Drawing.SystemColors.Control;
            this.Email.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Email.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.Email.ForeColor = System.Drawing.Color.DarkBlue;
            this.Email.Location = new System.Drawing.Point(2, 83);
            this.Email.Margin = new System.Windows.Forms.Padding(2);
            this.Email.Name = "Email";
            this.Email.Size = new System.Drawing.Size(238, 28);
            this.Email.TabIndex = 20;
            this.Email.Text = "Email";
            this.Email.UseCompatibleTextRendering = true;
            this.Email.UseVisualStyleBackColor = false;
            // 
            // txt_Mobile
            // 
            this.txt_Mobile.Location = new System.Drawing.Point(245, 57);
            this.txt_Mobile.Name = "txt_Mobile";
            this.txt_Mobile.Size = new System.Drawing.Size(236, 20);
            this.txt_Mobile.TabIndex = 19;
            this.txt_Mobile.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_Mobile_KeyPress);
            // 
            // label_Mobile
            // 
            this.label_Mobile.BackColor = System.Drawing.SystemColors.Control;
            this.label_Mobile.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label_Mobile.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.label_Mobile.ForeColor = System.Drawing.Color.DarkBlue;
            this.label_Mobile.Location = new System.Drawing.Point(2, 56);
            this.label_Mobile.Margin = new System.Windows.Forms.Padding(2);
            this.label_Mobile.Name = "label_Mobile";
            this.label_Mobile.Size = new System.Drawing.Size(238, 23);
            this.label_Mobile.TabIndex = 18;
            this.label_Mobile.Text = "Mobile";
            this.label_Mobile.UseCompatibleTextRendering = true;
            this.label_Mobile.UseVisualStyleBackColor = false;
            // 
            // Address
            // 
            this.Address.BackColor = System.Drawing.SystemColors.Control;
            this.Address.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Address.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.Address.ForeColor = System.Drawing.Color.DarkBlue;
            this.Address.Location = new System.Drawing.Point(2, 29);
            this.Address.Margin = new System.Windows.Forms.Padding(2);
            this.Address.Name = "Address";
            this.Address.Size = new System.Drawing.Size(238, 23);
            this.Address.TabIndex = 16;
            this.Address.Text = "Address";
            this.Address.UseCompatibleTextRendering = true;
            this.Address.UseVisualStyleBackColor = false;
            // 
            // Owner_Button
            // 
            this.Owner_Button.BackColor = System.Drawing.SystemColors.Control;
            this.Owner_Button.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Owner_Button.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.Owner_Button.ForeColor = System.Drawing.Color.DarkBlue;
            this.Owner_Button.Location = new System.Drawing.Point(2, 2);
            this.Owner_Button.Margin = new System.Windows.Forms.Padding(2);
            this.Owner_Button.Name = "Owner_Button";
            this.Owner_Button.Size = new System.Drawing.Size(238, 23);
            this.Owner_Button.TabIndex = 14;
            this.Owner_Button.Text = "Owner Name";
            this.Owner_Button.UseCompatibleTextRendering = true;
            this.Owner_Button.UseVisualStyleBackColor = false;
            // 
            // txt_Owner
            // 
            this.txt_Owner.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.txt_Owner.Location = new System.Drawing.Point(245, 3);
            this.txt_Owner.Name = "txt_Owner";
            this.txt_Owner.Size = new System.Drawing.Size(236, 20);
            this.txt_Owner.TabIndex = 15;
            // 
            // rtxt_Address
            // 
            this.rtxt_Address.Location = new System.Drawing.Point(245, 30);
            this.rtxt_Address.Name = "rtxt_Address";
            this.rtxt_Address.Size = new System.Drawing.Size(236, 20);
            this.rtxt_Address.TabIndex = 17;
            // 
            // txt_Email
            // 
            this.txt_Email.Location = new System.Drawing.Point(245, 84);
            this.txt_Email.Name = "txt_Email";
            this.txt_Email.Size = new System.Drawing.Size(236, 23);
            this.txt_Email.TabIndex = 21;
            this.txt_Email.Text = "";
            // 
            // But_Owner_info
            // 
            this.But_Owner_info.BackColor = System.Drawing.Color.Blue;
            this.But_Owner_info.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.But_Owner_info.ForeColor = System.Drawing.Color.White;
            this.But_Owner_info.Location = new System.Drawing.Point(14, 272);
            this.But_Owner_info.Name = "But_Owner_info";
            this.But_Owner_info.Size = new System.Drawing.Size(336, 23);
            this.But_Owner_info.TabIndex = 13;
            this.But_Owner_info.Text = "OWNER INFORMATION";
            this.But_Owner_info.UseCompatibleTextRendering = true;
            this.But_Owner_info.UseVisualStyleBackColor = false;
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.AutoSize = true;
            this.tableLayoutPanel3.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.tableLayoutPanel3.ColumnCount = 2;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.Controls.Add(this.Breed, 0, 4);
            this.tableLayoutPanel3.Controls.Add(this.txt_Breed, 1, 4);
            this.tableLayoutPanel3.Controls.Add(this.Sex, 0, 3);
            this.tableLayoutPanel3.Controls.Add(this.Species, 0, 2);
            this.tableLayoutPanel3.Controls.Add(this.Age, 0, 1);
            this.tableLayoutPanel3.Controls.Add(this.Pet_Name, 0, 0);
            this.tableLayoutPanel3.Controls.Add(this.txt_PetName, 1, 0);
            this.tableLayoutPanel3.Controls.Add(this.cobo_Species, 1, 2);
            this.tableLayoutPanel3.Controls.Add(this.txt_Color_Hair, 1, 5);
            this.tableLayoutPanel3.Controls.Add(this.Color_Hair, 0, 5);
            this.tableLayoutPanel3.Controls.Add(this.cobo_Sex, 1, 3);
            this.tableLayoutPanel3.Controls.Add(this.txt_Age, 1, 1);
            this.tableLayoutPanel3.Location = new System.Drawing.Point(12, 41);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 6;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(492, 163);
            this.tableLayoutPanel3.TabIndex = 0;
            // 
            // Breed
            // 
            this.Breed.BackColor = System.Drawing.SystemColors.Control;
            this.Breed.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Breed.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.Breed.ForeColor = System.Drawing.Color.DarkBlue;
            this.Breed.Location = new System.Drawing.Point(2, 110);
            this.Breed.Margin = new System.Windows.Forms.Padding(2);
            this.Breed.Name = "Breed";
            this.Breed.Size = new System.Drawing.Size(242, 23);
            this.Breed.TabIndex = 9;
            this.Breed.Text = "Breed";
            this.Breed.UseCompatibleTextRendering = true;
            this.Breed.UseVisualStyleBackColor = false;
            // 
            // txt_Breed
            // 
            this.txt_Breed.Location = new System.Drawing.Point(249, 111);
            this.txt_Breed.Name = "txt_Breed";
            this.txt_Breed.Size = new System.Drawing.Size(240, 20);
            this.txt_Breed.TabIndex = 10;
            // 
            // Sex
            // 
            this.Sex.BackColor = System.Drawing.SystemColors.Control;
            this.Sex.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Sex.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.Sex.ForeColor = System.Drawing.Color.DarkBlue;
            this.Sex.Location = new System.Drawing.Point(2, 83);
            this.Sex.Margin = new System.Windows.Forms.Padding(2);
            this.Sex.Name = "Sex";
            this.Sex.Size = new System.Drawing.Size(242, 23);
            this.Sex.TabIndex = 7;
            this.Sex.Text = "Sex";
            this.Sex.UseCompatibleTextRendering = true;
            this.Sex.UseVisualStyleBackColor = false;
            // 
            // Species
            // 
            this.Species.BackColor = System.Drawing.SystemColors.Control;
            this.Species.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Species.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.Species.ForeColor = System.Drawing.Color.DarkBlue;
            this.Species.Location = new System.Drawing.Point(2, 56);
            this.Species.Margin = new System.Windows.Forms.Padding(2);
            this.Species.Name = "Species";
            this.Species.Size = new System.Drawing.Size(242, 23);
            this.Species.TabIndex = 5;
            this.Species.Text = "Species";
            this.Species.UseCompatibleTextRendering = true;
            this.Species.UseVisualStyleBackColor = false;
            // 
            // Age
            // 
            this.Age.BackColor = System.Drawing.SystemColors.Control;
            this.Age.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Age.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.Age.ForeColor = System.Drawing.Color.DarkBlue;
            this.Age.Location = new System.Drawing.Point(2, 29);
            this.Age.Margin = new System.Windows.Forms.Padding(2);
            this.Age.Name = "Age";
            this.Age.Size = new System.Drawing.Size(242, 23);
            this.Age.TabIndex = 3;
            this.Age.Text = "Age";
            this.Age.UseCompatibleTextRendering = true;
            this.Age.UseVisualStyleBackColor = false;
            // 
            // Pet_Name
            // 
            this.Pet_Name.BackColor = System.Drawing.SystemColors.Control;
            this.Pet_Name.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Pet_Name.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.Pet_Name.ForeColor = System.Drawing.Color.DarkBlue;
            this.Pet_Name.Location = new System.Drawing.Point(2, 2);
            this.Pet_Name.Margin = new System.Windows.Forms.Padding(2);
            this.Pet_Name.Name = "Pet_Name";
            this.Pet_Name.Size = new System.Drawing.Size(242, 23);
            this.Pet_Name.TabIndex = 1;
            this.Pet_Name.Text = "PET Name";
            this.Pet_Name.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.Pet_Name.UseCompatibleTextRendering = true;
            this.Pet_Name.UseVisualStyleBackColor = false;
            // 
            // txt_PetName
            // 
            this.txt_PetName.Location = new System.Drawing.Point(249, 3);
            this.txt_PetName.Name = "txt_PetName";
            this.txt_PetName.Size = new System.Drawing.Size(240, 20);
            this.txt_PetName.TabIndex = 2;
            // 
            // cobo_Species
            // 
            this.cobo_Species.FormattingEnabled = true;
            this.cobo_Species.Items.AddRange(new object[] {
            "CANINE",
            "FELINE"});
            this.cobo_Species.Location = new System.Drawing.Point(249, 57);
            this.cobo_Species.Name = "cobo_Species";
            this.cobo_Species.Size = new System.Drawing.Size(240, 21);
            this.cobo_Species.TabIndex = 6;
            // 
            // txt_Color_Hair
            // 
            this.txt_Color_Hair.Location = new System.Drawing.Point(249, 138);
            this.txt_Color_Hair.Name = "txt_Color_Hair";
            this.txt_Color_Hair.Size = new System.Drawing.Size(240, 20);
            this.txt_Color_Hair.TabIndex = 12;
            // 
            // Color_Hair
            // 
            this.Color_Hair.BackColor = System.Drawing.SystemColors.Control;
            this.Color_Hair.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Color_Hair.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.Color_Hair.ForeColor = System.Drawing.Color.DarkBlue;
            this.Color_Hair.Location = new System.Drawing.Point(2, 137);
            this.Color_Hair.Margin = new System.Windows.Forms.Padding(2);
            this.Color_Hair.Name = "Color_Hair";
            this.Color_Hair.Size = new System.Drawing.Size(242, 24);
            this.Color_Hair.TabIndex = 11;
            this.Color_Hair.Text = "Color/ hair";
            this.Color_Hair.UseCompatibleTextRendering = true;
            this.Color_Hair.UseVisualStyleBackColor = false;
            // 
            // cobo_Sex
            // 
            this.cobo_Sex.FormattingEnabled = true;
            this.cobo_Sex.Items.AddRange(new object[] {
            "Male",
            "Female"});
            this.cobo_Sex.Location = new System.Drawing.Point(248, 83);
            this.cobo_Sex.Margin = new System.Windows.Forms.Padding(2);
            this.cobo_Sex.Name = "cobo_Sex";
            this.cobo_Sex.Size = new System.Drawing.Size(241, 21);
            this.cobo_Sex.TabIndex = 8;
            // 
            // txt_Age
            // 
            this.txt_Age.Location = new System.Drawing.Point(249, 30);
            this.txt_Age.Name = "txt_Age";
            this.txt_Age.Size = new System.Drawing.Size(240, 20);
            this.txt_Age.TabIndex = 4;
            // 
            // But_Pet_info
            // 
            this.But_Pet_info.BackColor = System.Drawing.Color.Blue;
            this.But_Pet_info.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.But_Pet_info.ForeColor = System.Drawing.Color.White;
            this.But_Pet_info.Location = new System.Drawing.Point(12, 12);
            this.But_Pet_info.Name = "But_Pet_info";
            this.But_Pet_info.Size = new System.Drawing.Size(336, 23);
            this.But_Pet_info.TabIndex = 0;
            this.But_Pet_info.Text = "PET INFORMATION";
            this.But_Pet_info.UseCompatibleTextRendering = true;
            this.But_Pet_info.UseVisualStyleBackColor = false;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.tableLayoutPanel2);
            this.groupBox2.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.groupBox2.Location = new System.Drawing.Point(535, 41);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(372, 264);
            this.groupBox2.TabIndex = 23;
            this.groupBox2.TabStop = false;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 2;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel2.Controls.Add(this.ch_NoD_BD, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.ch_Food_BD, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.ch_Medications_BD, 0, 2);
            this.tableLayoutPanel2.Controls.Add(this.ch_Other_BD, 0, 3);
            this.tableLayoutPanel2.Controls.Add(this.rtxt_Other_BD, 1, 3);
            this.tableLayoutPanel2.Controls.Add(this.txt_NoD_BD, 1, 0);
            this.tableLayoutPanel2.Location = new System.Drawing.Point(6, 13);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 4;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(360, 245);
            this.tableLayoutPanel2.TabIndex = 2;
            // 
            // ch_NoD_BD
            // 
            this.ch_NoD_BD.AutoSize = true;
            this.ch_NoD_BD.Location = new System.Drawing.Point(3, 3);
            this.ch_NoD_BD.Name = "ch_NoD_BD";
            this.ch_NoD_BD.Size = new System.Drawing.Size(168, 17);
            this.ch_NoD_BD.TabIndex = 24;
            this.ch_NoD_BD.Text = "Number of Boarding Days";
            this.ch_NoD_BD.UseVisualStyleBackColor = true;
            this.ch_NoD_BD.CheckedChanged += new System.EventHandler(this.ch_NoD_BD_CheckedChanged);
            // 
            // ch_Food_BD
            // 
            this.ch_Food_BD.AutoSize = true;
            this.ch_Food_BD.Location = new System.Drawing.Point(3, 29);
            this.ch_Food_BD.Name = "ch_Food_BD";
            this.ch_Food_BD.Size = new System.Drawing.Size(53, 17);
            this.ch_Food_BD.TabIndex = 26;
            this.ch_Food_BD.Text = "Food";
            this.ch_Food_BD.UseVisualStyleBackColor = true;
            // 
            // ch_Medications_BD
            // 
            this.ch_Medications_BD.AutoSize = true;
            this.ch_Medications_BD.Location = new System.Drawing.Point(3, 52);
            this.ch_Medications_BD.Name = "ch_Medications_BD";
            this.ch_Medications_BD.Size = new System.Drawing.Size(94, 17);
            this.ch_Medications_BD.TabIndex = 27;
            this.ch_Medications_BD.Text = "Medications";
            this.ch_Medications_BD.UseVisualStyleBackColor = true;
            // 
            // ch_Other_BD
            // 
            this.ch_Other_BD.AutoSize = true;
            this.ch_Other_BD.Location = new System.Drawing.Point(3, 75);
            this.ch_Other_BD.Name = "ch_Other_BD";
            this.ch_Other_BD.Size = new System.Drawing.Size(58, 17);
            this.ch_Other_BD.TabIndex = 28;
            this.ch_Other_BD.Text = "Other";
            this.ch_Other_BD.UseVisualStyleBackColor = true;
            this.ch_Other_BD.CheckedChanged += new System.EventHandler(this.ch_Other_BD_CheckedChanged);
            // 
            // rtxt_Other_BD
            // 
            this.rtxt_Other_BD.Location = new System.Drawing.Point(177, 75);
            this.rtxt_Other_BD.Name = "rtxt_Other_BD";
            this.rtxt_Other_BD.Size = new System.Drawing.Size(180, 166);
            this.rtxt_Other_BD.TabIndex = 29;
            this.rtxt_Other_BD.Text = "";
            this.rtxt_Other_BD.Visible = false;
            // 
            // txt_NoD_BD
            // 
            this.txt_NoD_BD.Location = new System.Drawing.Point(177, 3);
            this.txt_NoD_BD.Name = "txt_NoD_BD";
            this.txt_NoD_BD.Size = new System.Drawing.Size(180, 20);
            this.txt_NoD_BD.TabIndex = 25;
            this.txt_NoD_BD.Visible = false;
            this.txt_NoD_BD.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_NoD_BD_KeyPress);
            // 
            // circularButton3
            // 
            this.circularButton3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.circularButton3.AutoSize = true;
            this.circularButton3.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.circularButton3.FlatAppearance.BorderSize = 0;
            this.circularButton3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.circularButton3.Image = ((System.Drawing.Image)(resources.GetObject("circularButton3.Image")));
            this.circularButton3.Location = new System.Drawing.Point(846, 413);
            this.circularButton3.Name = "circularButton3";
            this.circularButton3.Size = new System.Drawing.Size(61, 61);
            this.circularButton3.TabIndex = 31;
            this.circularButton3.UseVisualStyleBackColor = true;
            this.circularButton3.Click += new System.EventHandler(this.circularButton3_Click);
            // 
            // circularButton1
            // 
            this.circularButton1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.circularButton1.AutoSize = true;
            this.circularButton1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.circularButton1.FlatAppearance.BorderSize = 0;
            this.circularButton1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.circularButton1.Image = ((System.Drawing.Image)(resources.GetObject("circularButton1.Image")));
            this.circularButton1.Location = new System.Drawing.Point(795, 418);
            this.circularButton1.Name = "circularButton1";
            this.circularButton1.Size = new System.Drawing.Size(56, 56);
            this.circularButton1.TabIndex = 30;
            this.circularButton1.UseVisualStyleBackColor = true;
            this.circularButton1.Click += new System.EventHandler(this.circularButton1_Click);
            // 
            // Boarding
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.ClientSize = new System.Drawing.Size(919, 486);
            this.Controls.Add(this.circularButton3);
            this.Controls.Add(this.circularButton1);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.But_Boarding_info);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Controls.Add(this.But_Owner_info);
            this.Controls.Add(this.tableLayoutPanel3);
            this.Controls.Add(this.But_Pet_info);
            this.Name = "Boarding";
            this.Text = "Boarding";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Boarding_FormClosing);
            this.Load += new System.EventHandler(this.Boarding_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button But_Boarding_info;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Button Email;
        private System.Windows.Forms.TextBox txt_Mobile;
        private System.Windows.Forms.Button label_Mobile;
        private System.Windows.Forms.Button Address;
        private System.Windows.Forms.Button Owner_Button;
        private System.Windows.Forms.TextBox txt_Owner;
        private System.Windows.Forms.TextBox rtxt_Address;
        private System.Windows.Forms.RichTextBox txt_Email;
        private System.Windows.Forms.Button But_Owner_info;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.Button Breed;
        private System.Windows.Forms.TextBox txt_Breed;
        private System.Windows.Forms.Button Sex;
        private System.Windows.Forms.Button Species;
        private System.Windows.Forms.Button Age;
        private System.Windows.Forms.Button Pet_Name;
        private System.Windows.Forms.TextBox txt_PetName;
        private System.Windows.Forms.ComboBox cobo_Species;
        private System.Windows.Forms.TextBox txt_Color_Hair;
        private System.Windows.Forms.Button Color_Hair;
        private System.Windows.Forms.ComboBox cobo_Sex;
        private System.Windows.Forms.Button But_Pet_info;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.CheckBox ch_NoD_BD;
        private System.Windows.Forms.CheckBox ch_Food_BD;
        private System.Windows.Forms.CheckBox ch_Medications_BD;
        private System.Windows.Forms.CheckBox ch_Other_BD;
        private System.Windows.Forms.RichTextBox rtxt_Other_BD;
        private System.Windows.Forms.TextBox txt_NoD_BD;
        private CircularButton circularButton3;
        private CircularButton circularButton1;
        private System.Windows.Forms.TextBox txt_Age;
    }
}