﻿namespace Professional_Vets
{
    partial class Other_Vaccine
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Other_Vaccine));
            this.button5 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.rtxt_Notes_OV = new System.Windows.Forms.RichTextBox();
            this.circularButton2 = new Professional_Vets.CircularButton();
            this.circularButton5 = new Professional_Vets.CircularButton();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.NDate1_OV = new System.Windows.Forms.DateTimePicker();
            this.Date1_OV = new System.Windows.Forms.DateTimePicker();
            this.Dr_Name4_OV = new System.Windows.Forms.TextBox();
            this.Dr_Name3_OV = new System.Windows.Forms.TextBox();
            this.Dr_Name2_OV = new System.Windows.Forms.TextBox();
            this.VB2_OV = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.VB1_OV = new System.Windows.Forms.TextBox();
            this.VB3_OV = new System.Windows.Forms.TextBox();
            this.VB4_OV = new System.Windows.Forms.TextBox();
            this.Dr_Name1_OV = new System.Windows.Forms.TextBox();
            this.Date2_OV = new System.Windows.Forms.DateTimePicker();
            this.Date3_OV = new System.Windows.Forms.DateTimePicker();
            this.Date4_OV = new System.Windows.Forms.DateTimePicker();
            this.NDate2_OV = new System.Windows.Forms.DateTimePicker();
            this.NDate3_OV = new System.Windows.Forms.DateTimePicker();
            this.NDate4_OV = new System.Windows.Forms.DateTimePicker();
            this.VB5_OV = new System.Windows.Forms.TextBox();
            this.Date5_OV = new System.Windows.Forms.DateTimePicker();
            this.Dr_Name5_OV = new System.Windows.Forms.TextBox();
            this.NDate5_OV = new System.Windows.Forms.DateTimePicker();
            this.VB6_OV = new System.Windows.Forms.TextBox();
            this.Date6_OV = new System.Windows.Forms.DateTimePicker();
            this.Dr_Name6_OV = new System.Windows.Forms.TextBox();
            this.NDate6_OV = new System.Windows.Forms.DateTimePicker();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.Blue;
            this.button5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button5.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.button5.ForeColor = System.Drawing.Color.White;
            this.button5.Location = new System.Drawing.Point(12, 30);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(336, 23);
            this.button5.TabIndex = 0;
            this.button5.Text = "Other Vaccine";
            this.button5.UseCompatibleTextRendering = true;
            this.button5.UseVisualStyleBackColor = false;
            // 
            // button13
            // 
            this.button13.BackColor = System.Drawing.Color.Blue;
            this.button13.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button13.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.button13.ForeColor = System.Drawing.Color.White;
            this.button13.Location = new System.Drawing.Point(527, 30);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(261, 23);
            this.button13.TabIndex = 29;
            this.button13.Text = "Notes for Other Vaccine";
            this.button13.UseCompatibleTextRendering = true;
            this.button13.UseVisualStyleBackColor = false;
            // 
            // rtxt_Notes_OV
            // 
            this.rtxt_Notes_OV.Location = new System.Drawing.Point(527, 59);
            this.rtxt_Notes_OV.Name = "rtxt_Notes_OV";
            this.rtxt_Notes_OV.Size = new System.Drawing.Size(261, 342);
            this.rtxt_Notes_OV.TabIndex = 30;
            this.rtxt_Notes_OV.Text = "Notes";
            // 
            // circularButton2
            // 
            this.circularButton2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.circularButton2.AutoSize = true;
            this.circularButton2.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.circularButton2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.circularButton2.FlatAppearance.BorderSize = 0;
            this.circularButton2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.circularButton2.Image = ((System.Drawing.Image)(resources.GetObject("circularButton2.Image")));
            this.circularButton2.Location = new System.Drawing.Point(732, 428);
            this.circularButton2.Name = "circularButton2";
            this.circularButton2.Size = new System.Drawing.Size(56, 56);
            this.circularButton2.TabIndex = 33;
            this.circularButton2.UseVisualStyleBackColor = true;
            this.circularButton2.Click += new System.EventHandler(this.circularButton2_Click);
            // 
            // circularButton5
            // 
            this.circularButton5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.circularButton5.AutoSize = true;
            this.circularButton5.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.circularButton5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.circularButton5.FlatAppearance.BorderSize = 0;
            this.circularButton5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.circularButton5.Image = ((System.Drawing.Image)(resources.GetObject("circularButton5.Image")));
            this.circularButton5.Location = new System.Drawing.Point(676, 428);
            this.circularButton5.Name = "circularButton5";
            this.circularButton5.Size = new System.Drawing.Size(56, 56);
            this.circularButton5.TabIndex = 31;
            this.circularButton5.UseVisualStyleBackColor = true;
            this.circularButton5.Click += new System.EventHandler(this.circularButton5_Click);
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.AutoSize = true;
            this.tableLayoutPanel1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.tableLayoutPanel1.ColumnCount = 4;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.Controls.Add(this.NDate1_OV, 3, 1);
            this.tableLayoutPanel1.Controls.Add(this.Date1_OV, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.Dr_Name4_OV, 2, 4);
            this.tableLayoutPanel1.Controls.Add(this.Dr_Name3_OV, 2, 3);
            this.tableLayoutPanel1.Controls.Add(this.Dr_Name2_OV, 2, 2);
            this.tableLayoutPanel1.Controls.Add(this.VB2_OV, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.button1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.button2, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.button3, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.button4, 3, 0);
            this.tableLayoutPanel1.Controls.Add(this.VB1_OV, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.VB3_OV, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.VB4_OV, 1, 4);
            this.tableLayoutPanel1.Controls.Add(this.Dr_Name1_OV, 2, 1);
            this.tableLayoutPanel1.Controls.Add(this.Date2_OV, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.Date3_OV, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.Date4_OV, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.NDate2_OV, 3, 2);
            this.tableLayoutPanel1.Controls.Add(this.NDate3_OV, 3, 3);
            this.tableLayoutPanel1.Controls.Add(this.NDate4_OV, 3, 4);
            this.tableLayoutPanel1.Controls.Add(this.VB5_OV, 1, 5);
            this.tableLayoutPanel1.Controls.Add(this.Date5_OV, 0, 5);
            this.tableLayoutPanel1.Controls.Add(this.Dr_Name5_OV, 2, 5);
            this.tableLayoutPanel1.Controls.Add(this.NDate5_OV, 3, 5);
            this.tableLayoutPanel1.Controls.Add(this.VB6_OV, 1, 6);
            this.tableLayoutPanel1.Controls.Add(this.Date6_OV, 0, 6);
            this.tableLayoutPanel1.Controls.Add(this.Dr_Name6_OV, 2, 6);
            this.tableLayoutPanel1.Controls.Add(this.NDate6_OV, 3, 6);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(12, 59);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 7;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.Size = new System.Drawing.Size(503, 183);
            this.tableLayoutPanel1.TabIndex = 61;
            // 
            // NDate1_OV
            // 
            this.NDate1_OV.CustomFormat = " ";
            this.NDate1_OV.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.NDate1_OV.Location = new System.Drawing.Point(370, 30);
            this.NDate1_OV.Name = "NDate1_OV";
            this.NDate1_OV.Size = new System.Drawing.Size(129, 20);
            this.NDate1_OV.TabIndex = 8;
            this.NDate1_OV.Value = new System.DateTime(2000, 1, 1, 0, 0, 0, 0);
            this.NDate1_OV.ValueChanged += new System.EventHandler(this.NDate1_OV_ValueChanged);
            // 
            // Date1_OV
            // 
            this.Date1_OV.CustomFormat = " ";
            this.Date1_OV.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.Date1_OV.Location = new System.Drawing.Point(3, 30);
            this.Date1_OV.Name = "Date1_OV";
            this.Date1_OV.Size = new System.Drawing.Size(129, 20);
            this.Date1_OV.TabIndex = 5;
            this.Date1_OV.Value = new System.DateTime(2000, 1, 1, 0, 0, 0, 0);
            this.Date1_OV.ValueChanged += new System.EventHandler(this.Date1_OV_ValueChanged);
            // 
            // Dr_Name4_OV
            // 
            this.Dr_Name4_OV.Location = new System.Drawing.Point(290, 108);
            this.Dr_Name4_OV.Name = "Dr_Name4_OV";
            this.Dr_Name4_OV.Size = new System.Drawing.Size(74, 20);
            this.Dr_Name4_OV.TabIndex = 19;
            // 
            // Dr_Name3_OV
            // 
            this.Dr_Name3_OV.Location = new System.Drawing.Point(290, 82);
            this.Dr_Name3_OV.Name = "Dr_Name3_OV";
            this.Dr_Name3_OV.Size = new System.Drawing.Size(74, 20);
            this.Dr_Name3_OV.TabIndex = 15;
            // 
            // Dr_Name2_OV
            // 
            this.Dr_Name2_OV.Location = new System.Drawing.Point(290, 56);
            this.Dr_Name2_OV.Name = "Dr_Name2_OV";
            this.Dr_Name2_OV.Size = new System.Drawing.Size(74, 20);
            this.Dr_Name2_OV.TabIndex = 11;
            // 
            // VB2_OV
            // 
            this.VB2_OV.Dock = System.Windows.Forms.DockStyle.Fill;
            this.VB2_OV.Location = new System.Drawing.Point(138, 56);
            this.VB2_OV.Name = "VB2_OV";
            this.VB2_OV.Size = new System.Drawing.Size(146, 20);
            this.VB2_OV.TabIndex = 10;
            this.VB2_OV.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Blue;
            this.button1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button1.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(2, 2);
            this.button1.Margin = new System.Windows.Forms.Padding(2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(131, 23);
            this.button1.TabIndex = 1;
            this.button1.Text = "Date";
            this.button1.UseVisualStyleBackColor = false;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Blue;
            this.button2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button2.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.Location = new System.Drawing.Point(137, 2);
            this.button2.Margin = new System.Windows.Forms.Padding(2);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(148, 23);
            this.button2.TabIndex = 2;
            this.button2.Text = "Vaccine/ Batch No.";
            this.button2.UseVisualStyleBackColor = false;
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.Blue;
            this.button3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button3.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.button3.ForeColor = System.Drawing.Color.White;
            this.button3.Location = new System.Drawing.Point(289, 2);
            this.button3.Margin = new System.Windows.Forms.Padding(2);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(76, 23);
            this.button3.TabIndex = 3;
            this.button3.Text = "Dr. Name";
            this.button3.UseCompatibleTextRendering = true;
            this.button3.UseVisualStyleBackColor = false;
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.Blue;
            this.button4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button4.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.button4.ForeColor = System.Drawing.Color.White;
            this.button4.Location = new System.Drawing.Point(369, 2);
            this.button4.Margin = new System.Windows.Forms.Padding(2);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(132, 23);
            this.button4.TabIndex = 4;
            this.button4.Text = "Next Date";
            this.button4.UseVisualStyleBackColor = false;
            // 
            // VB1_OV
            // 
            this.VB1_OV.Dock = System.Windows.Forms.DockStyle.Fill;
            this.VB1_OV.Location = new System.Drawing.Point(138, 30);
            this.VB1_OV.Name = "VB1_OV";
            this.VB1_OV.Size = new System.Drawing.Size(146, 20);
            this.VB1_OV.TabIndex = 6;
            this.VB1_OV.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // VB3_OV
            // 
            this.VB3_OV.Dock = System.Windows.Forms.DockStyle.Fill;
            this.VB3_OV.Location = new System.Drawing.Point(138, 82);
            this.VB3_OV.Name = "VB3_OV";
            this.VB3_OV.Size = new System.Drawing.Size(146, 20);
            this.VB3_OV.TabIndex = 14;
            this.VB3_OV.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // VB4_OV
            // 
            this.VB4_OV.Dock = System.Windows.Forms.DockStyle.Fill;
            this.VB4_OV.Location = new System.Drawing.Point(138, 108);
            this.VB4_OV.Name = "VB4_OV";
            this.VB4_OV.Size = new System.Drawing.Size(146, 20);
            this.VB4_OV.TabIndex = 18;
            this.VB4_OV.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Dr_Name1_OV
            // 
            this.Dr_Name1_OV.Location = new System.Drawing.Point(290, 30);
            this.Dr_Name1_OV.Name = "Dr_Name1_OV";
            this.Dr_Name1_OV.Size = new System.Drawing.Size(74, 20);
            this.Dr_Name1_OV.TabIndex = 7;
            // 
            // Date2_OV
            // 
            this.Date2_OV.CustomFormat = " ";
            this.Date2_OV.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.Date2_OV.Location = new System.Drawing.Point(3, 56);
            this.Date2_OV.Name = "Date2_OV";
            this.Date2_OV.Size = new System.Drawing.Size(129, 20);
            this.Date2_OV.TabIndex = 9;
            this.Date2_OV.Value = new System.DateTime(2000, 1, 1, 0, 0, 0, 0);
            this.Date2_OV.ValueChanged += new System.EventHandler(this.Date2_OV_ValueChanged);
            // 
            // Date3_OV
            // 
            this.Date3_OV.CustomFormat = " ";
            this.Date3_OV.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.Date3_OV.Location = new System.Drawing.Point(3, 82);
            this.Date3_OV.Name = "Date3_OV";
            this.Date3_OV.Size = new System.Drawing.Size(129, 20);
            this.Date3_OV.TabIndex = 13;
            this.Date3_OV.Value = new System.DateTime(2000, 1, 1, 0, 0, 0, 0);
            this.Date3_OV.ValueChanged += new System.EventHandler(this.Date3_OV_ValueChanged);
            // 
            // Date4_OV
            // 
            this.Date4_OV.CustomFormat = " ";
            this.Date4_OV.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.Date4_OV.Location = new System.Drawing.Point(3, 108);
            this.Date4_OV.Name = "Date4_OV";
            this.Date4_OV.Size = new System.Drawing.Size(129, 20);
            this.Date4_OV.TabIndex = 17;
            this.Date4_OV.Value = new System.DateTime(2000, 1, 1, 0, 0, 0, 0);
            this.Date4_OV.ValueChanged += new System.EventHandler(this.Date4_OV_ValueChanged);
            // 
            // NDate2_OV
            // 
            this.NDate2_OV.CustomFormat = " ";
            this.NDate2_OV.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.NDate2_OV.Location = new System.Drawing.Point(370, 56);
            this.NDate2_OV.Name = "NDate2_OV";
            this.NDate2_OV.Size = new System.Drawing.Size(129, 20);
            this.NDate2_OV.TabIndex = 12;
            this.NDate2_OV.Value = new System.DateTime(2000, 1, 1, 0, 0, 0, 0);
            this.NDate2_OV.ValueChanged += new System.EventHandler(this.NDate2_OV_ValueChanged);
            // 
            // NDate3_OV
            // 
            this.NDate3_OV.CustomFormat = " ";
            this.NDate3_OV.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.NDate3_OV.Location = new System.Drawing.Point(370, 82);
            this.NDate3_OV.Name = "NDate3_OV";
            this.NDate3_OV.Size = new System.Drawing.Size(129, 20);
            this.NDate3_OV.TabIndex = 16;
            this.NDate3_OV.Value = new System.DateTime(2000, 1, 1, 0, 0, 0, 0);
            this.NDate3_OV.ValueChanged += new System.EventHandler(this.NDate3_OV_ValueChanged);
            // 
            // NDate4_OV
            // 
            this.NDate4_OV.CustomFormat = " ";
            this.NDate4_OV.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.NDate4_OV.Location = new System.Drawing.Point(370, 108);
            this.NDate4_OV.Name = "NDate4_OV";
            this.NDate4_OV.Size = new System.Drawing.Size(129, 20);
            this.NDate4_OV.TabIndex = 20;
            this.NDate4_OV.Value = new System.DateTime(2000, 1, 1, 0, 0, 0, 0);
            this.NDate4_OV.ValueChanged += new System.EventHandler(this.NDate4_OV_ValueChanged);
            // 
            // VB5_OV
            // 
            this.VB5_OV.Dock = System.Windows.Forms.DockStyle.Fill;
            this.VB5_OV.Location = new System.Drawing.Point(138, 134);
            this.VB5_OV.Name = "VB5_OV";
            this.VB5_OV.Size = new System.Drawing.Size(146, 20);
            this.VB5_OV.TabIndex = 22;
            this.VB5_OV.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Date5_OV
            // 
            this.Date5_OV.CustomFormat = " ";
            this.Date5_OV.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.Date5_OV.Location = new System.Drawing.Point(3, 134);
            this.Date5_OV.Name = "Date5_OV";
            this.Date5_OV.Size = new System.Drawing.Size(129, 20);
            this.Date5_OV.TabIndex = 21;
            this.Date5_OV.Value = new System.DateTime(2000, 1, 1, 0, 0, 0, 0);
            this.Date5_OV.ValueChanged += new System.EventHandler(this.Date5_OV_ValueChanged);
            // 
            // Dr_Name5_OV
            // 
            this.Dr_Name5_OV.Location = new System.Drawing.Point(290, 134);
            this.Dr_Name5_OV.Name = "Dr_Name5_OV";
            this.Dr_Name5_OV.Size = new System.Drawing.Size(74, 20);
            this.Dr_Name5_OV.TabIndex = 23;
            // 
            // NDate5_OV
            // 
            this.NDate5_OV.CustomFormat = " ";
            this.NDate5_OV.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.NDate5_OV.Location = new System.Drawing.Point(370, 134);
            this.NDate5_OV.Name = "NDate5_OV";
            this.NDate5_OV.Size = new System.Drawing.Size(129, 20);
            this.NDate5_OV.TabIndex = 24;
            this.NDate5_OV.Value = new System.DateTime(2000, 1, 1, 0, 0, 0, 0);
            this.NDate5_OV.ValueChanged += new System.EventHandler(this.NDate5_OV_ValueChanged);
            // 
            // VB6_OV
            // 
            this.VB6_OV.Dock = System.Windows.Forms.DockStyle.Fill;
            this.VB6_OV.Location = new System.Drawing.Point(138, 160);
            this.VB6_OV.Name = "VB6_OV";
            this.VB6_OV.Size = new System.Drawing.Size(146, 20);
            this.VB6_OV.TabIndex = 26;
            this.VB6_OV.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Date6_OV
            // 
            this.Date6_OV.CustomFormat = " ";
            this.Date6_OV.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.Date6_OV.Location = new System.Drawing.Point(3, 160);
            this.Date6_OV.Name = "Date6_OV";
            this.Date6_OV.Size = new System.Drawing.Size(129, 20);
            this.Date6_OV.TabIndex = 25;
            this.Date6_OV.Value = new System.DateTime(2000, 1, 1, 0, 0, 0, 0);
            this.Date6_OV.ValueChanged += new System.EventHandler(this.Date6_OV_ValueChanged);
            // 
            // Dr_Name6_OV
            // 
            this.Dr_Name6_OV.Location = new System.Drawing.Point(290, 160);
            this.Dr_Name6_OV.Name = "Dr_Name6_OV";
            this.Dr_Name6_OV.Size = new System.Drawing.Size(74, 20);
            this.Dr_Name6_OV.TabIndex = 27;
            // 
            // NDate6_OV
            // 
            this.NDate6_OV.CustomFormat = " ";
            this.NDate6_OV.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.NDate6_OV.Location = new System.Drawing.Point(370, 160);
            this.NDate6_OV.Name = "NDate6_OV";
            this.NDate6_OV.Size = new System.Drawing.Size(129, 20);
            this.NDate6_OV.TabIndex = 28;
            this.NDate6_OV.Value = new System.DateTime(2000, 1, 1, 0, 0, 0, 0);
            this.NDate6_OV.ValueChanged += new System.EventHandler(this.NDate6_OV_ValueChanged);
            // 
            // Other_Vaccine
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.ClientSize = new System.Drawing.Size(800, 496);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Controls.Add(this.circularButton2);
            this.Controls.Add(this.circularButton5);
            this.Controls.Add(this.button13);
            this.Controls.Add(this.rtxt_Notes_OV);
            this.Controls.Add(this.button5);
            this.Name = "Other_Vaccine";
            this.Text = "Other_Vaccine";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Other_Vaccine_FormClosing);
            this.Load += new System.EventHandler(this.Other_Vaccine_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.RichTextBox rtxt_Notes_OV;
        private CircularButton circularButton2;
        private CircularButton circularButton5;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.DateTimePicker NDate1_OV;
        private System.Windows.Forms.DateTimePicker Date1_OV;
        private System.Windows.Forms.TextBox Dr_Name4_OV;
        private System.Windows.Forms.TextBox Dr_Name3_OV;
        private System.Windows.Forms.TextBox Dr_Name2_OV;
        private System.Windows.Forms.TextBox VB2_OV;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.TextBox VB1_OV;
        private System.Windows.Forms.TextBox VB3_OV;
        private System.Windows.Forms.TextBox VB4_OV;
        private System.Windows.Forms.TextBox Dr_Name1_OV;
        private System.Windows.Forms.DateTimePicker Date2_OV;
        private System.Windows.Forms.DateTimePicker Date3_OV;
        private System.Windows.Forms.DateTimePicker Date4_OV;
        private System.Windows.Forms.DateTimePicker NDate2_OV;
        private System.Windows.Forms.DateTimePicker NDate3_OV;
        private System.Windows.Forms.DateTimePicker NDate4_OV;
        private System.Windows.Forms.TextBox VB5_OV;
        private System.Windows.Forms.DateTimePicker Date5_OV;
        private System.Windows.Forms.TextBox Dr_Name5_OV;
        private System.Windows.Forms.DateTimePicker NDate5_OV;
        private System.Windows.Forms.TextBox VB6_OV;
        private System.Windows.Forms.DateTimePicker Date6_OV;
        private System.Windows.Forms.TextBox Dr_Name6_OV;
        private System.Windows.Forms.DateTimePicker NDate6_OV;
    }
}