﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Professional_Vets
{
    public partial class Forgot_Password : Form
    {

        public Forgot_Password()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void Forgot_Password_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.Hide();
            Login L = new Login();
            L.ShowDialog();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(txt_FN.Text != "" && txt_LN.Text != "" && txt_Email.Text != "")
            {
                if (txt_FN.Text == "Abd El-Rahman" && txt_LN.Text == "El-Tahat" && txt_Email.Text == "Abdrhmt@gmail.com")
                {
                    MessageBox.Show("Your Password is: At@hat123");
                }
                txt_FN.Clear();
                txt_LN.Clear();
                txt_Email.Clear();
                    
            }
            else
            {
                MessageBox.Show("You must fill All Data");
            }
            txt_FN.Clear();
            txt_LN.Clear();
            txt_Email.Clear();
        }
    }
}
