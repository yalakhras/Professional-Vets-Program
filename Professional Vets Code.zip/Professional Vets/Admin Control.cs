﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Professional_Vets
{
    public partial class Admin_Control : Form
    {
        SqlConnection con;
        SqlCommand cmd;

        public Admin_Control()
        {
            InitializeComponent();
        }

        private void Admin_Control_Load(object sender, EventArgs e)
        {
            con = new SqlConnection(Properties.Settings.Default.Database1ConnectionString);
            con.Open();

            SqlDataAdapter dataAdp = new SqlDataAdapter ("select * from Login where Role like '" + "User" + "%'", con);

            DataTable dt = new DataTable("Login");

            dataAdp.Fill(dt);

            dataGridView1.DataSource = dt;

            con.Close();
        }


        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            try
            {
                if (txt_user.Text == "" || txt_password.Text == "")
                {
                    MessageBox.Show("Please enter the Username and the Password To Update");
                }
                else if (txt_user.Text != "" && txt_password.Text != "")
                {
                    cmd = new SqlCommand("select * FROM Login WHERE Username= '" + txt_user.Text + "'", con);
                    con.Open();
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataSet ds = new DataSet();
                    da.Fill(ds);

                    int i = ds.Tables[0].Rows.Count;
                    if (i > 0)
                    {
                        cmd = new SqlCommand("Update Login SET Password='" + txt_password.Text + "' where Username like '" + txt_user.Text + "%'", con);
                        cmd.CommandType = CommandType.Text;
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("The Password for this user '" + txt_user.Text + " 'Updated");

                    }
                    else
                    {
                        MessageBox.Show("This User '"+ txt_user.Text + "' not available, You can Add it as a new user");
                    }
                }

                txt_user.Clear();
                txt_password.Clear();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (txt_user.Text == "" || txt_password.Text == "")
                {
                    MessageBox.Show("All Fields Are Compulsory");
                }
                else if (txt_user.Text != "" && txt_password.Text != "")
                {
                    cmd = new SqlCommand("select * FROM Login WHERE Username= '" + txt_user.Text + "'", con);
                    con.Open();
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataSet ds = new DataSet();
                    da.Fill(ds);

                    int i = ds.Tables[0].Rows.Count;
                    if (i > 0)
                    {
                        MessageBox.Show("This Username" + txt_user + "Already Exists");
                        ds.Clear();
                    }

                    else
                    {
                        cmd = new SqlCommand("Insert into Login values('"+txt_user.Text+"','"+txt_password.Text+"','"+txt_Role.Text+"')", con);
                        cmd.CommandType = CommandType.Text;
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Data Inserted");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
                
            }

            txt_user.Clear();
            txt_password.Clear();
        }

        private void Admin_Control_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.Hide();
            Login L = new Login();
            L.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                if (txt_user.Text == "")
                {
                    MessageBox.Show("Please enter the Username To Delete");
                }
                else
                {
                    cmd = new SqlCommand("Delete Login WHERE Username='" + txt_user.Text + "'", con);
                    con.Open();
                    cmd.CommandType = CommandType.Text;
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Data Deleted");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }

            txt_user.Clear();
            txt_password.Clear();

        }

        private void circularButton1_Click(object sender, EventArgs e)
        {
            this.Hide();
            HomePage HP = new HomePage("Atahat");
            HP.ShowDialog();
        }
    }
}
