﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Professional_Vets
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
            
        }

        private void LoginButton_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(Properties.Settings.Default.Database1ConnectionString) ;
            SqlDataAdapter sda = new SqlDataAdapter("Select Username From Login Where Username = '" + textbox_user.Text + "' and Password = '" + textbox_pass.Text + "'", con);
            DataTable dt = new System.Data.DataTable();
            sda.Fill(dt);

            if (dt.Rows.Count > 0)
            {
                this.Hide();
                HomePage HP = new HomePage(dt.Rows[0][0].ToString());
                HP.ShowDialog();
            }
            // Check if the Username & the Password Empty ot NO.
            else
            { if (textbox_user.Text.Trim().Equals(""))
                { MessageBox.Show("Enter Your Username", "Empty Username", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            else if (textbox_pass.Text.Trim().Equals(""))
                { MessageBox.Show("Enter Your Password", "Empty Password", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

            // Check if the Username & the Password doen't Exist
            else
                { MessageBox.Show("Wrong Username or Password", "Wrong Data", MessageBoxButtons.OK, MessageBoxIcon.Error); }
                    }

            con.Close();


        }
        

        private void label_FgPas_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            Forgot_Password FG = new Forgot_Password();
            FG.ShowDialog();
        }

        private void textbox_user_TextChanged(object sender, EventArgs e)
        {
                        if (textbox_user.Text == "Atahat" || textbox_user.Text == "atahat")
            {
                label_FgPas.Visible = true;
            }

            else
            {
                label_FgPas.Visible = false;
            }

       }
        

        private void Login_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (e.CloseReason == CloseReason.UserClosing)
            {
                DialogResult result = MessageBox.Show("Do you really want to exit?", "Exit", MessageBoxButtons.YesNo);
                if (result == DialogResult.Yes)
                {
                    Environment.Exit(0);
                }
                else
                {
                    e.Cancel = true;
                }
            }
            else
            {
                e.Cancel = true;
            }

        }

        private void Login_Load(object sender, EventArgs e)
        {

        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            MessageBox.Show("This program Developed by: Yaser Al-Akhras. " +
                "Email: yaser.alakhras@gmail.com", "About", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }



}
