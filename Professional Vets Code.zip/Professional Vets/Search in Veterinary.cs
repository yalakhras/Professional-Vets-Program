﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Professional_Vets
{

    public partial class Search_in_Veterinary : Form
    {
        String vn;

        public static SqlConnection con = new SqlConnection(Properties.Settings.Default.Database1ConnectionString);

        String Id;
        int Id1;
        int delete_Id;


        public Search_in_Veterinary(String role)
        {
            InitializeComponent();
            vn = role;
        }


        private void circularButton1_Click(object sender, EventArgs e)
        {
            this.Hide();
            HomePage HP = new HomePage(vn);
            HP.ShowDialog();
        }

        private void Search_Load(object sender, EventArgs e)
        {
            if (con.State == ConnectionState.Open)
            {
                con.Close();
            }

            con.Open();
            fill_grid0();
            fill_grid1();
            fill_grid2();
            fill_grid3();
            
            con = new SqlConnection(Properties.Settings.Default.Database1ConnectionString);
           con.Open();

            SqlDataAdapter dataAdp0 = new SqlDataAdapter("select * from Add_Veterinary", con);
            SqlDataAdapter dataAdp1 = new SqlDataAdapter("select * from Ph_Ex", con);
            SqlDataAdapter dataAdp2 = new SqlDataAdapter("select * from Ph_Ex1", con);
            SqlDataAdapter dataAdp3 = new SqlDataAdapter("select * from Ph_Ex2", con);

            DataTable dt0 = new DataTable("Add_Veterinary");
            DataTable dt1 = new DataTable("Ph_Ex");
            DataTable dt2 = new DataTable("Ph_Ex1");
            DataTable dt3 = new DataTable("Ph_Ex2");

            dataAdp0.Fill(dt0);
            dataAdp1.Fill(dt1);
            dataAdp2.Fill(dt2);
            dataAdp3.Fill(dt3);

            dataGridView0.DataSource = dt0;
            dataGridView1.DataSource = dt1;
            dataGridView2.DataSource = dt2;
            dataGridView3.DataSource = dt3;

        }


        public void fill_grid0()
        {
            SqlCommand cmd0 = con.CreateCommand();
            cmd0.CommandType = CommandType.Text;
            cmd0.CommandText = "select * from Add_Veterinary";
            cmd0.ExecuteNonQuery();
            DataTable dt0 = new DataTable();
            SqlDataAdapter da0 = new SqlDataAdapter(cmd0);
            da0.Fill(dt0);
            dataGridView0.DataSource = dt0;
        }

        public void fill_grid1()
        {
            SqlCommand cmd1 = con.CreateCommand();
            cmd1.CommandType = CommandType.Text;
            cmd1.CommandText = "select * from Ph_Ex";
            cmd1.ExecuteNonQuery();
            DataTable dt1 = new DataTable();
            SqlDataAdapter da1 = new SqlDataAdapter(cmd1);
            da1.Fill(dt1);
            dataGridView1.DataSource = dt1;
        }

        public void fill_grid2()
        {
            SqlCommand cmd2 = con.CreateCommand();
            cmd2.CommandType = CommandType.Text;
            cmd2.CommandText = "select * from Ph_Ex1";
            cmd2.ExecuteNonQuery();
            DataTable dt2 = new DataTable();
            SqlDataAdapter da2 = new SqlDataAdapter(cmd2);
            da2.Fill(dt2);
            dataGridView2.DataSource = dt2;
        }

        public void fill_grid3()
        {
            SqlCommand cmd3 = con.CreateCommand();
            cmd3.CommandType = CommandType.Text;
            cmd3.CommandText = "select * from Ph_Ex2";
            cmd3.ExecuteNonQuery();
            DataTable dt3 = new DataTable();
            SqlDataAdapter da3 = new SqlDataAdapter(cmd3);
            da3.Fill(dt3);
            dataGridView3.DataSource = dt3;
        }


        private void txt_search_TextChanged(object sender, EventArgs e)
        {
            con = new SqlConnection(Properties.Settings.Default.Database1ConnectionString);
            con.Open();
            SqlDataAdapter dataAdp0 = new SqlDataAdapter("select * from Add_Veterinary where Owner like '" + txt_search.Text + "%'", con);
            SqlDataAdapter dataAdp1 = new SqlDataAdapter("select * from Ph_Ex where Owner like '" + txt_search.Text + "%'", con);
            SqlDataAdapter dataAdp2 = new SqlDataAdapter("select * from Ph_Ex1 where Owner like '" + txt_search.Text + "%'", con);
            SqlDataAdapter dataAdp3 = new SqlDataAdapter("select * from Ph_Ex2 where Owner like '" + txt_search.Text + "%'", con);

            DataTable dt0 = new DataTable("Add_Veterinary");
            DataTable dt1 = new DataTable("Ph_Ex");
            DataTable dt2 = new DataTable("Ph_Ex1");
            DataTable dt3 = new DataTable("Ph_Ex2");

            dataAdp0.Fill(dt0);
            dataAdp1.Fill(dt1);
            dataAdp2.Fill(dt2);
            dataAdp3.Fill(dt3);

            dataGridView0.DataSource = dt0;
            dataGridView1.DataSource = dt1;
            dataGridView2.DataSource = dt2;
            dataGridView3.DataSource = dt3;
            
        }

        private void Search_in_Veterinary_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.Hide();
            HomePage HP = new HomePage(vn);
            HP.ShowDialog();
        }

        private void dataGridView0_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            Id = dataGridView0.Rows[e.RowIndex].Cells["No"].Value.ToString();
            if (Id == "")
            {
                Id1 = 0;
            }

            else
            {
                Id1 = Convert.ToInt32(dataGridView0.Rows[e.RowIndex].Cells["No"].Value.ToString());
            }

            if (Id1 == 0)
            {
                SqlCommand cmd0 = con.CreateCommand();
                cmd0.CommandType = CommandType.Text;
                cmd0.CommandText = "Insert into Add_Veterinary Vaues ('" + dataGridView0.Rows[e.RowIndex].Cells["Owner"].Value.ToString() + "', '" + dataGridView0.Rows[e.RowIndex].Cells["Mobile"].Value.ToString() + "', '" + dataGridView0.Rows[e.RowIndex].Cells["Pet"].Value.ToString() + "', '" + dataGridView0.Rows[e.RowIndex].Cells["Species"].Value.ToString() + "', '" + dataGridView0.Rows[e.RowIndex].Cells["Sex"].Value.ToString() + "', '" + dataGridView0.Rows[e.RowIndex].Cells["Age_Years"].Value.ToString() + "', '" + dataGridView0.Rows[e.RowIndex].Cells["Age_Months"].Value.ToString() + "', '" + dataGridView0.Rows[e.RowIndex].Cells["Breed"].Value.ToString() + "', '" + dataGridView0.Rows[e.RowIndex].Cells["Color"].Value.ToString() + "')";

                cmd0.ExecuteNonQuery();
                fill_grid0();
            }

            else
            {
                SqlCommand cmd0 = con.CreateCommand();
                cmd0.CommandType = CommandType.Text;
                cmd0.CommandText = "Update Add_Veterinary set Owner ='" + dataGridView0.Rows[e.RowIndex].Cells["Owner"].Value.ToString() + "', Mobile ='" + dataGridView0.Rows[e.RowIndex].Cells["Mobile"].Value.ToString() + "', Pet ='" + dataGridView0.Rows[e.RowIndex].Cells["Pet"].Value.ToString() + "', Species ='" + dataGridView0.Rows[e.RowIndex].Cells["Species"].Value.ToString() + "', Sex ='" + dataGridView0.Rows[e.RowIndex].Cells["Sex"].Value.ToString() + "', Age_Years ='" + dataGridView0.Rows[e.RowIndex].Cells["Age_Years"].Value.ToString() + "', Age_Months ='" + dataGridView0.Rows[e.RowIndex].Cells["Age_Months"].Value.ToString() + "', Breed ='" + dataGridView0.Rows[e.RowIndex].Cells["Breed"].Value.ToString() + "', Color ='" + dataGridView0.Rows[e.RowIndex].Cells["Color"].Value.ToString() + "' Where No= " + Id1 + "";

                cmd0.ExecuteNonQuery();

                MessageBox.Show("The Data was Updated");
                fill_grid0();

            }
        }

        private void dataGridView1_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            Id = dataGridView1.Rows[e.RowIndex].Cells["No"].Value.ToString();
            if (Id == "")
            {
                Id1 = 0;
            }

            else
            {
                Id1 = Convert.ToInt32(dataGridView1.Rows[e.RowIndex].Cells["No"].Value.ToString());
            }

            if (Id1 == 0)
            {
                SqlCommand cmd1 = con.CreateCommand();
                cmd1.CommandType = CommandType.Text;
                cmd1.CommandText = "Insert into Ph_Ex Vaues ('" + dataGridView1.Rows[e.RowIndex].Cells["Owner"].Value.ToString() + "', '" + dataGridView1.Rows[e.RowIndex].Cells["Mobile"].Value.ToString() + "', '" + dataGridView1.Rows[e.RowIndex].Cells["Pet"].Value.ToString() + "', '" + dataGridView1.Rows[e.RowIndex].Cells["RT"].Value.ToString() + "', '" + dataGridView1.Rows[e.RowIndex].Cells["HR"].Value.ToString() + "', '" + dataGridView1.Rows[e.RowIndex].Cells["RR"].Value.ToString() + "', '" + dataGridView1.Rows[e.RowIndex].Cells["CRT"].Value.ToString() + "', '" + dataGridView1.Rows[e.RowIndex].Cells["Wight"].Value.ToString() + "', '" + dataGridView1.Rows[e.RowIndex].Cells["Appear_Normal_CAS"].Value.ToString() + "', '" + dataGridView1.Rows[e.RowIndex].Cells["Pigment_CAS"].Value.ToString() + "', '" + dataGridView1.Rows[e.RowIndex].Cells["Itchy_CAS"].Value.ToString() + "', '" + dataGridView1.Rows[e.RowIndex].Cells["Lesion_CAS"].Value.ToString() + "', '" + dataGridView1.Rows[e.RowIndex].Cells["Dry_Dull_CAS"].Value.ToString() + "', '" + dataGridView1.Rows[e.RowIndex].Cells["Hair_Loss_CAS"].Value.ToString() + "', '" + dataGridView1.Rows[e.RowIndex].Cells["Lumps_CAS"].Value.ToString() + "', '" + dataGridView1.Rows[e.RowIndex].Cells["Greasy_CAS"].Value.ToString() + "', '" + dataGridView1.Rows[e.RowIndex].Cells["Shedding_CAS"].Value.ToString() + "', '" + dataGridView1.Rows[e.RowIndex].Cells["Parasites_CAS"].Value.ToString() + "', '" + dataGridView1.Rows[e.RowIndex].Cells["Scaly_CAS"].Value.ToString() + "', '" + dataGridView1.Rows[e.RowIndex].Cells["Other_CAS"].Value.ToString() + "', '" + dataGridView1.Rows[e.RowIndex].Cells["Normal_Eyes"].Value.ToString() + "', '" + dataGridView1.Rows[e.RowIndex].Cells["Cataract_Eyes"].Value.ToString() + "', '" + dataGridView1.Rows[e.RowIndex].Cells["Discharges_Eyes"].Value.ToString() + "', '" + dataGridView1.Rows[e.RowIndex].Cells["Inflamed_Eyes"].Value.ToString() + "', '" + dataGridView1.Rows[e.RowIndex].Cells["Dry_Eye_Eyes"].Value.ToString() + "', '" + dataGridView1.Rows[e.RowIndex].Cells["Ulcers_Lesions_Eyes"].Value.ToString() + "', '" + dataGridView1.Rows[e.RowIndex].Cells["Infected_Eyes"].Value.ToString() + "', '" + dataGridView1.Rows[e.RowIndex].Cells["Other_Eyes"].Value.ToString() + "', '" + dataGridView1.Rows[e.RowIndex].Cells["Normal_Ears"].Value.ToString() + "', '" + dataGridView1.Rows[e.RowIndex].Cells["Inflamed_Ears"].Value.ToString() + "', '" + dataGridView1.Rows[e.RowIndex].Cells["Yeast_Inf_Ears"].Value.ToString() + "', '" + dataGridView1.Rows[e.RowIndex].Cells["Bacterial_Ears"].Value.ToString() + "', '" + dataGridView1.Rows[e.RowIndex].Cells["Itchy_Ears"].Value.ToString() + "', '" + dataGridView1.Rows[e.RowIndex].Cells["Mites_Ears"].Value.ToString() + "', '" + dataGridView1.Rows[e.RowIndex].Cells["Excessive_Debris_Hair_Ears"].Value.ToString() + "', '" + dataGridView1.Rows[e.RowIndex].Cells["Other_Ears"].Value.ToString() + "')";

                cmd1.ExecuteNonQuery();
                fill_grid1();
            }

            else
            {
                SqlCommand cmd1 = con.CreateCommand();
                cmd1.CommandType = CommandType.Text;
                cmd1.CommandText = "Update Ph_Ex set Owner ='" + dataGridView1.Rows[e.RowIndex].Cells["Owner"].Value.ToString() + "', Mobile ='" + dataGridView1.Rows[e.RowIndex].Cells["Mobile"].Value.ToString() + "', Pet ='" + dataGridView1.Rows[e.RowIndex].Cells["Pet"].Value.ToString() + "', RT ='" + dataGridView1.Rows[e.RowIndex].Cells["RT"].Value.ToString() + "', HR ='" + dataGridView1.Rows[e.RowIndex].Cells["HR"].Value.ToString() + "', RR ='" + dataGridView1.Rows[e.RowIndex].Cells["RR"].Value.ToString() + "', CRT ='" + dataGridView1.Rows[e.RowIndex].Cells["CRT"].Value.ToString() + "', Wight ='" + dataGridView1.Rows[e.RowIndex].Cells["Wight"].Value.ToString() + "', Appear_Normal_CAS ='" + dataGridView1.Rows[e.RowIndex].Cells["Appear_Normal_CAS"].Value.ToString() + "', Pigment_CAS ='" + dataGridView1.Rows[e.RowIndex].Cells["Pigment_CAS"].Value.ToString() + "', Itchy_CAS ='" + dataGridView1.Rows[e.RowIndex].Cells["Itchy_CAS"].Value.ToString() + "', Lesion_CAS ='" + dataGridView1.Rows[e.RowIndex].Cells["Lesion_CAS"].Value.ToString() + "', Dry_Dull_CAS ='" + dataGridView1.Rows[e.RowIndex].Cells["Dry_Dull_CAS"].Value.ToString() + "', Hair_Loss_CAS ='" + dataGridView1.Rows[e.RowIndex].Cells["Hair_Loss_CAS"].Value.ToString() + "', Lumps_CAS ='" + dataGridView1.Rows[e.RowIndex].Cells["Lumps_CAS"].Value.ToString() + "', Greasy_CAS ='" + dataGridView1.Rows[e.RowIndex].Cells["Greasy_CAS"].Value.ToString() + "', Shedding_CAS ='" + dataGridView1.Rows[e.RowIndex].Cells["Shedding_CAS"].Value.ToString() + "', Parasites_CAS ='" + dataGridView1.Rows[e.RowIndex].Cells["Parasites_CAS"].Value.ToString() + "', Scaly_CAS ='" + dataGridView1.Rows[e.RowIndex].Cells["Scaly_CAS"].Value.ToString() + "', Other_CAS ='" + dataGridView1.Rows[e.RowIndex].Cells["Other_CAS"].Value.ToString() + "', Normal_Eyes ='" + dataGridView1.Rows[e.RowIndex].Cells["Normal_Eyes"].Value.ToString() + "', Cataract_Eyes ='" + dataGridView1.Rows[e.RowIndex].Cells["Cataract_Eyes"].Value.ToString() + "', Discharges_Eyes ='" + dataGridView1.Rows[e.RowIndex].Cells["Discharges_Eyes"].Value.ToString() + "', Inflamed_Eyes ='" + dataGridView1.Rows[e.RowIndex].Cells["Inflamed_Eyes"].Value.ToString() + "', Dry_Eye_Eyes ='" + dataGridView1.Rows[e.RowIndex].Cells["Dry_Eye_Eyes"].Value.ToString() + "', Ulcers_Lesions_Eyes ='" + dataGridView1.Rows[e.RowIndex].Cells["Ulcers_Lesions_Eyes"].Value.ToString() + "', Infected_Eyes ='" + dataGridView1.Rows[e.RowIndex].Cells["Infected_Eyes"].Value.ToString() + "', Other_Eyes ='" + dataGridView1.Rows[e.RowIndex].Cells["Other_Eyes"].Value.ToString() + "', Normal_Ears ='" + dataGridView1.Rows[e.RowIndex].Cells["Normal_Ears"].Value.ToString() + "', Inflamed_Ears ='" + dataGridView1.Rows[e.RowIndex].Cells["Inflamed_Ears"].Value.ToString() + "', Yeast_Inf_Ears ='" + dataGridView1.Rows[e.RowIndex].Cells["Yeast_Inf_Ears"].Value.ToString() + "', Bacterial_Ears ='" + dataGridView1.Rows[e.RowIndex].Cells["Bacterial_Ears"].Value.ToString() + "', Itchy_Ears ='" + dataGridView1.Rows[e.RowIndex].Cells["Itchy_Ears"].Value.ToString() + "', Mites_Ears ='" + dataGridView1.Rows[e.RowIndex].Cells["Mites_Ears"].Value.ToString() + "', Excessive_Debris_Hair_Ears ='" + dataGridView1.Rows[e.RowIndex].Cells["Excessive_Debris_Hair_Ears"].Value.ToString() + "', Other_Ears ='" + dataGridView1.Rows[e.RowIndex].Cells["Other_Ears"].Value.ToString() + "' Where No= " + Id1 + "";

                cmd1.ExecuteNonQuery();

                MessageBox.Show("The Data was Updated");
                fill_grid1();

            }
        }

        private void dataGridView2_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            Id = dataGridView2.Rows[e.RowIndex].Cells["No"].Value.ToString();
            if (Id == "")
            {
                Id1 = 0;
            }

            else
            {
                Id1 = Convert.ToInt32(dataGridView2.Rows[e.RowIndex].Cells["No"].Value.ToString());
            }

            if (Id1 == 0)
            {
                SqlCommand cmd2 = con.CreateCommand();
                cmd2.CommandType = CommandType.Text;
                cmd2.CommandText = "Insert into Ph_Ex1 Vaues ('" + dataGridView2.Rows[e.RowIndex].Cells["Owner"].Value.ToString() + "', '" + dataGridView2.Rows[e.RowIndex].Cells["Mobile"].Value.ToString() + "', '" + dataGridView2.Rows[e.RowIndex].Cells["Pet"].Value.ToString() + "', '" + dataGridView2.Rows[e.RowIndex].Cells["Normal_NAT"].Value.ToString() + "', '" + dataGridView2.Rows[e.RowIndex].Cells["Nasal_Discharge_NAT"].Value.ToString() + "', '" + dataGridView2.Rows[e.RowIndex].Cells["Inf_Throat_NAT"].Value.ToString() + "', '" + dataGridView2.Rows[e.RowIndex].Cells["Inf_Tensile_NAT"].Value.ToString() + "', '" + dataGridView2.Rows[e.RowIndex].Cells["Other_NAT"].Value.ToString() + "', '" + dataGridView2.Rows[e.RowIndex].Cells["Normal_MTG"].Value.ToString() + "', '" + dataGridView2.Rows[e.RowIndex].Cells["Broken_MTG"].Value.ToString() + "', '" + dataGridView2.Rows[e.RowIndex].Cells["Loose_MTG"].Value.ToString() + "', '" + dataGridView2.Rows[e.RowIndex].Cells["Ulcers_Lesions_MTG"].Value.ToString() + "', '" + dataGridView2.Rows[e.RowIndex].Cells["Pyorrhea_MTG"].Value.ToString() + "', '" + dataGridView2.Rows[e.RowIndex].Cells["Gingivitis_MTG"].Value.ToString() + "', '" + dataGridView2.Rows[e.RowIndex].Cells["Stain_MTG"].Value.ToString() + "', '" + dataGridView2.Rows[e.RowIndex].Cells["Tartar_Degree_MTG"].Value.ToString() + "', '" + dataGridView2.Rows[e.RowIndex].Cells["Normal_MLL"].Value.ToString() + "', '" + dataGridView2.Rows[e.RowIndex].Cells["Lameness_MLL"].Value.ToString() + "', '" + dataGridView2.Rows[e.RowIndex].Cells["Pain_on_Palpation_MLL"].Value.ToString() + "', '" + dataGridView2.Rows[e.RowIndex].Cells["Sounds_Normal_H"].Value.ToString() + "', '" + dataGridView2.Rows[e.RowIndex].Cells["Arrhythmia_H"].Value.ToString() + "', '" + dataGridView2.Rows[e.RowIndex].Cells["Murmur_H"].Value.ToString() + "', '" + dataGridView2.Rows[e.RowIndex].Cells["Other_H"].Value.ToString() + "', '" + dataGridView2.Rows[e.RowIndex].Cells["Normal_AB"].Value.ToString() + "', '" + dataGridView2.Rows[e.RowIndex].Cells["Enlarged_AB"].Value.ToString() + "', '" + dataGridView2.Rows[e.RowIndex].Cells["Mass_AB"].Value.ToString() + "', '" + dataGridView2.Rows[e.RowIndex].Cells["Fluid_AB"].Value.ToString() + "', '" + dataGridView2.Rows[e.RowIndex].Cells["Other_AB"].Value.ToString() + "', '" + dataGridView2.Rows[e.RowIndex].Cells["Normal_Sound_LU"].Value.ToString() + "', '" + dataGridView2.Rows[e.RowIndex].Cells["Abnormal_Sound_LU"].Value.ToString() + "', '" + dataGridView2.Rows[e.RowIndex].Cells["Breathing_Difficulty_LU"].Value.ToString() + "', '" + dataGridView2.Rows[e.RowIndex].Cells["Coughing_LU"].Value.ToString() + "', '" + dataGridView2.Rows[e.RowIndex].Cells["Congestion_LU"].Value.ToString() + "', '" + dataGridView2.Rows[e.RowIndex].Cells["Other_LU"].Value.ToString() + "')";

                cmd2.ExecuteNonQuery();
                fill_grid2();
            }

            else
            {
                SqlCommand cmd2 = con.CreateCommand();
                cmd2.CommandType = CommandType.Text;
                cmd2.CommandText = "Update Ph_Ex1 set Owner ='" + dataGridView2.Rows[e.RowIndex].Cells["Owner"].Value.ToString() + "', Mobile ='" + dataGridView2.Rows[e.RowIndex].Cells["Mobile"].Value.ToString() + "', Pet ='" + dataGridView2.Rows[e.RowIndex].Cells["Pet"].Value.ToString() + "', Normal_NAT ='" + dataGridView2.Rows[e.RowIndex].Cells["Normal_NAT"].Value.ToString() + "', Nasal_Discharge_NAT ='" + dataGridView2.Rows[e.RowIndex].Cells["Nasal_Discharge_NAT"].Value.ToString() + "', Inf_Throat_NAT ='" + dataGridView2.Rows[e.RowIndex].Cells["Inf_Throat_NAT"].Value.ToString() + "', Inf_Tensile_NAT ='" + dataGridView2.Rows[e.RowIndex].Cells["Inf_Tensile_NAT"].Value.ToString() + "', Other_NAT ='" + dataGridView2.Rows[e.RowIndex].Cells["Other_NAT"].Value.ToString() + "', Normal_MTG ='" + dataGridView2.Rows[e.RowIndex].Cells["Normal_MTG"].Value.ToString() + "', Broken_MTG ='" + dataGridView2.Rows[e.RowIndex].Cells["Broken_MTG"].Value.ToString() + "', Loose_MTG ='" + dataGridView2.Rows[e.RowIndex].Cells["Loose_MTG"].Value.ToString() + "', Ulcers_Lesions_MTG ='" + dataGridView2.Rows[e.RowIndex].Cells["Ulcers_Lesions_MTG"].Value.ToString() + "', Pyorrhea_MTG ='" + dataGridView2.Rows[e.RowIndex].Cells["Pyorrhea_MTG"].Value.ToString() + "', Gingivitis_MTG ='" + dataGridView2.Rows[e.RowIndex].Cells["Gingivitis_MTG"].Value.ToString() + "', Stain_MTG ='" + dataGridView2.Rows[e.RowIndex].Cells["Stain_MTG"].Value.ToString() + "', Tartar_Degree_MTG ='" + dataGridView2.Rows[e.RowIndex].Cells["Tartar_Degree_MTG"].Value.ToString() + "', Normal_MLL ='" + dataGridView2.Rows[e.RowIndex].Cells["Normal_MLL"].Value.ToString() + "', Lameness_MLL ='" + dataGridView2.Rows[e.RowIndex].Cells["Lameness_MLL"].Value.ToString() + "', Pain_on_Palpation_MLL ='" + dataGridView2.Rows[e.RowIndex].Cells["Pain_on_Palpation_MLL"].Value.ToString() + "', Sounds_Normal_H ='" + dataGridView2.Rows[e.RowIndex].Cells["Sounds_Normal_H"].Value.ToString() + "', Arrhythmia_H ='" + dataGridView2.Rows[e.RowIndex].Cells["Arrhythmia_H"].Value.ToString() + "', Murmur_H ='" + dataGridView2.Rows[e.RowIndex].Cells["Murmur_H"].Value.ToString() + "', Other_H ='" + dataGridView2.Rows[e.RowIndex].Cells["Other_H"].Value.ToString() + "', Normal_AB ='" + dataGridView2.Rows[e.RowIndex].Cells["Normal_AB"].Value.ToString() + "', Enlarged_AB ='" + dataGridView2.Rows[e.RowIndex].Cells["Enlarged_AB"].Value.ToString() + "', Mass_AB ='" + dataGridView2.Rows[e.RowIndex].Cells["Mass_AB"].Value.ToString() + "', Fluid_AB ='" + dataGridView2.Rows[e.RowIndex].Cells["Fluid_AB"].Value.ToString() + "', Other_AB ='" + dataGridView2.Rows[e.RowIndex].Cells["Other_AB"].Value.ToString() + "', Normal_Sound_LU ='" + dataGridView2.Rows[e.RowIndex].Cells["Normal_Sound_LU"].Value.ToString() + "', Abnormal_Sound_LU ='" + dataGridView2.Rows[e.RowIndex].Cells["Abnormal_Sound_LU"].Value.ToString() + "', Breathing_Difficulty_LU ='" + dataGridView2.Rows[e.RowIndex].Cells["Breathing_Difficulty_LU"].Value.ToString() + "', Coughing_LU ='" + dataGridView2.Rows[e.RowIndex].Cells["Coughing_LU"].Value.ToString() + "', Congestion_LU ='" + dataGridView2.Rows[e.RowIndex].Cells["Congestion_LU"].Value.ToString() + "', Other_LU ='" + dataGridView2.Rows[e.RowIndex].Cells["Other_LU"].Value.ToString() + "' Where No= " + Id1 + "";

                cmd2.ExecuteNonQuery();

                MessageBox.Show("The Data was Updated");
                fill_grid2();

            }
        }

        private void dataGridView3_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            Id = dataGridView3.Rows[e.RowIndex].Cells["No"].Value.ToString();
            if (Id == "")
            {
                Id1 = 0;
            }

            else
            {
                Id1 = Convert.ToInt32(dataGridView3.Rows[e.RowIndex].Cells["No"].Value.ToString());
            }

            if (Id1 == 0)
            {
                SqlCommand cmd3 = con.CreateCommand();
                cmd3.CommandType = CommandType.Text;
                cmd3.CommandText = "Insert into Ph_Ex2 Vaues ('" + dataGridView3.Rows[e.RowIndex].Cells["Owner"].Value.ToString() + "', '" + dataGridView3.Rows[e.RowIndex].Cells["Mobile"].Value.ToString() + "', '" + dataGridView3.Rows[e.RowIndex].Cells["Pet"].Value.ToString() + "', '" + dataGridView3.Rows[e.RowIndex].Cells["Normal_GIT"].Value.ToString() + "', '" + dataGridView3.Rows[e.RowIndex].Cells["Abn_Feces_GIT"].Value.ToString() + "', '" + dataGridView3.Rows[e.RowIndex].Cells["Excessive_Gas_GIT"].Value.ToString() + "', '" + dataGridView3.Rows[e.RowIndex].Cells["Parasites_GIT"].Value.ToString() + "', '" + dataGridView3.Rows[e.RowIndex].Cells["Vomiting_GIT"].Value.ToString() + "', '" + dataGridView3.Rows[e.RowIndex].Cells["Diarrhea_GIT"].Value.ToString() + "', '" + dataGridView3.Rows[e.RowIndex].Cells["Anorexia_GIT"].Value.ToString() + "', '" + dataGridView3.Rows[e.RowIndex].Cells["Other_GIT"].Value.ToString() + "', '" + dataGridView3.Rows[e.RowIndex].Cells["Normal_US"].Value.ToString() + "', '" + dataGridView3.Rows[e.RowIndex].Cells["Abnormal_Urination_US"].Value.ToString() + "', '" + dataGridView3.Rows[e.RowIndex].Cells["Anal_Sacs_US"].Value.ToString() + "', '" + dataGridView3.Rows[e.RowIndex].Cells["Genital_discharge_US"].Value.ToString() + "', '" + dataGridView3.Rows[e.RowIndex].Cells["Abn_Testicles_US"].Value.ToString() + "', '" + dataGridView3.Rows[e.RowIndex].Cells["Mammary_Abn_US"].Value.ToString() + "', '" + dataGridView3.Rows[e.RowIndex].Cells["Other_US"].Value.ToString() + "', '" + dataGridView3.Rows[e.RowIndex].Cells["Excellent_D"].Value.ToString() + "', '" + dataGridView3.Rows[e.RowIndex].Cells["Good_D"].Value.ToString() + "', '" + dataGridView3.Rows[e.RowIndex].Cells["Change_Diet_D"].Value.ToString() + "', '" + dataGridView3.Rows[e.RowIndex].Cells["Vitamins_needed_D"].Value.ToString() + "', '" + dataGridView3.Rows[e.RowIndex].Cells["Recommendations_D"].Value.ToString() + "', '" + dataGridView3.Rows[e.RowIndex].Cells["Diagnosis_Explanations"].Value.ToString() + "', '" + dataGridView3.Rows[e.RowIndex].Cells["Recommendations"].Value.ToString() + "', '" + dataGridView3.Rows[e.RowIndex].Cells["Price"].Value.ToString() + "', '" + dataGridView3.Rows[e.RowIndex].Cells["Pay"].Value.ToString() + "')";

                cmd3.ExecuteNonQuery();
                fill_grid3();
            }

            else
            {
                SqlCommand cmd3 = con.CreateCommand();
                cmd3.CommandType = CommandType.Text;
                cmd3.CommandText = "Update Ph_Ex2 set Owner ='" + dataGridView3.Rows[e.RowIndex].Cells["Owner"].Value.ToString() + "', Mobile ='" + dataGridView3.Rows[e.RowIndex].Cells["Mobile"].Value.ToString() + "', Pet ='" + dataGridView3.Rows[e.RowIndex].Cells["Pet"].Value.ToString() + "', Normal_GIT ='" + dataGridView3.Rows[e.RowIndex].Cells["Normal_GIT"].Value.ToString() + "', Abn_Feces_GIT ='" + dataGridView3.Rows[e.RowIndex].Cells["Abn_Feces_GIT"].Value.ToString() + "', Excessive_Gas_GIT ='" + dataGridView3.Rows[e.RowIndex].Cells["Excessive_Gas_GIT"].Value.ToString() + "', Parasites_GIT ='" + dataGridView3.Rows[e.RowIndex].Cells["Parasites_GIT"].Value.ToString() + "', Vomiting_GIT ='" + dataGridView3.Rows[e.RowIndex].Cells["Vomiting_GIT"].Value.ToString() + "', Diarrhea_GIT ='" + dataGridView3.Rows[e.RowIndex].Cells["Diarrhea_GIT"].Value.ToString() + "', Anorexia_GIT ='" + dataGridView3.Rows[e.RowIndex].Cells["Anorexia_GIT"].Value.ToString() + "', Other_GIT ='" + dataGridView3.Rows[e.RowIndex].Cells["Other_GIT"].Value.ToString() + "', Normal_US ='" + dataGridView3.Rows[e.RowIndex].Cells["Normal_US"].Value.ToString() + "', Abnormal_Urination_US ='" + dataGridView3.Rows[e.RowIndex].Cells["Abnormal_Urination_US"].Value.ToString() + "', Anal_Sacs_US ='" + dataGridView3.Rows[e.RowIndex].Cells["Anal_Sacs_US"].Value.ToString() + "', Genital_discharge_US ='" + dataGridView3.Rows[e.RowIndex].Cells["Genital_discharge_US"].Value.ToString() + "', Abn_Testicles_US ='" + dataGridView3.Rows[e.RowIndex].Cells["Abn_Testicles_US"].Value.ToString() + "', Mammary_Abn_US ='" + dataGridView3.Rows[e.RowIndex].Cells["Mammary_Abn_US"].Value.ToString() + "', Other_US ='" + dataGridView3.Rows[e.RowIndex].Cells["Other_US"].Value.ToString() + "', Excellent_D ='" + dataGridView3.Rows[e.RowIndex].Cells["Excellent_D"].Value.ToString() + "', Good_D ='" + dataGridView3.Rows[e.RowIndex].Cells["Good_D"].Value.ToString() + "', Change_Diet_D ='" + dataGridView3.Rows[e.RowIndex].Cells["Change_Diet_D"].Value.ToString() + "', Vitamins_needed_D ='" + dataGridView3.Rows[e.RowIndex].Cells["Vitamins_needed_D"].Value.ToString() + "', Recommendations_D ='" + dataGridView3.Rows[e.RowIndex].Cells["Recommendations_D"].Value.ToString() + "', Diagnosis_Explanations ='" + dataGridView3.Rows[e.RowIndex].Cells["Diagnosis_Explanations"].Value.ToString() + "', Recommendations ='" + dataGridView3.Rows[e.RowIndex].Cells["Recommendations"].Value.ToString() + "', Price ='" + dataGridView3.Rows[e.RowIndex].Cells["Price"].Value.ToString() + "', Pay ='" + dataGridView3.Rows[e.RowIndex].Cells["Pay"].Value.ToString() + "' Where No= " + Id1 + "";

                cmd3.ExecuteNonQuery();

                MessageBox.Show("The Data was Updated");
                fill_grid3();

            }
        }

        private void deleteRecord0ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SqlCommand cmd0 = con.CreateCommand();
            cmd0.CommandType = CommandType.Text;
            cmd0.CommandText = "Delete from Add_Veterinary Where No="+ delete_Id +"";

            MessageBox.Show("Selected Row was Deleted");
            cmd0.ExecuteNonQuery();
            fill_grid0();
        }

        private void deleteRecord1ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SqlCommand cmd1 = con.CreateCommand();
            cmd1.CommandType = CommandType.Text;
            cmd1.CommandText = "Delete from Ph_Ex Where No="+ delete_Id + "";

            MessageBox.Show("Selected Row was Deleted");
            cmd1.ExecuteNonQuery();
            fill_grid1();
        }

        private void deleteRecord2ToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            SqlCommand cmd2 = con.CreateCommand();
            cmd2.CommandType = CommandType.Text;
            cmd2.CommandText = "Delete from Ph_Ex1 Where No="+ delete_Id + "";

            MessageBox.Show("Selected Row was Deleted");
            cmd2.ExecuteNonQuery();
            fill_grid2();
        }

        private void deleteRecord3ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SqlCommand cmd3 = con.CreateCommand();
            cmd3.CommandType = CommandType.Text;
            cmd3.CommandText = "Delete from Ph_Ex2 Where No="+ delete_Id + "";

            MessageBox.Show("Selected Row was Deleted");
            cmd3.ExecuteNonQuery();
            fill_grid3();
        }

        private void dataGridView0_CellMouseUp(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                delete_Id = Convert.ToInt32(dataGridView0.Rows[e.RowIndex].Cells["No"].Value.ToString());
                this.contextMenuStrip0.Show(this.dataGridView0, e.Location);
                contextMenuStrip0.Show(Cursor.Position);
            }
        }

        private void dataGridView1_CellMouseUp(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                delete_Id = Convert.ToInt32(dataGridView1.Rows[e.RowIndex].Cells["No"].Value.ToString());
                this.contextMenuStrip1.Show(this.dataGridView1, e.Location);
                contextMenuStrip1.Show(Cursor.Position);
            }
        }

        private void dataGridView2_CellMouseUp(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                delete_Id = Convert.ToInt32(dataGridView2.Rows[e.RowIndex].Cells["No"].Value.ToString());
                this.contextMenuStrip2.Show(this.dataGridView2, e.Location);
                contextMenuStrip2.Show(Cursor.Position);
            }
        }

        private void dataGridView3_CellMouseUp(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                delete_Id = Convert.ToInt32(dataGridView3.Rows[e.RowIndex].Cells["No"].Value.ToString());
                this.contextMenuStrip3.Show(this.dataGridView3, e.Location);
                contextMenuStrip3.Show(Cursor.Position);
            }
        }
    }
        
}
