﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Professional_Vets
{
    public partial class Boarding : Form
    {
        String vn;
        
        SqlConnection con;
        SqlCommand cmd;

        private void Boarding_Load(object sender, EventArgs e)
        {
            if (ch_NoD_BD.Checked)
            {
                txt_NoD_BD.Visible = true;
            }
            else
            {
                txt_NoD_BD.Visible = false;
            }

            if (ch_Other_BD.Checked)
            {
                rtxt_Other_BD.Visible = true;
            }
            else
            {
                rtxt_Other_BD.Visible = false;
            }

        }

        private void txt_Mobile_KeyPress(object sender, KeyPressEventArgs e)
        {
            //For enter number only

            if ((e.KeyChar >= 48 && e.KeyChar <= 57) || e.KeyChar == 8)
            {


                e.Handled = false;

            }
            else
            {
                MessageBox.Show("Please Enter only Number.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                e.Handled = true;

            }
        }

        private void txt_NoD_BD_KeyPress(object sender, KeyPressEventArgs e)
        {
            //For enter number only

            if ((e.KeyChar >= 48 && e.KeyChar <= 57) || e.KeyChar == 8)
            {


                e.Handled = false;

            }
            else
            {
                MessageBox.Show("Please Enter only Number.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                e.Handled = true;

            }
        }

        private void ch_NoD_BD_CheckedChanged(object sender, EventArgs e)
        {
            txt_NoD_BD.Visible = (ch_NoD_BD.CheckState == CheckState.Checked);
            
        }

        private void ch_Other_BD_CheckedChanged(object sender, EventArgs e)
        {
            rtxt_Other_BD.Visible = (ch_Other_BD.CheckState == CheckState.Checked);
        }

        private void circularButton3_Click(object sender, EventArgs e)
        {
            String Food, Med;

            Food = ch_Food_BD.Checked == true ? "Yes" : "No";
            Med = ch_Medications_BD.Checked == true ? "Yes" : "No";


            con = new SqlConnection(Properties.Settings.Default.Database1ConnectionString);
            con.Open();

            cmd = new SqlCommand("Insert INTO Boarding (Vet_Name, Pet, Age, Species, Breed, Sex, Color_Hair, Owner, Address, Mobile, Email, Number_of_Boarding_Days, Food, Medications, Other, Date) VALUES (@Vet_Name, @Pet, @Age, @Species, @Breed, @Sex, @Color_Hair, @Owner, @Address, @Mobile, @Email, @Number_of_Boarding_Days, @Food, @Medications, @Other, @Date)", con);

            // Pet Info
            cmd.Parameters.AddWithValue("@Vet_Name", vn);
            cmd.Parameters.AddWithValue("@Pet", txt_PetName.Text);
            cmd.Parameters.AddWithValue("@Age", txt_Age.Text);
            cmd.Parameters.AddWithValue("@Date", DateTime.Now);

            if (cobo_Species.SelectedItem != null)
            {
                cmd.Parameters.AddWithValue("@Species", cobo_Species.SelectedItem.ToString());
            }
            else
            {
                cmd.Parameters.AddWithValue("@Species", "null");
            }
            
            if(cobo_Sex.SelectedItem != null)
            {
                cmd.Parameters.AddWithValue("@Sex", cobo_Sex.SelectedItem.ToString());
            }
            else
            {
                cmd.Parameters.AddWithValue("@Sex", "null");
            }
            

            cmd.Parameters.AddWithValue("@Breed", txt_Breed.Text);
            cmd.Parameters.AddWithValue("@Color_Hair", txt_Color_Hair.Text);

            // Owner Info
            cmd.Parameters.AddWithValue("@Owner", txt_Owner.Text);
            cmd.Parameters.AddWithValue("@Address", rtxt_Address.Text);
            cmd.Parameters.AddWithValue("@Mobile", txt_Mobile.Text);
            cmd.Parameters.AddWithValue("@Email", txt_Email.Text);

            //Boarding Details
            cmd.Parameters.AddWithValue("@Number_of_Boarding_Days", txt_NoD_BD.Text);
            cmd.Parameters.AddWithValue("@Food", Food);
            cmd.Parameters.AddWithValue("@Medications", Med);
            cmd.Parameters.AddWithValue("@Other", rtxt_Other_BD.Text);

            cmd.ExecuteNonQuery();
            con.Close();


            this.Hide();
            HomePage HP = new HomePage(vn);
            HP.ShowDialog();
        }

        public Boarding(String role)
        {
            InitializeComponent();
            vn = role;
        }

        private void circularButton1_Click(object sender, EventArgs e)
        {
            this.Hide();
            HomePage HP = new HomePage(vn);
            HP.ShowDialog();
        }

        private void Boarding_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.Hide();
            HomePage HP = new HomePage(vn);
            HP.ShowDialog();
        }
    }
}
